module V1
  module Staff
    class ScheduleDateSerializer < ActiveModel::Serializer
      attributes :id, :date, :start_time, :end_time, :nurse_id, :time_range

      has_one :nursing_care_history
      belongs_to :scheduleable, polymorphic: true
      belongs_to :nurse, class_name: 'NursingStaff', serializer: NursingStaffSerializer

      def nursing_care_history
        return nil if object.nursing_care_history.blank?

        NursingCareHistorySerializer.new(object.nursing_care_history).as_json
      end

      def scheduleable
        ScheduleSerializer.new(object.scheduleable).as_json
      end

      def time_range
        "#{object.start_time_format} ~ #{object.end_time_format}"
      end
    end
  end
end
