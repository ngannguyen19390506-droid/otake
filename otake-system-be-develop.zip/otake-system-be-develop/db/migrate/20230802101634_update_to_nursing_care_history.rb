class UpdateToNursingCareHistory < ActiveRecord::Migration[7.0]
  def change
    add_reference :nursing_care_histories, :schedule_date, foreign_key: true, null: true
    add_reference :nursing_care_histories, :service, foreign_key: true, null: true
    add_reference :nursing_care_histories, :service_type, foreign_key: true, null: true
    add_column :nursing_care_histories, :start_time, :string, null: true
    add_column :nursing_care_histories, :end_time, :string, null: true
    change_column :nursing_care_histories, :division, 'integer USING division::integer', null: true
    add_column :nursing_care_histories, :physical_care, :integer, null: true
    change_column :nursing_care_histories, :complexion,  'integer USING complexion::integer', null: true
    change_column :nursing_care_histories, :sweating, 'integer USING sweating::integer', null: true
    change_column :nursing_care_histories, :environmental_arrangement, 'boolean USING environmental_arrangement::boolean', null: true
    change_column :nursing_care_histories, :consultation_assistance, 'boolean USING consultation_assistance::boolean', null: true
    add_column :nursing_care_histories, :record, :boolean, null: true
    change_column :nursing_care_histories, :toilet_assistance, 'boolean USING toilet_assistance::boolean', null: true
    change_column :nursing_care_histories, :diaper_check, 'boolean USING diaper_check::boolean', null: true
    change_column :nursing_care_histories, :pad_confirmation, 'boolean USING pad_confirmation::boolean', null: true
    change_column :nursing_care_histories, :defecation, 'integer USING defecation::integer', null: true
    change_column :nursing_care_histories, :urinal_cleaning, 'boolean USING urinal_cleaning::boolean', null: true
    change_column :nursing_care_histories, :maintain_posture, 'boolean USING maintain_posture::boolean', null: true
    change_column :nursing_care_histories, :washing_hair, 'boolean USING washing_hair::boolean', null: true
    change_column :nursing_care_histories, :full_body_bath_procedure, 'boolean USING full_body_bath_procedure::boolean', null: true
    change_column :nursing_care_histories, :washbasin, 'boolean USING washbasin::boolean', null: true
    change_column :nursing_care_histories, :oral_care, 'boolean USING oral_care::boolean', null: true
    change_column :nursing_care_histories, :dressing_assistance, 'boolean USING dressing_assistance::boolean', null: true
    change_column :nursing_care_histories, :position_exchange, 'boolean USING position_exchange::boolean', null: true
    change_column :nursing_care_histories, :transfer_assistance, 'boolean USING transfer_assistance::boolean', null: true
    change_column :nursing_care_histories, :watch_over, 'boolean USING watch_over::boolean', null: true
    change_column :nursing_care_histories, :note, :text, null: true
    change_column :nursing_care_histories, :eating_assistance, :string, null: true
    change_column :nursing_care_histories, :full_body_bath, :string, null: true
    change_column :nursing_care_histories, :cleaning, :string, null: true
    change_column :nursing_care_histories, :hydration, :integer, null: true
    change_column :nursing_care_histories, :urination, :integer, null: true
    remove_column :nursing_care_histories, :defecation_type
    remove_column :nursing_care_histories, :manager
    remove_column :nursing_care_histories, :moisture
    remove_column :nursing_care_histories, :temperature
    remove_column :nursing_care_histories, :blood_pressure
  end
end
