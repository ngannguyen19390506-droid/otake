module V1
  module Admin
    module ShiftRegistrations
      class CreateShiftRegistration < ::ApplicationOperation
        def call(params, shift_code)
          if invalid_time_rage?(params[:start_time], params[:end_time])
            return Failure({ start_time: I18n.t('errors.messages.invalid') })
          end

          shift_registration = create_shift_registration_info(params, shift_code)
          if shift_registration.valid?
            Success(shift_registration)
          else
            Failure(shift_registration.errors.messages.transform_values { |value| value.join(',') })
          end
        end

        private

        def create_shift_registration_info(params, shift_code)
          ShiftRegistration.create({
                                     shift_code: shift_code,
                                     start_time: params[:start_time],
                                     end_time: params[:end_time],
                                     abbreviation: params[:abbreviation],
                                     name: params[:name],
                                     background_color: params[:background_color],
                                     text_color: params[:text_color]
                                   })
        end
      end
    end
  end
end
