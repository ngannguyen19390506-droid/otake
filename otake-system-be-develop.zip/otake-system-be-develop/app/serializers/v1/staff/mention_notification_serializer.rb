module V1
  module Staff
    class MentionNotificationSerializer < ActiveModel::Serializer
      attributes :id,
                 :m_id,
                 :name

      def name
        Patient.find_by(id: object.m_id)&.family_name
      end
    end
  end
end
