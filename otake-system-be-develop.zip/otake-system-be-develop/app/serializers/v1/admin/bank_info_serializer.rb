module V1
  module Admin
    class BankInfoSerializer < ActiveModel::Serializer
      attributes :id, :formal_name, :bank_name, :bank_name_kana, :bank_code, :bank_name_search

      def bank_name_search
        "#{object.formal_name}(#{object.bank_code})"
      end
    end
  end
end
