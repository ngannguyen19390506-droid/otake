# == Schema Information
#
# Table name: document_receipts
#
#  id         :bigint           not null, primary key
#  files      :text
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  receipt_id :integer
#
class DocumentReceipt < ActiveRecord::Base
  has_one_attached :image

  belongs_to :receipt

  def file_url
    Rails.application.routes.url_helpers.rails_blob_url(image, host: ENV['API_URI']) if image.attached?
  end
end
