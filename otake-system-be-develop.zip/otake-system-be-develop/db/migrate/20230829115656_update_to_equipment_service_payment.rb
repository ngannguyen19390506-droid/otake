class UpdateToEquipmentServicePayment < ActiveRecord::Migration[7.0]
  def change
    change_column :equipment_service_payments, :equipment_service_id, :bigint, null: true
  end
end
