if UserHomeSystem.admin.blank?
  UserHomeSystem.admin.create(
    user_code: '0001',
    password: 'Otake123',
    user_name: 'Admin HS'
  )
end

if UserHomeSystem.staff.blank?
  UserHomeSystem.staff.create(
    user_code: '0002',
    password: 'Otake123',
    user_name: 'Staff HS '
  )
end
