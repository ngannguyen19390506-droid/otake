class AddCreateTypeToHoliday < ActiveRecord::Migration[7.0]
  def change
    add_column :holidays, :create_type, :integer
    rename_column :shift_managements, :shift_name, :shift_registration_id
  end
end
