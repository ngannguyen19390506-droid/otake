class AddHexColorToPatients < ActiveRecord::Migration[7.0]
  def change
    add_column :patients, :hex_color, :string
  end
end
