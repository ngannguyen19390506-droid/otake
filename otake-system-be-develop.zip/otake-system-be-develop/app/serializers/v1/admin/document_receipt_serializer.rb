module V1
  module Admin
    class DocumentReceiptSerializer < ActiveModel::Serializer
      attributes :id,
                 :files,
                 :file_path

      def file_path
        ActiveStorage::Blob.service.path_for(object.files.key)
      end
    end
  end
end
