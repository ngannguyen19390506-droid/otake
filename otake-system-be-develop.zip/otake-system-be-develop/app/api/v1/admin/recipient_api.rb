module V1
  module Admin
    class RecipientApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :recipients do
          desc 'GET api/v1/admin/recipients',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
          end
          get do
            patient = Patient.find(params[:patient_id])
            page = (params[:page].presence || 1).to_i
            @query = patient.recipients
            @objects = @query.by_created_at_desc.page(page).per(params[:per])
            serialized_data = @objects.map do |item|
              RecipientSerializer.new(item).as_json
            end
            present :page, page
            present :total_page, @objects.total_pages
            present :total_items, @objects.total_count
            present :recipients, serialized_data
          end

          desc 'GET api/v1/admin/recipients/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
          end
          get '/:id' do
            recipient = Recipient.find(params[:id])
            recipient.update(recipient_params)
            render recipient
          end

          desc 'POST api/v1/admin/recipients',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :business_code, type: String
            requires :patient_id, type: Integer
            requires :recipient_code, type: String
            requires :service_content, type: String
            requires :contract_allocation_amount, type: String
            requires :contract_date, type: String
            requires :service_end_date, type: String
            requires :applicable_start_date, type: String
            requires :user_burden_percentage, type: String
            requires :monthly_cost_limit, type: String
          end
          post do
            Recipient.create(recipient_params)

            { success: I18n.t('recipient.success.added') }
          end

          desc 'PUT api/v1/admin/recipients/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
            optional :business_code, type: String
            optional :recipient_code, type: String
            optional :service_content, type: String
            optional :contract_allocation_amount, type: String
            optional :contract_date, type: String
            optional :service_end_date, type: String
            optional :applicable_start_date, type: String
            optional :user_burden_percentage, type: String
            optional :monthly_cost_limit, type: Integer
          end
          put '/:id' do
            recipient = Recipient.find(params[:id])
            recipient.update(recipient_params)

            { success: I18n.t('recipient.success.updated') }
          end

          desc 'POST api/v1/admin/recipients/delete-multiple',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :ids, type: Array, desc: '[1, 2, 3]'
          end
          post '/delete-multiple' do
            error!(I18n.t('errors.messages.params_invalid'), UNPROCESSABLE_ENTITY) if params[:ids].blank?

            Recipient.where(id: params[:ids])&.destroy_all

            @objects = Recipient.all
            present :total_items, @objects.count
            present :message, I18n.t('recipient.success.deleted')
          end
        end
      end

      helpers do
        def recipient_params
          params.slice(:patient_id, :business_code, :recipient_code, :service_content, :contract_allocation_amount,
                       :contract_date, :service_end_date, :applicable_start_date, :user_burden_percentage,
                       :monthly_cost_limit)
        end
      end
    end
  end
end
