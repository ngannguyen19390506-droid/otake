class UpdateToSystemManagementProfile < ActiveRecord::Migration[7.0]
  def change
    rename_column :system_management_profiles, :state, :district
    rename_column :system_management_profiles, :house_no, :building_name
    change_column_null :system_management_profiles, :building_name, true
    add_column :system_management_profiles, :mobile_phone, :string
  end
end
