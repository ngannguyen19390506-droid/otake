# == Schema Information
#
# Table name: evalue_ones
#
#  id                      :bigint           not null, primary key
#  character               :text
#  created_date            :date
#  current_illness_history :text
#  daily_life_challenges   :text
#  daily_rhythm_of_life    :text
#  family_circumstances    :text
#  family_interview        :text
#  hobbies                 :text
#  life_history            :text
#  note                    :text
#  personal_interview      :text
#  special_notes           :text
#  created_at              :datetime         not null
#  updated_at              :datetime         not null
#  patient_id              :bigint           not null
#
# Indexes
#
#  index_evalue_ones_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class EvalueOne < ApplicationRecord
  include ApiCommon
  belongs_to :patient
  # has_many :change_histories, as: :changeable, dependent: :destroy

  # def create_change_histories(user_admin_id)
  #   ActiveRecord::Base.transaction do
  #     all_changes = extract_changes_without_timestamps(previous_changes)
  #     all_changes.each do |changed_attribute, (before_value, after_value)|
  #       text_description = attribute_description(changed_attribute)
  #       create_change_history(user_admin_id, text_description, before_value, after_value)
  #     end
  #   rescue StandardError => e
  #     e
  #   end
  # end

  # private

  # def attribute_description(attribute_name)
  #   descriptions = {
  #     'pre_history' => '生活歴',
  #     'heartbeat' => '1日の生活リズム',
  #     'daily_life_challenges' => '日常生活の課題',
  #     'note' => 'その他注意事項',
  #     'character' => '性格',
  #     'hobbies' => '趣味・レク',
  #     'family_circumstances' => '家族状況',
  #     'special_notes' => '特記・他サービス利用'
  #   }
  #   descriptions[attribute_name] || attribute_name
  # end
end
