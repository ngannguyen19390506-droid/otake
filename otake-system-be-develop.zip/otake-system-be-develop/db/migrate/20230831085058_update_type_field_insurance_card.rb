class UpdateTypeFieldInsuranceCard < ActiveRecord::Migration[7.0]
  def change
    change_column :insurance_cards, :certification_department, 'integer USING certification_department::integer'
  end
end
