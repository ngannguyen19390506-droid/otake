module V1
  module AdminHomeSystem
    class MessageSerializer < ActiveModel::Serializer
      attributes :id, 
                 :content,
                 :sender_id,
                 :sender_type,
                 :room_id,
                 :read_at,
                 :time_send_at,
                 :hour_at,
                 :is_unread

      belongs_to :sender, polymorphic: true

      def time_send_at
        I18n.locale = :ja
        "#{object.created_at.strftime("%Y/%m/%d %H:%M")} #{DAY_NAMES[object.created_at.wday]}"  
      end

      def hour_at
        object.created_at.strftime("%H:%M")
      end

      def is_unread
        object.read_at.nil?
      end
    end
  end
end
