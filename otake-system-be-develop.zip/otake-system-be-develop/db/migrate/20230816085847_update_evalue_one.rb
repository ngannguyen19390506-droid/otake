class UpdateEvalueOne < ActiveRecord::Migration[7.0]
  def change
    remove_column :evalue_ones, :average_blood_pressure
    remove_column :evalue_ones, :temp
  end
end
