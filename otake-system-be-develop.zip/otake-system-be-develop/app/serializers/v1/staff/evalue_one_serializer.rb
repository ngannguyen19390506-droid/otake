module V1
  module Staff
    class EvalueOneSerializer < ActiveModel::Serializer
      attributes :id,
                 :patient_id,
                 :heartbeat,
                 :pre_history,
                 :daily_life_challenges,
                 :note,
                 :character,
                 :hobbies,
                 :family_circumstances,
                 :special_notes,
                 :current_illness_history,
                 :family_interview,
                 :personal_interview,
                 :created_date
    end
  end
end
