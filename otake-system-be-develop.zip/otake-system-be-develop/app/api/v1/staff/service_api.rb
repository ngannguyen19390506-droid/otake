module V1
  module Staff
    class ServiceApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :services do
          # patient_type=normal || patient_type=disability
          desc 'GET /api/v1/staff/services'
          params do
            optional :patient_type, type: String
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
          end
          get do
            @query = Service.all
            @query = Service.where(patient_type: params[:patient_type]) if params[:patient_type].present?
            return present :data, @query.default_order if params[:get_all] == true

            page = (params[:page].presence || 1).to_i
            @services = @query.default_order
            if params[:sortKey].present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              @services = @query.order(params[:sortKey] => sort_order)
            end
            @services = @services.page(page).per(params[:per])
            serialized_services = @services.map do |service|
              ServiceSerializer.new(service).as_json
            end
            present :page, page
            present :total_items, @services.total_count
            present :total_pages, @services.total_pages
            present :serialized_services, serialized_services
          end
        end
      end
    end
  end
end
