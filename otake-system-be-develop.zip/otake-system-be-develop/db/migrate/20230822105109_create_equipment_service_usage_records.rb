class CreateEquipmentServiceUsageRecords < ActiveRecord::Migration[7.0]
  def change
    create_table :equipment_service_usages do |t|
      t.references :equipment_service_payment, null: false, foreign_key: true
      t.date :date, null: false
      t.integer :quantity, null: false

      t.timestamps
    end
  end
end
