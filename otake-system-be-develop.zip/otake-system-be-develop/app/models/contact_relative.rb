# == Schema Information
#
# Table name: contact_relatives
#
#  id               :bigint           not null, primary key
#  address          :string
#  cellphone_number :string
#  name             :string
#  relationship     :string
#  telephone_number :string
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  nurse_id         :bigint
#  patient_id       :bigint
#
# Indexes
#
#  index_contact_relatives_on_nurse_id    (nurse_id)
#  index_contact_relatives_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (nurse_id => nursing_staffs.id)
#  fk_rails_...  (patient_id => patients.id)
#
class ContactRelative < ApplicationRecord
  include ApiCommon

  belongs_to :nurse, class_name: 'NursingStaff', optional: true
  belongs_to :patient, optional: true

  validates :telephone_number, :cellphone_number, length: { in: MIN_LENGTH_TEN..MAX_LENGTH_TWENTY }, allow_blank: true
end
