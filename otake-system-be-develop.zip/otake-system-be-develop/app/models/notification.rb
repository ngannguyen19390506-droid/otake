# == Schema Information
#
# Table name: notifications
#
#  id                       :bigint           not null, primary key
#  confirmer                :string
#  content                  :string           not null
#  deleted_at               :datetime
#  deployment_date          :date
#  discoverer               :string
#  is_deleted               :boolean          default(FALSE)
#  is_important             :boolean          default(FALSE)
#  notify_type              :integer          not null
#  occurred_at              :datetime
#  occurrence_status        :string
#  poster                   :string           not null
#  response_action          :text
#  sender_type              :string
#  target_person            :string
#  title                    :string
#  created_at               :datetime         not null
#  updated_at               :datetime         not null
#  notification_category_id :integer
#  patient_id               :integer
#  sender_id                :integer
#
# Indexes
#
#  index_notifications_on_sender_type_and_sender_id  (sender_type,sender_id)
#
class Notification < ApplicationRecord
  include ApiCommon
  has_one_attached :file

  has_many :mention_notifications, dependent: :destroy
  has_many :notification_view_logs, dependent: :destroy
  belongs_to :patient, foreign_key: :patient_id, optional: true
  belongs_to :notification_category, foreign_key: :notification_category_id, optional: true
  belongs_to :user_home_system, foreign_key: :user_home_system_id, optional: true

  validates :content, :poster, :notify_type, :target_person, :discoverer, :occurred_at, :occurrence_status,
            :response_action, :confirmer, presence: true

  scope :root_levels, -> { where(level: 1, reply_to: nil) }
  scope :by_level, ->(level, id) { where(level: level, reply_to: id) }
  scope :by_admin_owner, ->(id) { where(sender_id: id, sender_type: 'UserAdmin') }
  scope :patient_exists, -> { where.not(patient_id: nil) }

  enum notify_type: { noti_by_admin: 1, noti_by_hs_admin: 2, noti_by_hs_staff: 3, noti_by_staff: 4 }

  def self.ransackable_attributes(_auth_object = nil)
    %w[title content created_at notification_category_id]
  end

  def self.ransackable_associations(_auth_object = nil)
    %w[]
  end
end
