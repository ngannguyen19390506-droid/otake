class CreatePostCode < ActiveRecord::Migration[7.0]
  def change
    create_table :post_codes do |t|
      t.references :city, null: false, foreign_key: true
      t.references :district, null: false, foreign_key: true
      t.references :address, null: false, foreign_key: true
      t.string :code, null: false
      t.timestamps
    end

    add_index :post_codes, :code, unique: true
  end
end
