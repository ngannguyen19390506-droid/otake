# == Schema Information
#
# Table name: routines
#
#  id         :bigint           not null, primary key
#  regis_day  :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  nurse_id   :integer          not null
#
class Routine < ApplicationRecord
  belongs_to :nurse, class_name: 'NursingStaff', optional: true

  def self.week_days
    [1, 2, 3, 4, 5, 6, 0]
  end
end
