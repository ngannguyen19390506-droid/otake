module V1
  module Admin
    class PaymentHistorySerializer < ActiveModel::Serializer
      attributes :id,
                 :actual_date,
                 :expected_date,
                 :year_month,
                 :status

      def status
        return '入金完了' if object.actual_date.present? && object.expected_date.present?
      end
    end
  end
end
