module V1
  module Admin
    module CarePlans
      class CarePlanBaseOperation < ::ApplicationOperation
        private

        def create_schedule(care_plan, schedule_params, care_plan_type)
          start_time = schedule_params[:start_time].present? ? schedule_params[:start_time] : nil
          end_time = schedule_params[:end_time].present? ? schedule_params[:end_time] : nil
          schedule = Schedule.create(
            care_plan_id: care_plan.id,
            patient_id: care_plan.patient_id,
            care_plan_type: care_plan_type,
            service_id: schedule_params[:service_id],
            service_type_id: schedule_params[:service_type_id],
            frequency: schedule_params[:frequency],
            shift_type: schedule_params[:shift_type],
            date: schedule_params[:date],
            start_time: start_time,
            end_time: end_time,
            sort_index: schedule_params[:sort_index]
          )
          schedule
        end

        def create_schedule_date(schedule_id, schedule_params)
          schedule_params[:shift_dates].each do |date|
            schedule_date = ScheduleDate.new(
              scheduleable_id: schedule_id,
              date: date,
              start_time: schedule_params[:start_time],
              end_time: schedule_params[:end_time],
              scheduleable_type: 'Schedule'
            )
            schedule_date.save!
          end
        end

        def create_schedule_routine(schedule_id, schedule_params, frequency = nil)
          schedule_params[:schedule_routines].each do |data|
            next unless data[:checked]

            routine = ScheduleRoutine.new(
              schedule_id: schedule_id,
              regis_day: data[:regis_day]
            )
            routine.save!
          end
        end

        def update_schedule(schedule, schedule_params)
          start_time = schedule_params[:start_time].present? ? schedule_params[:start_time] : nil
          end_time = schedule_params[:end_time].present? ? schedule_params[:end_time] : nil

          schedule.update!(
            service_id: schedule_params[:service_id],
            service_type_id: schedule_params[:service_type_id],
            frequency: schedule_params[:frequency],
            shift_type: schedule_params[:shift_type],
            date: schedule_params[:date],
            start_time: start_time,
            end_time: end_time,
            sort_index: schedule_params[:sort_index]
          )
        end

        def update_schedule_date(schedule, schedule_params, current_user_id)
          schedule.schedule_dates.where.not(date: schedule_params[:shift_dates]).destroy_all
          created_change = false
          schedule_params[:shift_dates].each do |date|
            schedule_date = schedule.schedule_dates.find_or_initialize_by(date: date)

            start_time = schedule_params[:start_time].present? ? schedule_params[:start_time] : nil
            end_time = schedule_params[:end_time].present? ? schedule_params[:end_time] : nil

            schedule_date.update!(
              start_time: start_time,
              end_time: end_time,
              scheduleable_type: 'Schedule'
            )

            schedule_date.create_change_histories(current_user_id) unless created_change # create 1 record change histories for care plan
            created_change = true
          end
        end

        def update_schedule_routines(schedule, schedule_params, current_user_id)
          schedule_id = schedule.id
          schedule.schedule_routines&.destroy_all
          schedule_params[:schedule_routines].each do |data|
            next unless data[:checked]

            routine = ScheduleRoutine.new(
              schedule_id: schedule_id,
              regis_day: data[:regis_day]
            )
            routine.save!
          end
        end

        def create_improvement_nursing_care_plans(care_plan_id, improvement_nursing_care_plans, care_plan_type, patient_type, user_admin_id)
          improvement_nursing_care_plans.each do |params|
            treatment_improvement_id = params[:treatment_improvement_id]
            if params[:id].present?
              improvement_nursing_care_plan = ImprovementNursingCarePlan.find(params[:id])
              improvement_nursing_care_plan.update(treatment_improvement_id: treatment_improvement_id)
              improvement_nursing_care_plan.create_change_histories(user_admin_id)
            else
              treatment_improvement = TreatmentImprovement.find_by(id: treatment_improvement_id, patient_type: patient_type)
              return false if treatment_improvement.blank?

              improvement_nursing_care_plan = ImprovementNursingCarePlan.new(
                care_plan_id: care_plan_id,
                treatment_improvement_id: treatment_improvement_id,
                care_plan_type: care_plan_type
              )

              ChangeHistory.create(
                user_admin_id: user_admin_id,
                changeable_id: care_plan_id,
                changeable_type: care_plan_type,
                changed_attribute: '処遇改善加算',
                before_change: '',
                after_change: treatment_improvement.name,
                date: Time.zone.today
              )
              improvement_nursing_care_plan.save!
            end
          end
        end
      end
    end
  end
end
