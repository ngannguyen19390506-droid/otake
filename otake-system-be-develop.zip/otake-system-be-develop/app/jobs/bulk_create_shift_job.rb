class BulkCreateShiftJob < ApplicationJob
  queue_as :default

  def perform(options)
    shift_registration_id = options[:shift_registration_id]
    staff_id = options[:staff_id]
    holiday_dates = options[:holiday_dates]
    start_month = options[:start_month]
    end_month = options[:end_month]

    (start_month..end_month).each do |date|
      next if holiday_dates.include?(date)

      create_params = { shift_date: date, shift_registration_id: shift_registration_id, start_time: '08:00', 
                        end_time: '17:00', create_type: 'admin'}
      sm = ShiftManagement.find_or_create_by(create_params)
      NursingShiftManage.find_or_create_by(nurse_id: staff_id, shift_id: sm.id)
    end
  end
end
