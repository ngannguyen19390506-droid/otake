module V1
  module Staff
    class MonthlyHolidayApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :monthly_holidays do
          desc 'POST api/v1/staff/monthly_holidays'
          params do
            requires :dates, type: Array[Date], message: I18n.t('errors.messages.blank')
            requires :status, type: String, values: MonthlyHoliday.statuses.keys, message: I18n.t('errors.messages.blank')
          end
          post do
            ActiveRecord::Base.transaction do
              current_date = Date.current
              beginning_next_month = current_date.at_beginning_of_month.next_month
              end_next_month = beginning_next_month.end_of_month
              # must between the 20th and the 25th of  month
              # valid_date_range = (current_date.at_beginning_of_month + 19.days)..(current_date.at_beginning_of_month + 24.days)
              # return error!({ 'message': I18n.t('errors.messages.invalid_date_range') }, UNPROCESSABLE_ENTITY) if valid_date_range.exclude?(current_date)

              monthly_holiday = current_staff.monthly_holidays.find_or_initialize_by(year_month: beginning_next_month.strftime('%Y/%m'))
              return error!({ 'message': I18n.t('errors.messages.cannot_modify_sent_holiday') }, UNPROCESSABLE_ENTITY) if monthly_holiday.sent?

              monthly_holiday.confirmed_by_staff = true if params[:status] == 'sent'
              is_update_status = monthly_holiday.status != params[:status]
              year_month = monthly_holiday.year_month

              if monthly_holiday.update(status: params[:status])
                monthly_holiday.holidays.destroy_all
                params[:dates].each do |date|
                  date = date.to_date
                  return error!({ 'message': I18n.t('errors.messages.invalid_holiday') }, UNPROCESSABLE_ENTITY) if (beginning_next_month..end_next_month).exclude?(date)

                  monthly_holiday.holidays.create(date: date, create_type: 'staff')
                end

                # Create notification
                create_noti(year_month) if is_update_status && params[:status] == 'sent'

                { success: I18n.t('success.messages.added') }
              else
                error!(monthly_holiday.error_messages, UNPROCESSABLE_ENTITY)
              end
            rescue StandardError => e
              error!({ errors: e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/staff/monthly_holidays'
          get do
            year_month = Date.current.next_month.at_beginning_of_month.strftime('%Y/%m')
            @monthly_holiday = current_staff.monthly_holidays.find_by(year_month: year_month)

            present @monthly_holiday
          end
        end
      end

      helpers do
        def noti_title year_month
          "タイトル：#{year_month}の休日申請を送信しました。"
        end

        def noti_content year_month
          "<p>#{year_month}の休日申請を送信しました。</p>
          <p>シフトの確認をお願いします。</p>
          <p>リンク先URL #{ENV['FE_APP_URL']}/admin/shift/shift_holiday</p>"
        end

        def create_noti year_month
          year_month = year_month.to_date.strftime('%Y年%m月')
          notification = Notification.create!(title: noti_title(year_month), content: noti_content(year_month),
                                            poster: current_staff.full_name, is_important: true, notify_type: 2,
                                            sender_id: current_staff.id, sender_type: current_staff.class.name)
          admin_ids = UserAdmin.all.pluck(:id)
          admin_ids.each do |uid|
            notification.mention_notifications.create!(m_id: uid, mention_type: 'UserAdmin')
          end
        end
      end
    end
  end
end
