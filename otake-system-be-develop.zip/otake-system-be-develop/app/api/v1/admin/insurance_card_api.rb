module V1
  module Admin
    class InsuranceCardApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :insurance_cards do
          # index
          desc 'GET /api/v1/admin/insurance_cards',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('insurance_card.error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @insurance_cards = patient.insurance_cards.default_order
            serialized_insurance_cards = @insurance_cards.map do |service|
              InsuranceCardSerializer.new(service, { use_conversion_methods: true }).as_json
            end
            present :serialized_insurance_cards, serialized_insurance_cards
          end

          desc 'POST api/v1/admin/insurance_cards',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('insurance_card.error.validate.blank')
            requires :insurance_name, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :start_insurance, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :end_insurance, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :insurance_company_number, type: Integer, message: I18n.t('insurance_card.error.validate.blank')
            optional :certification_department, values: InsuranceCard.certification_departments.keys
            optional :insurance_number, type: Integer
            optional :release_date, type: String
            optional :certification_date, type: String
            requires :start_validate, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :end_validate, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :care_level, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :home_care_office_type, type: String, values: InsuranceCard.home_care_office_types.keys,
                                             message: I18n.t('insurance_card.error.validate.blank')
            optional :home_care_office_input_first, type: String
            optional :home_care_office_input_second, type: String
            requires :care_application_start_date, type: String, message: I18n.t('insurance_card.error.validate.blank')
            optional :responsible_policy_management, type: String
            optional :comprehensive_support_center, type: String
            optional :announcement_date, type: String
            requires :benefit_limit, type: Float, message: I18n.t('insurance_card.error.validate.blank')
            requires :start_date_apply_benefits, type: String, message: I18n.t('insurance_card.error.validate.blank')
            optional :zipcode, type: String
            optional :city, type: String
            optional :district, type: String
            optional :street, type: String
            optional :home_care_support_office_name, type: String
          end

          post do
            existing_card = InsuranceCard.where(
              patient_id: params_insurance_card[:patient_id],
              insurance_name: params_insurance_card[:insurance_name],
              insurance_number: params_insurance_card[:insurance_number],
              start_insurance: params_insurance_card[:start_insurance],
              end_insurance: params_insurance_card[:end_insurance],
              insurance_company_number: params_insurance_card[:insurance_company_number],
              certification_department: params_insurance_card[:certification_department],
              release_date: params_insurance_card[:release_date],
              certification_date: params_insurance_card[:certification_date],
              start_validate: params_insurance_card[:start_validate],
              end_validate: params_insurance_card[:end_validate],
              care_level: params_insurance_card[:care_level],
              home_care_office_input_first: params_insurance_card[:home_care_office_input_first],
              care_application_start_date: params_insurance_card[:care_application_start_date],
              responsible_policy_management: params_insurance_card[:responsible_policy_management],
              comprehensive_support_center: params_insurance_card[:comprehensive_support_center],
              announcement_date: params_insurance_card[:announcement_date],
              benefit_limit: params_insurance_card[:benefit_limit]&.round(2),
              start_date_apply_benefits: params_insurance_card[:start_date_apply_benefits],
              home_care_office_type: params_insurance_card[:home_care_office_type],
              home_care_office_input_second: params_insurance_card[:home_care_office_input_second],
              zipcode: params_insurance_card[:zipcode],
              city: params_insurance_card[:city],
              district: params_insurance_card[:district],
              street: params_insurance_card[:street]
            )
            return error!({ message: I18n.t('errors.messages.already_exists') }, UNPROCESSABLE_ENTITY) if existing_card.present?

            insurance_card = InsuranceCard.new(params_insurance_card)
            if insurance_card.save
              { success: I18n.t('insurance_card.success.added') }
            else
              error!(insurance_card.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/insurance_cards/:id'
          params do
            requires :id, type: Integer
            requires :patient_id, type: Integer, message: I18n.t('insurance_card.error.validate.blank')
            requires :insurance_name, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :start_insurance, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :end_insurance, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :insurance_company_number, type: Integer, message: I18n.t('insurance_card.error.validate.blank')
            optional :certification_department, values: InsuranceCard.certification_departments.keys
            optional :insurance_number, type: Integer
            optional :release_date, type: String
            optional :certification_date, type: String
            requires :start_validate, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :end_validate, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :care_level, type: String, message: I18n.t('insurance_card.error.validate.blank')
            requires :home_care_office_type, type: String, values: InsuranceCard.home_care_office_types.keys,
                                             message: I18n.t('insurance_card.error.validate.blank')
            optional :home_care_office_input_first, type: String
            optional :home_care_office_input_second, type: String
            requires :care_application_start_date, type: String, message: I18n.t('insurance_card.error.validate.blank')
            optional :responsible_policy_management, type: String
            optional :comprehensive_support_center, type: String
            optional :announcement_date, type: String
            requires :benefit_limit, type: Float, message: I18n.t('insurance_card.error.validate.blank')
            requires :start_date_apply_benefits, type: String, message: I18n.t('insurance_card.error.validate.blank')
            optional :zipcode, type: String
            optional :city, type: String
            optional :district, type: String
            optional :street, type: String
            optional :home_care_support_office_name, type: String
          end
          put ':id' do
            insurance_card = InsuranceCard.find(params[:id])
            if insurance_card.update(params_insurance_card)
              { success: I18n.t('insurance_card.success.updated') }
            else
              error!(insurance_card.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Detail Insurance Card
          desc 'GET api/v1/admin/insurance_cards/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              @insurance_card = InsuranceCard.find(params[:id])
              present @insurance_card
            end
          end

          desc 'DELETE /api/v1/admin/insurance_cards/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
          end

          delete ':id' do
            InsuranceCard.find_by(id: params[:id])&.destroy
            { success: true }
          end
        end
      end

      helpers do
        def params_insurance_card
          params_insurance_card = params.slice(
            :patient_id, :insurance_name, :insurance_number, :start_insurance, :end_insurance,
            :insurance_company_number, :certification_department, :release_date, :certification_date,
            :start_validate, :end_validate, :care_level, :home_care_office_type, :home_care_office_input_first,
            :home_care_office_input_second, :care_application_start_date,
            :responsible_policy_management, :comprehensive_support_center,
            :announcement_date, :benefit_limit, :start_date_apply_benefits,
            :zipcode, :city, :district, :street, :home_care_support_office_name
          )
          params_insurance_card[:start_insurance] = convert_date(params_insurance_card[:start_insurance]) if params_insurance_card[:start_insurance].present?
          params_insurance_card[:end_insurance] = convert_date(params_insurance_card[:end_insurance]) if params_insurance_card[:end_insurance].present?
          params_insurance_card[:release_date] = convert_date(params_insurance_card[:release_date]) if params_insurance_card[:release_date].present?
          params_insurance_card[:certification_date] = convert_date(params_insurance_card[:certification_date]) if params_insurance_card[:certification_date].present?
          params_insurance_card[:start_validate] = convert_date(params_insurance_card[:start_validate]) if params_insurance_card[:start_validate].present?
          params_insurance_card[:end_validate] = convert_date(params_insurance_card[:end_validate]) if params_insurance_card[:end_validate].present?
          params_insurance_card[:care_application_start_date] = convert_date(params_insurance_card[:care_application_start_date]) if params_insurance_card[:care_application_start_date].present?
          params_insurance_card[:announcement_date] = convert_date(params_insurance_card[:announcement_date]) if params_insurance_card[:announcement_date].present?
          params_insurance_card[:start_date_apply_benefits] = convert_date(params_insurance_card[:start_date_apply_benefits]) if params_insurance_card[:start_date_apply_benefits].present?
          params_insurance_card
        end
      end
    end
  end
end
