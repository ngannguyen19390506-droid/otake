module V1
  module AdminHomeSystem
    class ScheduleMemoAtHomeSerializer < ActiveModel::Serializer
      attributes :id,
                 :content

      has_many :schedule_date_at_homes, serializer: ScheduleDateAtHomeSerializer
    end
  end
end
