class CreatePayment < ActiveRecord::Migration[7.0]
  def change
    create_table :payments do |t|
      t.references :patient,             null: false, foreign_key: true
      t.integer    :payment_method,      null: false, limit: 1
      t.integer    :account_number,      null: false
      t.string     :bank_name,           null: false
      t.string     :branch_name,         null: false
      t.integer    :account_type,        null: false, limit: 1
      t.string     :account_name_kana,   null: false
      t.integer    :account_number_kana, null: false
      t.string     :payment_address,     null: false
      t.string     :zipcode,             null: false
      t.string     :state,               null: false
      t.string     :city,                null: false
      t.string     :street,              null: false
      t.string     :house_no,            null: false
      t.float      :amount,              null: false

      t.timestamps
    end
  end
end
