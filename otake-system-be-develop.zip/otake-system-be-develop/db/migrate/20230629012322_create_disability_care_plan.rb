class CreateDisabilityCarePlan < ActiveRecord::Migration[7.0]
  def change
    create_table :disability_care_plans do |t|
      t.references :patient,                     null: false, foreign_key: true
      t.references :service,                     null: false, foreign_key: true
      t.string     :comprehensive_aid_policy,    null: false
      t.string     :individual_family_intention, null: false
      t.string     :aid_purpose,                 null: false

      t.timestamps
    end
  end
end
