module V1
  module Client
    class ScheduleApi < V1::AppApi
      before { authenticate!(Patient, :patient_code) }

      namespace :client do
        resources :schedules do
          desc 'GET api/v1/client/schedule/summary'
          params do
            optional :year_month, type: String
            optional :week_start_date, type: String
            optional :week_end_date, type: String
            optional :specific_date, type: String
          end
          get :summary do
            year_month = if params[:year_month].present?
                           Date.parse(params[:year_month]).strftime('%Y/%m')
                         elsif params[:week_start_date].present? && params[:week_end_date].present?
                           Date.parse(params[:week_start_date]).strftime('%Y/%m')
                         elsif params[:specific_date]
                           Date.parse(params[:specific_date]).strftime('%Y/%m')
                         end
            monthly_holidays = MonthlyHoliday.where(year_month: year_month, status: 'approved')
            return { data: {} } if monthly_holidays.blank?

            if params[:year_month].present?
              { data: get_schedule_by_year_month(params[:year_month]) }
            elsif params[:week_start_date].present? && params[:week_end_date].present?
              { data: get_schedule_by_week(params[:week_start_date], params[:week_end_date]) }
            elsif params[:specific_date].present?
              { data: get_schedule_by_specific_date(convert_date(params[:specific_date])) }
            end
          end
        end
      end

      helpers do
        def get_schedule_by_year_month(year_month)
          year_month_date = Date.strptime(year_month, "%Y/%m")
          beginning_of_month = year_month_date.beginning_of_month
          end_of_month = year_month_date.end_of_month
          schedule_dates = current_staff.schedule_dates.where(schedule_dates: { date: beginning_of_month..end_of_month, status: 'sent' }).group_by(&:date)

          data = {}
          schedule_dates.each do |date, dates|
            data[date] = dates.map { |schedule_date| schedule_date.scheduleable.service_type.detail }.uniq
          end

          data
        end

        def get_schedule_by_week(week_start_date, week_end_date)
          week_start_date = convert_date(params[:week_start_date])
          week_end_date = convert_date(params[:week_end_date])
          schedules = current_staff.schedules.includes(:schedule_dates)
                                            .for_week(week_start_date, week_end_date)
                                            .where(schedule_dates: { status: 'sent' })
          data = {}
          schedules.each do |schedule|
            schedule.schedule_dates.each do |schedule_date|
              date = schedule_date.date.to_s
              time_range, nurse_name, service_name = get_detail_schedule(schedule, schedule_date)
              data[date] ||= []
              data[date] << { nurse_name: nurse_name, time_range: time_range, service_name: service_name }
            end
          end

          data
        end

        def get_schedule_by_specific_date(specific_date)
          data = {}
          schedules = current_staff.schedules.includes(:schedule_dates).for_date(specific_date).where(schedule_dates: { status: 'sent' })
          schedules.each do |schedule|
            schedule.schedule_dates.each do |schedule_date|
              time_range, nurse_name, service_name = get_detail_schedule(schedule, schedule_date)
              data[service_name] ||= []
              data[service_name] << { time_range: time_range, nurse_name: nurse_name, service_name: service_name, patient_name: current_client.family_name }
            end
          end

          data
        end

        def get_detail_schedule(schedule, schedule_date)
          time_range = "#{schedule_date.start_time} ~ #{schedule_date.end_time}"
          nurse_name = schedule_date.nurse&.family_name
          service_name = schedule.service_type.detail

          [time_range, nurse_name, service_name]
        end
      end
    end
  end
end

