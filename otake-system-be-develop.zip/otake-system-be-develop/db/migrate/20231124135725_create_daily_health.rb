class CreateDailyHealth < ActiveRecord::Migration[7.0]
  def change
    create_table :daily_healths do |t|
      t.references :care_plan_at_home, null: false, foreign_key: true
      t.string :body_temperature_first # 体温 2
      t.string :body_temperature_second
      t.string :blood_pressure_first # 血圧 4
      t.string :blood_pressure_second
      t.string :blood_pressure_third
      t.string :blood_pressure_fourth
      t.string :pulse_first # 脈拍 2
      t.string :pulse_second
      t.string :oxygen_first # 酸素 2
      t.string :oxygen_second
      t.string :bathing # 入浴
      t.string :wiping # 清拭
      t.date :date

      t.timestamps
    end
  end
end
