class CreateUserHomeSystem < ActiveRecord::Migration[7.0]
  def change
    create_table :user_home_systems do |t|
      t.string :encrypted_password, null: false
      t.string :user_code, null: false
      t.string :user_name
      t.integer :user_type, null: false

      t.timestamps
    end

    add_index :user_home_systems, :user_code, unique: true
    add_reference :authentication_tokens, :user_home_system, foreign_key: true
  end
end
