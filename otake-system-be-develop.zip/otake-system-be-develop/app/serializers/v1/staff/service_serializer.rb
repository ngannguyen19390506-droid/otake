module V1
  module Staff
    class ServiceSerializer < ActiveModel::Serializer
      attributes :id, :service_code, :service_name, :unit_price
    end
  end
end
