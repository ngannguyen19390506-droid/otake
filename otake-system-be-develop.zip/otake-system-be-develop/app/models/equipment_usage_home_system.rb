# == Schema Information
#
# Table name: equipment_usage_home_systems
#
#  id                       :bigint           not null, primary key
#  date                     :date             not null
#  quantity                 :integer          not null
#  created_at               :datetime         not null
#  updated_at               :datetime         not null
#  equipment_home_system_id :bigint           not null
#
# Indexes
#
#  index_equipment_usage_home_systems_on_equipment_home_system_id  (equipment_home_system_id)
#
# Foreign Keys
#
#  fk_rails_...  (equipment_home_system_id => equipment_home_systems.id)
#
class EquipmentUsageHomeSystem < ApplicationRecord
  include ApiCommon
  belongs_to :equipment_home_system

  validates :date, :quantity, presence: true
end
