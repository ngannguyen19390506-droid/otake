module V1
  module Admin
    class DashboardApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :dashboard do
          desc 'GET api/v1/admin/dashboard',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :year_month, type: String, desc: '2024/03'
          end
          get do
            current_user_id = @current_user.id
            objects = Notification.noti_by_admin.patient_exists
                                  .or(Notification.noti_by_staff.patient_exists)
            objects = objects.where('deployment_date >= ?', Time.current.to_date)
            objects = objects.distinct.by_deployment_date_asc.limit(10)
            serialized_nofitications = objects.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            rooms = Room.admin_room_owner(current_user_id)
                        .only_unread(true, current_user_id)
                        .distinct.by_created_at_desc.limit(10)
            serialized_rooms = rooms.map do |room|
              RoomSerializer.new(room, { params: { current_uid: current_user_id } }).as_json
            end

            rooms_unread_count = serialized_rooms.count
            year_month = params[:year_month]
            shifts_calendar = get_patient_calendar_data(year_month)
            present :notifications, serialized_nofitications
            present :rooms, serialized_rooms
            present :rooms_unread_count, rooms_unread_count
            present :shifts_calendar, shifts_calendar
          end
        end
      end

      helpers do

      end
    end
  end
end
