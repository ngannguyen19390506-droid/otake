class RemoveColumnsFromHolidays < ActiveRecord::Migration[7.0]
  def change
    add_reference :holidays, :monthly_holiday, foreign_key: true

    remove_column :holidays, :approved_by
    remove_column :holidays, :content
    remove_column :holidays, :end_time
    remove_column :holidays, :registered
    remove_column :holidays, :start_time
    remove_column :holidays, :nurse_id
  end
end
