# == Schema Information
#
# Table name: patient_receipts
#
#  id         :bigint           not null, primary key
#  registered :boolean          default(FALSE), not null
#  year_month :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  patient_id :integer          not null
#
class PatientReceipt < ApplicationRecord
  has_many :receipts
  belongs_to :patient
end
