module V1
  module Staff
    class DisabilityCarePlanApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :disability_care_plans do
          desc 'get api/v1/staff/disability_care_plans',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('disability_care_plan.error.validate.blank')
            requires :year_month, type: String, message: I18n.t('disability_care_plan.error.validate.blank')
          end
          get do
            begin
              patient = Patient.find_by(id: params[:patient_id])
              return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

              @disability_care_plan = patient.disability_care_plans.find_by(year_month: params[:year_month])
              if @disability_care_plan.blank?
                return error!({ 'messages': I18n.t('errors.messages.master_side_not_created_yet') },
                              NOT_FOUND)
              end

              present @disability_care_plan
            end
          end
        end
      end
    end
  end
end
