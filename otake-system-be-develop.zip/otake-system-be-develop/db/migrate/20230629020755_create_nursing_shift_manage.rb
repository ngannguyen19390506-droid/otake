class CreateNursingShiftManage < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_shift_manages do |t|
      t.references :nurse, null: false, foreign_key: { to_table: :nursing_staffs }
      t.references :shift, null: false, foreign_key: { to_table: :shift_managements }

      t.timestamps
    end
  end
end
