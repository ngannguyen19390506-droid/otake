module V1
  module Staff
    class DashboardApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :dashboard do
          desc 'GET api/v1/staff/dashboard',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :date, type: String, desc: '2024/05/10'
          end
          get do
            current_staff_id = current_staff.id
            objects = Notification.noti_by_admin.patient_exists
                                  .or(Notification.noti_by_staff.patient_exists)
            objects = objects.where('deployment_date >= ?', Time.current.to_date)
            objects = objects.distinct.by_deployment_date_asc.limit(10)
            serialized_nofitications = objects.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            rooms = Room.room_owner(current_staff_id)
                        .staff_only_unread(true, current_staff_id)
                        .distinct.by_created_at_desc.limit(10)
            serialized_rooms = rooms.map do |room|
              RoomSerializer.new(room, { params: { current_uid: current_staff_id } }).as_json
            end

            date = params[:date]
            error!({ 'messages': I18n.t('patient.error.validate.blank') }, UNPROCESSABLE_ENTITY) if date.blank?

            rooms_unread_count = serialized_rooms.count
            shifts_calendar = get_patient_schedules(date)

            present :notifications, serialized_nofitications
            present :rooms, serialized_rooms
            present :rooms_unread_count, rooms_unread_count
            present :shifts_calendar, shifts_calendar
          end

          desc 'GET /api/v1/staff/dashboard/shifts-list',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer
            requires :date, type: String, desc: '2024/05/10'
          end
          get 'shifts-list' do
            patient = Patient.find(params[:patient_id])
            date = params[:date].to_date
            schedule_dates = patient.schedule_dates.where(date: date, nurse_id: current_staff.id)
            schedule_dates_objects = schedule_dates.map do |schedule|
              ScheduleDateSerializer.new(schedule).as_json
            end
            present :schedule_dates, schedule_dates_objects
          end
        end
      end

      helpers do

      end
    end
  end
end
