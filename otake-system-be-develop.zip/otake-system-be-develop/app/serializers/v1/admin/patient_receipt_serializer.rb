module V1
  module Admin
    class PatientReceiptSerializer < ActiveModel::Serializer
      attributes :id,
                 :year_month,
                 :registered

      belongs_to :patient, serializer: PatientSerializer
      has_many :receipts, serializer: ReceiptSerializer
    end
  end
end
