module V1
  module AdminHomeSystem
    class ServiceHomeSystemApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resources :service_home_systems do
          desc 'GET /api/v1/admin_home_system/service_home_systems'
          params do
          end
          get do
            serialized_service_home_systems = ServiceHomeSystem.order(:position).map do |service|
              ServiceHomeSystemSerializer.new(service).as_json
            end
            present :data, serialized_service_home_systems
          end

          desc 'POST /api/v1/admin_home_system/service_home_systems'
          params do
            requires :service_name, type: String, message: I18n.t('error.validate.blank')
            requires :display_name, type: String, message: I18n.t('error.validate.blank')
            requires :selection_method, type: String, values: ServiceHomeSystem.selection_methods.keys, message: I18n.t('error.validate.blank')
            optional :dropdown_values, type: Array[String]
          end
          post do
            service_home_system = ServiceHomeSystem.new(params_service_home_system)
            if service_home_system.save
              { success: I18n.t('success.messages.added') }
            else
              error!(service_home_system.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin_home_system/service_home_systems/update_positions'
          params do
            requires :records, type: Array do
              requires :id, type: Integer
              requires :position, type: Integer
            end
          end
          put :update_positions do
            ActiveRecord::Base.transaction do
              params[:records].each do |record_params|
                service_home_system = ServiceHomeSystem.find_by(id: record_params[:id])
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_home_system.blank?

                service_home_system.update(position: record_params[:position])
              end
              positions = ServiceHomeSystem.pluck(:position)
              return error!({ 'messages': I18n.t('equipment_service.error.duplicate_positions') }, UNPROCESSABLE_ENTITY) if positions != positions.uniq

              { success: I18n.t('success.messages.updated') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin_home_system/service_home_systems'
          params do
            requires :id, type: Integer
            optional :service_name, type: String
            optional :display_name, type: String
            optional :selection_method, type: String, values: ServiceHomeSystem.selection_methods.keys
            optional :dropdown_values, type: Array[String]
          end
          put ':id' do
            service_home_system = ServiceHomeSystem.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_home_system.blank?

            if service_home_system.update(params_service_home_system)
              { success: I18n.t('success.messages.updated') }
            else
              error!(service_home_system.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin_home_system/service_home_systems/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            service_home_system = ServiceHomeSystem.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_home_system.blank?

            present service_home_system
          end
        end
      end

      helpers do
        def params_service_home_system
          params.slice(:service_name, :display_name, :selection_method, :dropdown_values)
        end
      end
    end
  end
end
