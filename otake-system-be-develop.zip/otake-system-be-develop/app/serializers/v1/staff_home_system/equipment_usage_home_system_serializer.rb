module V1
  module StaffHomeSystem
    class EquipmentUsageHomeSystemSerializer < ActiveModel::Serializer
      attributes :id,
                 :date,
                 :quantity,
                 :equipment_home_system_id

      belongs_to :equipment_home_system, serializer: EquipmentHomeSystemSerializer
    end
  end
end
