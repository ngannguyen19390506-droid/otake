module V1
  module Staff
    class TreatmentImprovementApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }
      namespace :staff do
        resources :treatment_improvements do
          # index treatment_improvements
          desc 'GET /api/v1/staff/treatment_improvements?patient_type=normal ||
          /api/v1/staff/treatment_improvements?patient_type=disability'
          params do
            requires :patient_type, type: String, message: I18n.t('treatment_improvement.error.validate.blank'),
                                    values: TreatmentImprovement.patient_types.keys
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
          end
          get do
            @query = TreatmentImprovement.where(patient_type: params[:patient_type])
            return present :data, @query.default_order if params[:get_all] == true

            page = (params[:page].presence || 1).to_i
            @treatment_improvements = @query.default_order
            if params[:sortKey].present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              @treatment_improvements = @query.order(params[:sortKey] => sort_order)
            end
            @treatment_improvements = @treatment_improvements.page(page).per(params[:per])
            serialized_treatment_improvements = @treatment_improvements.map do |treatment_improvement|
              TreatmentImprovementSerializer.new(treatment_improvement).as_json
            end
            present :page, page
            present :total_items, @treatment_improvements.total_count
            present :total_pages, @treatment_improvements.total_pages
            present :serialized_treatment_improvements, serialized_treatment_improvements
          end

          # Get treatment_improvements detail
          desc 'GET api/v1/staff/treatment_improvements/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            @treatment_improvement = TreatmentImprovement.find(params[:id])
            present @treatment_improvement
          end
        end
      end
    end
  end
end
