# == Schema Information
#
# Table name: user_admins
#
#  id                     :bigint           not null, primary key
#  email                  :string           default("")
#  encrypted_password     :string           default(""), not null
#  remember_created_at    :datetime
#  reset_password_sent_at :datetime
#  reset_password_token   :string
#  user_code              :string
#  user_name              :string
#  created_at             :datetime         not null
#  updated_at             :datetime         not null
#
# Indexes
#
#  index_users_on_reset_password_token  (reset_password_token) UNIQUE
#  index_users_on_user_code             (user_code) UNIQUE
#
class UserAdmin < ApplicationRecord
  include ApiCommon
  has_many :authentication_tokens, dependent: :destroy
  has_many :messages, as: :sender, dependent: :destroy
  has_many :rooms, dependent: :destroy, class_name: 'Room', foreign_key: 'source_id'
  has_many :notifications, dependent: :destroy

  VALID_RESET_PW_TOKEN_TIME = 15.minutes.to_i

  def generate_reset_password_token
    raw, hashed = Devise.token_generator.generate(UserAdmin, :reset_password_token)
    self.reset_password_token = hashed
    self.reset_password_sent_at = Time.current
    save
    raw
  end

  def self.ransackable_attributes(_auth_object = nil)
    attribute_names
  end

  def self.ransackable_associations(auth_object = nil); end
end
