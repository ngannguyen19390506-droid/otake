# == Schema Information
#
# Table name: rent_billings
#
#  id           :bigint           not null, primary key
#  food_cost    :bigint
#  living_cost  :bigint
#  refund_cost  :bigint
#  rent_cost    :bigint
#  utility_cost :bigint
#  year_month   :string
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#  patient_id   :integer
#
class RentBilling < ApplicationRecord
  belongs_to :patient, foreign_key: :patient_id
end
