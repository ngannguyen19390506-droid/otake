class ChangeColumnNameEvalueTwo < ActiveRecord::Migration[7.0]
  def change
    remove_column :evalue_twos, :staple_food
    remove_column :evalue_twos, :side_meal
    remove_column :evalue_twos, :toromi
    remove_column :evalue_twos, :support
    remove_column :evalue_twos, :eating_utensil
    remove_column :evalue_twos, :luxury_goods
    remove_column :evalue_twos, :is_allergic
    remove_column :evalue_twos, :neck
    remove_column :evalue_twos, :upper_limb
    remove_column :evalue_twos, :belt
    remove_column :evalue_twos, :hip_joint
    remove_column :evalue_twos, :bottom
    remove_column :evalue_twos, :sight
    remove_column :evalue_twos, :glasses
    remove_column :evalue_twos, :hearing
    remove_column :evalue_twos, :language
    remove_column :evalue_twos, :form_movement
    remove_column :evalue_twos, :move
    remove_column :evalue_twos, :stand
    remove_column :evalue_twos, :sit
    remove_column :evalue_twos, :wash_face
    remove_column :evalue_twos, :head_washing
    remove_column :evalue_twos, :removable
    remove_column :evalue_twos, :grooming
    remove_column :evalue_twos, :excretory_form
    remove_column :evalue_twos, :is_urgent_urination
    remove_column :evalue_twos, :is_benefit
    remove_column :evalue_twos, :is_incontinence
    remove_column :evalue_twos, :is_crushing_process
    remove_column :evalue_twos, :swallow
    remove_column :evalue_twos, :dentures
    remove_column :evalue_twos, :recognition
    remove_column :evalue_twos, :declaration_intent
    remove_column :evalue_twos, :understanding
    remove_column :evalue_twos, :is_wandering
    remove_column :evalue_twos, :is_violence
    remove_column :evalue_twos, :is_delusion
    remove_column :evalue_twos, :is_denial
    remove_column :evalue_twos, :is_treatment
    remove_column :evalue_twos, :dosage
    remove_column :evalue_twos, :is_toromi
    remove_column :evalue_twos, :support_level
    remove_column :evalue_twos, :allergic
    remove_column :evalue_twos, :is_disability_sight
    remove_column :evalue_twos, :has_glasses
    remove_column :evalue_twos, :is_disability_hearing
    remove_column :evalue_twos, :is_disability_language
    remove_column :evalue_twos, :move_level
    remove_column :evalue_twos, :stand_level
    remove_column :evalue_twos, :sit_level
    remove_column :evalue_twos, :wash_face_level
    remove_column :evalue_twos, :head_washing_level
    remove_column :evalue_twos, :removable_level
    remove_column :evalue_twos, :grooming_level
    remove_column :evalue_twos, :urgent_urination_excretion
    remove_column :evalue_twos, :benefit_excretion
    remove_column :evalue_twos, :allergic_excretion
    remove_column :evalue_twos, :crushing_process
    remove_column :evalue_twos, :is_normal_swallow
    remove_column :evalue_twos, :cognitive_level
    remove_column :evalue_twos, :is_possible_declaration_intent
    remove_column :evalue_twos, :is_possible_understanding
    remove_column :evalue_twos, :wandering
    remove_column :evalue_twos, :violence
    remove_column :evalue_twos, :delusion
    remove_column :evalue_twos, :denial
    remove_column :evalue_twos, :treatment
    remove_column :evalue_twos, :dosage_level
    remove_column :evalue_twos, :staple_food_option
    remove_column :evalue_twos, :side_meal_option
    remove_column :evalue_twos, :eating_utensil_option
    remove_column :evalue_twos, :luxury_goods_option
    remove_column :evalue_twos, :neck_option
    remove_column :evalue_twos, :upper_limb_option
    remove_column :evalue_twos, :belt_option
    remove_column :evalue_twos, :hip_joint_option
    remove_column :evalue_twos, :bottom_option
    remove_column :evalue_twos, :form_movement_option
    remove_column :evalue_twos, :excretory_form_option
    remove_column :evalue_twos, :dentures_option

    # Tạo các cột mới
    add_column :evalue_twos, :staple_food_opt, :text
    add_column :evalue_twos, :staple_food_txt, :text
    add_column :evalue_twos, :side_dish_opt, :text
    add_column :evalue_twos, :side_dish_txt, :text
    add_column :evalue_twos, :thoromi_opt, :integer
    add_column :evalue_twos, :thoromi_txt, :text
    add_column :evalue_twos, :assistance_opt, :integer
    add_column :evalue_twos, :assistance_txt, :text
    add_column :evalue_twos, :tool_opt, :text
    add_column :evalue_twos, :tool_txt, :text
    add_column :evalue_twos, :hobby_goods_opt, :text
    add_column :evalue_twos, :hobby_goods_txt, :text
    add_column :evalue_twos, :allergy_opt, :integer
    add_column :evalue_twos, :allergy_txt, :text
    add_column :evalue_twos, :head_opt, :text
    add_column :evalue_twos, :head_txt, :text
    add_column :evalue_twos, :upper_limbs_opt, :text
    add_column :evalue_twos, :upper_limbs_txt, :text
    add_column :evalue_twos, :waist_opt, :text
    add_column :evalue_twos, :waist_txt, :text
    add_column :evalue_twos, :hip_joint_opt, :text
    add_column :evalue_twos, :hip_joint_txt, :text
    add_column :evalue_twos, :lower_limbs_opt, :text
    add_column :evalue_twos, :lower_limbs_txt, :text
    add_column :evalue_twos, :eyesight_opt, :integer
    add_column :evalue_twos, :eyesight_txt, :text
    add_column :evalue_twos, :glasses_opt, :integer
    add_column :evalue_twos, :glasses_txt, :text
    add_column :evalue_twos, :hearing_opt, :integer
    add_column :evalue_twos, :hearing_txt, :text
    add_column :evalue_twos, :language_opt, :integer
    add_column :evalue_twos, :language_txt, :text
    add_column :evalue_twos, :morphology_opt, :text
    add_column :evalue_twos, :morphology_txt, :text
    add_column :evalue_twos, :move_opt, :integer
    add_column :evalue_twos, :move_txt, :text
    add_column :evalue_twos, :standing_position_opt, :integer
    add_column :evalue_twos, :standing_position_txt, :text
    add_column :evalue_twos, :seat_opt, :integer
    add_column :evalue_twos, :seat_txt, :text
    add_column :evalue_twos, :wash_body_opt, :integer
    add_column :evalue_twos, :wash_body_txt, :text
    add_column :evalue_twos, :hair_washing_opt, :integer
    add_column :evalue_twos, :hair_washing_txt, :text
    add_column :evalue_twos, :attaching_and_detaching_opt, :integer
    add_column :evalue_twos, :attaching_and_detaching_txt, :text
    add_column :evalue_twos, :plastic_surgery_opt, :integer
    add_column :evalue_twos, :plastic_surgery_txt, :text
    add_column :evalue_twos, :excretion_form_opt, :text
    add_column :evalue_twos, :excretion_form_txt, :text
    add_column :evalue_twos, :urge_to_urinate_opt, :integer
    add_column :evalue_twos, :urge_to_urinate_txt, :text
    add_column :evalue_twos, :convenience_opt, :integer
    add_column :evalue_twos, :convenience_txt, :text
    add_column :evalue_twos, :incontinence_opt, :integer
    add_column :evalue_twos, :incontinence_txt, :text
    add_column :evalue_twos, :chew_opt, :integer
    add_column :evalue_twos, :chew_txt, :text
    add_column :evalue_twos, :swallowing_opt, :integer
    add_column :evalue_twos, :swallowing_txt, :text
    add_column :evalue_twos, :denture_opt, :text
    add_column :evalue_twos, :denture_txt, :text
    add_column :evalue_twos, :understanding_opt, :integer
    add_column :evalue_twos, :understanding_txt, :text
    add_column :evalue_twos, :expression_of_meaning_opt, :integer
    add_column :evalue_twos, :expression_of_meaning_txt, :text
    add_column :evalue_twos, :understand_opt, :integer
    add_column :evalue_twos, :understand_txt, :text
    add_column :evalue_twos, :wander_opt, :integer
    add_column :evalue_twos, :wander_txt, :text
    add_column :evalue_twos, :violence_opt, :integer
    add_column :evalue_twos, :violence_txt, :text
    add_column :evalue_twos, :delusion_opt, :integer
    add_column :evalue_twos, :delusion_txt, :text
    add_column :evalue_twos, :rejection_opt, :integer
    add_column :evalue_twos, :rejection_txt, :text
    add_column :evalue_twos, :treatment_opt, :integer
    add_column :evalue_twos, :treatment_txt, :text
    add_column :evalue_twos, :dosage_opt, :integer
    add_column :evalue_twos, :dosage_txt, :text
  end
end
