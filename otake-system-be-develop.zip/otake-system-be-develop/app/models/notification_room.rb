# == Schema Information
#
# Table name: notification_rooms
#
#  id            :bigint           not null, primary key
#  receiver_type :string
#  sender_type   :string
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#  receiver_id   :integer
#  sender_id     :bigint           not null
#
class NotificationRoom < ApplicationRecord
  has_many :message_notifications, dependent: :destroy
end
