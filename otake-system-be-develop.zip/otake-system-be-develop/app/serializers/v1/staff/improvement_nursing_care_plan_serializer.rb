module V1
  module Staff
    class ImprovementNursingCarePlanSerializer < ActiveModel::Serializer
      attributes :id, :treatment_improvement_id
    end
  end
end
