class UpdateToChangeHistory < ActiveRecord::Migration[7.0]
  def change
    change_column_null :change_histories, :after_change, true
    change_column_null :change_histories, :before_change, true
  end
end
