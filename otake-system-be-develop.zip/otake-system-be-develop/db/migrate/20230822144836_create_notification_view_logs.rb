class CreateNotificationViewLogs < ActiveRecord::Migration[7.0]
  def change
    create_table :notification_view_logs do |t|
      t.references :notification, null: false

      t.timestamps
    end
  end
end
