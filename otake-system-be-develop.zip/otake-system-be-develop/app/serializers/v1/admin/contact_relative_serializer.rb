module V1
  module Admin
    class ContactRelativeSerializer < ActiveModel::Serializer
      attributes :id, :name, :relationship, :cellphone_number, :telephone_number, :address
    end
  end
end
