module V1
  class NotificationCategoryApi < V1::AppApi
    desc 'GET api/v1/notification_category'
    get :notification_categories do
      objects = NotificationCategory.all

      data = objects.map do |category|
        {
          id: category.id,
          name: category.name
        }
      end

      { objects: data }
    end
  end
end
