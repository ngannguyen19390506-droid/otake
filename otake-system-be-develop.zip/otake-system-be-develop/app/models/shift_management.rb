# == Schema Information
#
# Table name: shift_managements
#
#  id                    :bigint           not null, primary key
#  create_type           :integer
#  end_time              :string
#  previous_data         :json
#  shift_date            :date             not null
#  start_time            :string
#  status                :integer          default("initial")
#  created_at            :datetime         not null
#  updated_at            :datetime         not null
#  shift_registration_id :string
#
class ShiftManagement < ApplicationRecord
  has_many :service_shift_manages, foreign_key: :shift_id, dependent: :destroy
  has_many :service_type_shift_manages, foreign_key: :shift_id, dependent: :destroy
  has_many :nursing_shift_manages, foreign_key: :shift_id, dependent: :destroy
  has_many :patient_shift_manages, foreign_key: :shift_id, dependent: :destroy
  has_many :services, through: :service_shift_manages
  has_many :service_types, through: :service_type_shift_manages
  has_many :patients, through: :patient_shift_manages
  has_many :nurses, class_name: 'NursingStaff', through: :nursing_shift_manages

  validates :shift_date, :start_time, :end_time, presence: true

  enum create_type: { staff: 1, admin: 2 }
  # support for staff edit shift
  enum status: { initial: 0, draft: 1, sent: 2 }
end
