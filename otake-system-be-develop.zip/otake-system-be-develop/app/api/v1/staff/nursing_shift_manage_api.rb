module V1
  module Staff
    class NursingShiftManageApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :nursing_shift_manages do
          desc 'GET api/v1/staff/nursing_shift_manages/summary'
          params do
            optional :month_date, type: String
            optional :week_start_date, type: Date
            optional :week_end_date, type: Date
            optional :specific_date, type: Date
          end
          get :summary do
            V1::Staff::NursingShiftManages::GetNursingShiftSummary.call(params, current_staff)
          end

          desc 'GET api/v1/staff/nursing_shift_manages/next_month_shift_status'
          get :next_month_shift_status do
            next_month = Date.current.next_month
            year_month = next_month.strftime('%Y/%m')
            start_date = next_month.beginning_of_month
            end_date = next_month.end_of_month
            nursing_shift_manage = current_staff.nursing_shift_manages.includes(:shift)
                                                .where(status: ['sent', 'approved'], shift: { shift_date: (start_date..end_date) })
            monthly_holiday = current_staff.monthly_holidays.find_by(year_month: year_month)
            show_item_noti = monthly_holiday.blank? || monthly_holiday&.draft? || monthly_holiday&.approved? ||
                             (monthly_holiday&.sent? && monthly_holiday&.confirmed_by_admin) || shift_changed()

            { monthly_holiday: monthly_holiday, next_month_shift_request: nursing_shift_manage.present?, show_item_noti: show_item_noti }
          end

          desc 'GET api/v1/staff/nursing_shift_manages'
          params do
            optional :year_month, type: String, desc: 'Eg: 2024/02'
          end
          get do
            result = V1::Staff::NursingShiftManages::GetNursingShiftDetail.call(current_staff, params)
            if result.success?
              {
                data: result.success
              }
            else
              error!(result.failure, 422)
            end
          end

          # desc 'POST api/v1/staff/nursing_shift_manages'
          # params do
          #   requires :nurse_id, type: Integer
          #   requires :shift_id, type: String
          #   requires :shift_date, type: String
          #   requires :start_time, type: String
          #   requires :end_time, type: String
          # end
          # post do
          #   result = V1::AdjustNursingShiftManage.call(params)
          #   if result.success?
          #     {
          #       month: params[:current_shift_date].to_date.strftime('%Y%m'),
          #       data: result.success
          #     }
          #   else
          #     error!(result.failure, 422)
          #   end
          # end

          desc 'PUT api/v1/staff/nursing_shift_manages'
          params do
            optional :id, type: Integer
            optional :date, type: String
            optional :start_time, type: String
            optional :end_time, type: String
            optional :revert_change, type: Boolean
          end
          put do
            # check_nursing_shift_manage_confirmation
            if params[:id].blank?
              date = convert_date(params[:date])
              start_time = params[:start_time]
              end_time = params[:end_time]
              check_for_overlapping_shifts(date, start_time, end_time, nil)
              sm = ShiftManagement.create!(start_time: params[:start_time],
                                            end_time: params[:end_time],
                                            shift_date: params[:date])
              shift = NursingShiftManage.create(nurse_id: current_staff.id, shift_id: sm.id)
              return { success: I18n.t('success.messages.updated'), shift: shift }
            end
            ActiveRecord::Base.transaction do
              nursing_shift_manage = NursingShiftManage.find(params[:id])
              shift = nursing_shift_manage.shift
              shift.update(shift.previous_data) if params[:revert_change] && shift.previous_data.present?
              date = params[:revert_change] ? shift.shift_date : convert_date(params[:date])
              start_time = params[:revert_change] ? shift.start_time : params[:start_time]
              end_time = params[:revert_change] ? shift.end_time : params[:end_time]
              check_for_overlapping_shifts(date, start_time, end_time, shift.id)
              if shift.previous_data.blank? && (shift.shift_date != date || shift.start_time != start_time || shift.end_time != end_time)
                shift.previous_data = shift.attributes
              elsif nursing_shift_manage.status == 'initial' && params[:revert_change]
                shift.destroy
                shift_destroyed = true
              end
              if shift_destroyed || shift.update(shift_date: date, start_time: start_time, end_time: end_time)
                { success: I18n.t('success.messages.updated') }
              else
                error!({ errors: shift.error_messages }, UNPROCESSABLE_ENTITY)
              end
            rescue StandardError => e
              e
            end
          end

          desc 'PUT api/v1/staff/nursing_shift_manages/update_shift'
          params do
            requires :button_type, type: String, values: %w[cancel draft sent approved], message: I18n.t('nursing_shift_manage.error.validate.blank')
          end
          put 'update_shift' do
            ActiveRecord::Base.transaction do
              # check_nursing_shift_manage_confirmation
              next_month = Date.current.next_month
              year_month = next_month.strftime('%Y/%m')
              nursing_shift_manages = current_staff.nursing_shift_manages.where(status: 'initial')
              shifts = current_staff.shifts.where.not(previous_data: nil)

              if params[:button_type] == 'cancel'
                current_staff.shifts.where.not(previous_data: nil).where(status: 'initial').each do |shift|
                  shift.update(shift.previous_data)
                end
                current_staff.shifts.includes(:nursing_shift_manages).where(nursing_shift_manages: { status: 'initial' }).where(status: 'initial').destroy_all
              elsif params[:button_type] == 'draft'
                current_staff.shifts.where.not(previous_data: nil).each do |shift|
                  shift.update(status: 'draft')
                end
                current_staff.shifts.includes(:nursing_shift_manages).where(nursing_shift_manages: { status: 'initial' }).update_all(status: 'draft')
              elsif params[:button_type] == 'sent'
                return error!({ 'messages': I18n.t('errors.messages.button_type_invalid') }, NOT_FOUND) if nursing_shift_manages.blank? && shifts.blank?

                current_staff.shifts.where(status: ['draft', 'initial', 'sent'])&.update_all(previous_data: nil, status: 'sent')
                current_staff.nursing_shift_manages.update_all(confirmed_by_admin: false, confirmed_by_staff: true, status: 'sent', previous_data: nil)
                start_date = next_month.beginning_of_month
                end_date = next_month.end_of_month
                current_staff.schedule_dates.where(date: start_date..end_date).each do |schedule_date|
                  available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(schedule_date.date, schedule_date.start_time, schedule_date.end_time)
                  if available_nurse_ids.exclude?(current_staff.id)
                    schedule_date.update(nurse_id: nil)
                  end
                end
                current_staff.monthly_holidays.find_by(year_month: year_month).update(confirmed_by_admin: false, confirmed_by_staff: true)
              else # approved
                return error!({ 'messages': I18n.t('errors.messages.button_type_invalid') }, NOT_FOUND) if nursing_shift_manages.present? || shifts.present?

                current_staff.monthly_holidays.find_by(year_month: year_month).update(confirmed_by_staff: true)
                current_staff.nursing_shift_manages.update_all(confirmed_by_staff: true)
              end

              # Create notification
              create_noti(year_month, params[:button_type]) if ['sent', 'approved'].include?(params[:button_type])

              { success: I18n.t('success.messages.updated') }
            rescue StandardError => e
              e
            end
          end
        end
      end

      helpers do
        def check_for_overlapping_shifts(date, start_time, end_time, shift_id)
          dup_record = current_staff.shifts.includes(:nursing_shift_manages)
                                        .where(shift_date: date)
                                        .where('(start_time >= :start_time AND end_time <= :start_time)OR (end_time >= :start_time AND end_time <= :end_time)',
                                        { start_time: start_time, end_time: end_time })
                                        .where.not(id: shift_id)
          return error!({ message: I18n.t('nursing_shift_manage.error.overlap_date',
                          date: dup_record.pluck(:shift_date).uniq.join(','),
                          start_time: start_time,
                          end_time: end_time) }, UNPROCESSABLE_ENTITY) if dup_record.present?
        end

        def check_nursing_shift_manage_confirmation
          year_month = Date.current.next_month.strftime('%Y/%m')
          monthly_holiday = current_staff.monthly_holidays.find_by(year_month: year_month)
          return error!(I18n.t('errors.messages.shift_finalized'), UNPROCESSABLE_ENTITY) if monthly_holiday.confirmed_by_staff && monthly_holiday.confirmed_by_admin
          error!(I18n.t('errors.messages.wait_for_admin_confirmation'), UNPROCESSABLE_ENTITY) if monthly_holiday.confirmed_by_staff
        end

        def noti_title year_month, button_type
          case button_type
          when 'sent'
            "タイトル：#{year_month}のシフト調整依頼を送信しました。"
          when 'approved'
            "タイトル：#{year_month}のシフトを承認しました。"
          end
        end

        def noti_content year_month, button_type
          case button_type
          when 'sent'
            "<p>#{year_month}のシフト調整依頼を送信しました。</p>
            <p>シフトの確認をお願いします。</p>
            <p>リンク先URL #{ENV['FE_APP_URL']}/admin/shift/shift_staff</p>"
          when 'approved'
            "<p>#{year_month}のシフトを承認しました。</p>
            <p>リンク先URL #{ENV['FE_APP_URL']}/admin/shift/shift_staff</p>"
          end
        end

        def create_noti date = Date.today, button_type
          year_month = date.to_date.strftime('%Y年%m月')
          notification = Notification.create!(title: noti_title(year_month, button_type), content: noti_content(year_month, button_type),
                                              poster: current_staff.full_name, is_important: true, notify_type: 2,
                                              sender_id: current_staff.id, sender_type: current_staff.class.name)
          admin_ids = UserAdmin.all.pluck(:id)
          admin_ids.each do |uid|
            notification.mention_notifications.create!(m_id: uid, mention_type: 'UserAdmin')
          end
        end

        def shift_changed()
          next_month = Date.current.next_month
          year_month = next_month.strftime('%Y/%m')
          start_date = next_month.beginning_of_month
          end_date = next_month.end_of_month
          monthly_holiday = current_staff.monthly_holidays.find_by(year_month: year_month)
          return false unless monthly_holiday&.confirmed_by_admin

          shifts = current_staff.nursing_shift_manages.includes(:shift).where(shift: { shift_date: start_date..end_date } )
          dates_working = current_staff.shifts.where(shift_date: start_date..end_date).pluck(:shift_date)
          staff_holidays_created_by_staff = current_staff.holidays.where(date: start_date..end_date, create_type: 'staff')

          is_changed = false
          current_staff.holidays.where(date: start_date..end_date).where.not(date: dates_working).each do |holiday|
           is_changed = true if holiday.create_type == 'admin'
          end
          shifts.each do |value|
            is_changed = true if staff_holidays_created_by_staff.pluck(:date).include?(value.shift.shift_date)
          end

          is_changed
        end
      end
    end
  end
end
