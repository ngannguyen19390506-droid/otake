module V1
  module StaffHomeSystem
    class DashboardApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :staff_home_system do
        resources :dashboard do
          desc 'GET api/v1/staff_home_system/dashboard',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          get do
            objects = Notification.noti_by_hs_staff.patient_exists
                                  .or(Notification.noti_by_hs_admin.patient_exists)
            objects = objects.where('deployment_date >= ?', Time.current.to_date)
            objects = objects.distinct.by_deployment_date_asc.limit(10)
            serialized_nofitications = objects.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            rooms = Room.hs_dashboard_unread(@current_user.id).distinct.by_created_at_desc.limit(10)
            serialized_rooms = rooms.map do |room|
              RoomSerializer.new(room, { params: { current_uid: @current_user.id } }).as_json
            end

            rooms_unread_count = serialized_rooms.count

            present :notifications, serialized_nofitications
            present :rooms, serialized_rooms
            present :rooms_unread_count, rooms_unread_count
          end
        end
      end

      helpers do

      end
    end
  end
end
