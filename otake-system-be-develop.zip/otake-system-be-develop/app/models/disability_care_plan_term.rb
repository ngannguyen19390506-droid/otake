# == Schema Information
#
# Table name: disability_care_plan_terms
#
#  id                      :bigint           not null, primary key
#  plan_type               :integer
#  term_goal               :string
#  created_at              :datetime         not null
#  updated_at              :datetime         not null
#  disability_care_plan_id :integer          not null
#
class DisabilityCarePlanTerm < ApplicationRecord
  belongs_to :disability_care_plan

  enum plan_type: { short_term: 1, long_term: 2 }
end
