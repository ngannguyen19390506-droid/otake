# == Schema Information
#
# Table name: mention_notifications
#
#  id              :bigint           not null, primary key
#  mention_type    :string
#  name            :string
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  m_id            :integer
#  notification_id :integer
#
class MentionNotification < ApplicationRecord
  belongs_to :notification, foreign_key: :notification_id
  belongs_to :patient, foreign_key: :m_id, optional: true
end
