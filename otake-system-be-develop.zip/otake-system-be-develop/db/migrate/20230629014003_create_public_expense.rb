class CreatePublicExpense < ActiveRecord::Migration[7.0]
  def change
    create_table :public_expenses do |t|
      t.references :patient,                  null: false, foreign_key: true
      t.date       :start_date,               null: false
      t.date       :end_date,                 null: false
      t.string     :system_name,              null: false
      t.string     :cost_number,              null: false
      t.string     :beneficiary_number,       null: false
      t.float      :payment_amount,           null: false
      t.integer    :benefit_level,            null: false
      t.string     :comprehensive_aid_policy, null: false

      t.timestamps
    end
  end
end
