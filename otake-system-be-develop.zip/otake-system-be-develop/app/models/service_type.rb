# == Schema Information
#
# Table name: service_types
#
#  id         :bigint           not null, primary key
#  detail     :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
# Indexes
#
#  index_service_types_on_detail  (detail) UNIQUE
#
class ServiceType < ApplicationRecord
  include ApiCommon

  has_many :nursing_care_plan_service_types, dependent: :destroy
  has_many :nursing_care_plans, through: :nursing_care_plan_service_types
  has_many :nursing_care_histories, dependent: :destroy

  validates :detail, presence: true, uniqueness: true
  has_many :schedules, dependent: :destroy
end
