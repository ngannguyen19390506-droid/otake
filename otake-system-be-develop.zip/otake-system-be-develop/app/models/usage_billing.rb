# == Schema Information
#
# Table name: usage_billings
#
#  id               :bigint           not null, primary key
#  additional       :float
#  billing_amount   :float
#  exceeding_amount :float
#  invoice_type     :integer
#  other_charge     :float
#  subsidy_amount   :float
#  year_month       :string
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  patient_id       :integer
#
class UsageBilling < ApplicationRecord
  belongs_to :patient, foreign_key: :patient_id
  enum invoice_type: { nursing_care: 1, disability: 2 }
end
