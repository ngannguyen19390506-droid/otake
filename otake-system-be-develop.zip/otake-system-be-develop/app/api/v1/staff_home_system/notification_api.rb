module V1
  module StaffHomeSystem
    class NotificationApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :staff_home_system do
        resources :notifications do
          desc 'GET api/v1/staff_home_system/notifications',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
            optional :search, type: String
            requires :notify_tab, type: Integer, desc: 'tab 重要事項 = 1, tab 申し送り事項 = 2'
            optional :start_at, type: String, desc: '2024/03/10'
            optional :end_at, type: String, desc: '2024/03/20'
            optional :notification_category_id, type: Integer
          end
          get do
            page = (params[:page].presence || 1).to_i
            objects = Notification.noti_by_hs_staff.or(Notification.noti_by_hs_admin)
            case params[:notify_tab]
            when 1
              objects = objects.where.not(patient_id: nil)
            when 2
              objects = objects.where.not(notification_category_id: nil)
            end
            query = Hash.new.tap do |q|
              q[:title_or_content_cont] = params[:search] if params[:search].present?
              q[:notification_category_id_eq] = params[:notification_category_id] if params[:notification_category_id].present?
              q[:created_at_gteq] = convert_date(params[:start_at]).beginning_of_day if params[:start_at].present?
              q[:created_at_lteq] = convert_date(params[:end_at]).end_of_day if params[:end_at].present?
            end
            objects = objects.ransack(query).result.by_created_at_desc

            importants = []
            if params[:notify_tab] == 1
              importants = objects.where('deployment_date >= ?', Time.current.to_date)
                                  .by_deployment_date_asc.limit(10)
              objects = objects.where('deployment_date < ?', Time.current.to_date)
            end
            objects = objects.page(page).per(params[:per])
            serialized_nofitications = objects.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            important_notifications = importants.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            present :page, page
            present :total_page, objects.total_pages
            present :total_items, objects.total_count
            present :importants, important_notifications
            present :notifications, serialized_nofitications
          end

          desc 'GET api/v1/staff_home_system/notifications/personal-notification',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
          end
          get '/personal-notification' do
            current_cls = @current_user.class.name
            objects = NotificationRoom.where(sender_id: @current_user.id, sender_type: current_cls)
                                      .or(NotificationRoom.where(receiver_id: @current_user.id, receiver_type: current_cls))
                                      .by_created_at_desc
            page = (params[:page].presence || 1).to_i
            serialized_nofitications = objects.map do |room|
              next if room.message_notifications.count.zero?

              NotificationRoomSerializer.new(room, { params: { current_uid: @current_user.id } }).as_json
            end

            serialized_nofitications = Kaminari.paginate_array(serialized_nofitications)
                                               .page(page).per(params[:per])
            present :page, page
            present :total_page, serialized_nofitications.total_pages
            present :total_items, serialized_nofitications.total_count
            present :notifications, serialized_nofitications
          end

          desc 'GET api/v1/staff_home_system/notifications/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              notification = Notification.find(params[:id])
              notification.notification_view_logs.find_or_create_by(viewer_id: @current_user.id, viewer_type: @current_user.class.name)

              present notification
            end
          end

          desc 'POST api/v1/staff_home_system/notifications/create-room',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :receiver_id, type: Integer
          end
          post 'create-room' do
            begin
              params.merge!({ sender_id: @current_user.id, sender_type: @current_user.class.name,
                              receiver_type: 'UserHomeSystem' })
              room = NotificationRoom.find_or_create_by(params)
              present room
            end
          end

          desc 'POST api/v1/staff_home_system/notifications/messages',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer, desc: 'NotificationRoom ID'
            requires :content, type: String, desc: 'content'
            requires :notification_room_id, type: Integer
          end
          post 'messages' do
            params.merge!({ sender_id: @current_user.id, sender_type: @current_user.class.name })
            MessageNotification.create(params)
            room = NotificationRoom.find_by_id(params[:notification_room_id])
            present room
          end

          desc 'POST api/v1/staff_home_system/notifications',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer
            requires :content, type: String, desc: 'content'
            requires :deployment_date, type: Date, desc: '2024/03/01'
          end
          post do
            begin
              deployment_date = params[:deployment_date].to_date
              if deployment_date < Time.current.to_date
                return error!(I18n.t('errors.messages.date_less_than_current_date'), UNPROCESSABLE_ENTITY)
              end

              params.merge!({ sender_id: @current_user.id, notify_type: "noti_by_hs_staff",
                              poster: @current_user.user_name || "StaffHomeSystem", sender_type: @current_user.class.name })
              notification = Notification.new(params)
              if notification.save
                { success: I18n.t('success.messages.added') }
              else
                error!(notification.error_messages, UNPROCESSABLE_ENTITY)
              end
            end
          end

          desc 'POST api/v1/staff_home_system/notifications/group',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :notification_category_id, type: Integer
            requires :content, type: String, desc: 'content'
          end
          post '/group' do
            begin
              params.merge!({ sender_id: @current_user.id, notify_type: "noti_by_hs_staff",
                              poster: @current_user.user_name || "AdminHomeSystem", sender_type: @current_user.class.name })
              notification = Notification.new(params)
              if notification.save
                { success: I18n.t('success.messages.added') }
              else
                error!(notification.error_messages, UNPROCESSABLE_ENTITY)
              end
            end
          end
        end
      end

      helpers do
      end
    end
  end
end
