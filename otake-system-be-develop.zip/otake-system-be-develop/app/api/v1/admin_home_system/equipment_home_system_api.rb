module V1
  module AdminHomeSystem
    class EquipmentHomeSystemApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resources :equipment_home_systems do
          desc 'POST api/v1/admin_home_system/equipment_home_systems'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :equipment_home_systems, type: Array do
              requires :equipment_service_id, type: Integer, message: I18n.t('error.validate.blank')
              optional :unit_price, type: Integer
              requires :equipment_usage_home_systems, type: Array do
                requires :date, type: Date, message: I18n.t('error.validate.blank')
                requires :change, type: Integer, message: I18n.t('error.validate.blank')
              end
            end
          end
          post do
            patient_id = params[:patient_id]
            year_month = params[:year_month]
            start_of_month = year_month.to_date.beginning_of_month
            end_of_month = year_month.to_date.end_of_month
            patient = Patient.find_by(id: patient_id)
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            equipment_home_systems = patient.equipment_home_systems.where(year_month: year_month)
            ActiveRecord::Base.transaction do
              params[:equipment_home_systems].each do |data_params|
                equipment_service = EquipmentService.equipment.find_by(id: data_params[:equipment_service_id])
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if equipment_service.blank?

                stock_quantity_update = if equipment_service.stock_quantity != NOT_MANAGE
                                          equipment_service.stock_quantity.to_i - data_params[:equipment_usage_home_systems].sum {|usage| usage[:change] }
                                        else
                                          NOT_MANAGE
                                        end

                if equipment_service.update(stock_quantity: stock_quantity_update)
                  equipment_home_system = equipment_home_systems.find_by(equipment_service_id: data_params[:equipment_service_id])
                  if equipment_home_system.present?
                    data_params[:equipment_usage_home_systems].each do |params_usage|
                      return error!({ 'messages': I18n.t('errors.messages.invalid_date') }, UNPROCESSABLE_ENTITY) if (start_of_month..end_of_month).exclude?(params_usage[:date].to_date)
                      return error!({ 'messages': I18n.t('errors.messages.invalid_value_change') }, UNPROCESSABLE_ENTITY) if params_usage[:change] > 10
                      # at here
                      equipment_usage = equipment_home_system.equipment_usage_home_systems.find_by(date: params_usage[:date])
                      if equipment_usage.present?
                        equipment_usage.update!(quantity: equipment_usage.quantity + params_usage[:change])
                      else
                        create_equipment_usage(equipment_home_system, params_usage[:date], params_usage[:change])
                      end
                    end
                  else
                    equipment_home_system = EquipmentHomeSystem.new(
                      patient_id: patient_id,
                      year_month: year_month,
                      equipment_service_id: data_params[:equipment_service_id],
                      unit_price: data_params[:unit_price]
                    )
                    if equipment_home_system.save
                      data_params[:equipment_usage_home_systems].each do |params_usage|
                        return error!({ 'messages': I18n.t('errors.messages.invalid_date') }, UNPROCESSABLE_ENTITY) if (start_of_month..end_of_month).exclude?(params_usage[:date].to_date)
                        return error!({ 'messages': I18n.t('errors.messages.invalid_value_change') }, UNPROCESSABLE_ENTITY) if params_usage[:change] > 10

                        create_equipment_usage(equipment_home_system, params_usage[:date], params_usage[:change])
                      end
                    else
                      error!(equipment_home_system.error_messages, UNPROCESSABLE_ENTITY)
                    end
                  end
                else
                  error!({ message: equipment_service.error_messages.values.join(', ') }, UNPROCESSABLE_ENTITY)
                end
              end

              equipment_home_systems.present? ? { success: I18n.t('success.messages.updated') } : { success: I18n.t('success.messages.added') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end

      helpers do
        def create_equipment_usage(equipment_home_system, date, quantity)
          equipment_home_system.equipment_usage_home_systems.create!(
            date: date,
            quantity: quantity
          )
        end
      end
    end
  end
end
