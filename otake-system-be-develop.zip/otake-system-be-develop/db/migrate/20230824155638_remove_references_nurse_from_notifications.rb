class RemoveReferencesNurseFromNotifications < ActiveRecord::Migration[7.0]
  def change
    remove_reference :notifications, :nurse, foreign_key: { to_table: :nursing_staffs }, if_exists: true
  end
end
