class HealthController < ActionController::API
  def be
    render json: { status: "ok", service: "backend", version: ENV["VERSION"] }
  end
  def db
    ActiveRecord::Base.connection.execute("SELECT 1")
    render json: { status: "ok", service: "database", version: ENV["VERSION"] }
  rescue StandardError => e
    render status: :service_unavailable, json: {
      status: "error",
      service: "database",
      version: ENV["VERSION"]
    }
  end
end
