# design master
puts "Start time import data: #{DateTime.now}"

ActiveRecord::Base.transaction do
  # create patient
  last_record = Patient.order(patient_code: :desc).first
  patient = Patient.create!(
    password: 'otake123',
    last_name: '井上',
    first_name:	'隆代',
    last_name_kana: 'イノウエ',
    first_name_kana:	'タカヨ',
    family_name: '井上 隆代',
    name_kana: 'イノウエ タカヨ',
    sex: '女',
    birth_date:	'1946/06/21', #昭和21年6月21日
    zipcode: '463-0067',
    district:	'愛知県',
    city:	'名古屋市守山区',
    street:	'守山（丁目）',
    telephone_number:	'0123456789',
    status: 'using',
    period_contract: '2022/12/01',
    current_illness_history: '2週間に1回',
    family_interview: '井上朋浩 骨折され入院、手術し自宅で見ることが難しい。施設に入ることで少しほっとしている 次男嫁 施設になじめるか心配',
    personal_interview: '声かけに対し反応していただけず、そっぽ向かれてしまう',
    patient_code: last_record ? format('%04d', last_record.patient_code.to_i + 1) : '0001',
    contact_relatives_attributes: [
      {
        name: '井上 朋浩',
        relationship: '甥っ子',
        cellphone_number: '090-2188-4096',
        telephone_number: '',
        address: '愛知県名古屋市守山区守山1丁目10-16'
      },
      {
        name: '',
        relationship: '',
        cellphone_number: '',
        telephone_number: '',
        address: ''
      },
    ],
    hospital_attributes: {
      name: 'じょうど医院',
      clinical_department: '内科',
      phone: '090-4628-7825',
      address: ''
    }
  )

  # Create evalue one for patient
  patient.create_evalue_one(
    heartbeat: '大半をベッド上で過ごされており気分で動かれている',
    pre_history: "幼少期からコロニー利用 2021年4月26日右大腿骨転子部骨折のため入院",
    daily_life_challenges: "言語障害か聞き取りづらい部分があり訴えがあまりわからない 転倒リスクが高く、転倒転落起こす可能性がある",
    note: '環境の変化によりせん妄、不穏状態が悪化する可能性がある 心不全の治療は服薬にて継続されている 無視をされたり手が出たりかみつかれたりすることがある',
    character: '好き嫌いがはっきりしている',
    hobbies: '知的障害の部分で理解力あまりなし 参加するしないがはっきりされている',
    family_circumstances: '結婚歴なし',
    special_notes: '福祉用具'
  )

  # create service by patient_type: 'normal' and 'disability'
  services_to_create = [
    { service_name: '身体介護1', unit_price: 250, patient_type: 'normal' },
    { service_name: '身体介護1・夜', unit_price: 313, patient_type: 'normal' },
    { service_name: '身体介護2', unit_price: 396, patient_type: 'normal' },
    { service_name: '身体日0.5', unit_price: 255, patient_type: 'disability' },
    { service_name: '身体夜0.5', unit_price: 319, patient_type: 'disability' },
    { service_name: '身体深0.5', unit_price: 383, patient_type: 'disability' }
  ]

  services_to_create.each do |service_attrs|
    last_record = Service.order(service_code: :desc).first
    next_service_code = last_record ? format('%04d', last_record.service_code.to_i + 1) : '0001'

    Service.find_or_create_by(service_name: service_attrs[:service_name], patient_type: service_attrs[:patient_type]) do |service|
      service.service_name = service_attrs[:service_name]
      service.unit_price = service_attrs[:unit_price]
      service.patient_type = service_attrs[:patient_type]
      service.service_code = next_service_code
    end
  end

  # create service type
  service_type_details = ['名称', '口腔ケア・排泄補助', '入浴', '排泄補助・体位交換', '排泄介助']
  service_type_details.each do |detail|
    ServiceType.find_or_create_by(detail: detail)
  end

  # Create nursing care plan for patient
  year_month = Date.current.next_month
  start_month = year_month.beginning_of_month
  end_month = year_month.end_of_month
  nursing_care_plan = patient.nursing_care_plans.create!(
    year_month: year_month.strftime('%Y/%m'),
    comprehensive_aid_policy: 'ご本人様の身体状況と生活の安定のために疾病管理は主治医に従い、必要な医療を継続できるようにする。ご本人、ご家族の意向を尊重した、納得のいくサービス利用が出来るように情報提供を行い、安全快適な施設での生活ができるように支援していきます。',
    individual_family_intention: '施設での生活を穏やかに安心して暮らしたい。コミュニケーションを取ってもらいながら、必要なサービスを利用して安全快適な施設生活を維持してもらいたい。',
    remarks: '排泄介助：オムツ・パット使用側臥位になるのはご自身で難しいので手伝い必要。手が出たりかみついたりされるため注意必要。体位交換、除圧行う。',
  )

  # Schedule first: service: 身体介護1, time: 04：30～5：00, service_type:	排泄介助, total_number_of_times: 30
  service_first_id = Service.find_by(service_name: '身体介護1').id
  # Schedule second: service: 身体介護2, time: 22:00～22:30, service_type:	排泄介助, total_number_of_times: 30
  service_second_id = Service.find_by(service_name: '身体介護2').id
  service_type_id = ServiceType.find_by(detail: '排泄介助').id
  total_number_of_times = (start_month..end_month).count
  schedule_first = nursing_care_plan.schedules.create(service_id: service_first_id, service_type_id: service_type_id, patient_id: patient.id,
                                                      care_plan_type: 'NursingCarePlan', total_number_of_times: total_number_of_times)
  schedule_second = nursing_care_plan.schedules.create(service_id: service_second_id, service_type_id: service_type_id, patient_id: patient.id,
                                                       care_plan_type: 'NursingCarePlan', total_number_of_times: total_number_of_times)
  (start_month..end_month).each do |date|
    schedule_first.schedule_dates.create!(
      date: date,
      start_time: '04:30',
      end_time: '05:00',
      scheduleable_type: 'Schedule'
    )

    schedule_second.schedule_dates.create!(
      date: date,
      start_time: '22:00',
      end_time: '22:30',
      scheduleable_type: 'Schedule'
    )
  end

  # create staffs
  last_record = NursingStaff.order(nurse_code: :desc).first
  # telephone_number: '090-1282-1272',
  nurse_code = last_record ? format('%04d', last_record.nurse_code[0..-5].to_i + 1) + '1272' : '00011272'
  staff_first = NursingStaff.create!(
    cellphone_number: '090-1282-1272',
    telephone_number: '090-1282-1272',
    password: 'otake123',
    birth_date: '1990/10/20',
    sex: '男',
    last_name: '丹羽',
    first_name: '智大',
    last_name_kana: 'ニワ',
    first_name_kana: 'トモヒロ',
    zipcode: '463-0001',
    district: '愛知県',
    city: '名古屋市守山区',
    street: '上志段味',
    nurse_code: nurse_code,
    my_number: '',
    building_name: '',
    family_name: '丹羽 智大',
    name_kana: 'ニワ トモヒロ',
    status: 'active',
    contact_relatives_attributes: [
      {
        name: '丹羽千映美',
        relationship: '妻',
        cellphone_number: '',
        telephone_number: '',
        address: '同上'
      },
      {
        name: '',
        relationship: '',
        cellphone_number: '',
        telephone_number: '',
        address: ''
      },
    ]
  )

  last_record = NursingStaff.order(nurse_code: :desc).first
  # telephone_number: '052-880-4102',
  nurse_code = last_record ? format('%04d', last_record.nurse_code[0..-5].to_i + 1) + '4102' : '00014102'
  staff_second = NursingStaff.create!(
    cellphone_number: '090-8321-4046',
    telephone_number: '052-880-4102',
    password: 'otake123',
    birth_date: '1987/09/13"',
    sex: '女',
    last_name: '大嶽',
    first_name: '麻未',
    last_name_kana: 'オオタケ',
    first_name_kana: 'マミ',
    zipcode: '463-0036',
    district: '愛知県',
    city: '名古屋市守山区',
    street: '向台',
    nurse_code: nurse_code,
    my_number: '',
    building_name: '',
    family_name: '大嶽 麻未',
    name_kana: 'オオタケ マミ',
    status: 'active',
    contact_relatives_attributes: [
      {
        name: '大嶽暁良',
        relationship: '妻',
        cellphone_number: '090-9195-7475',
        telephone_number: '',
        address: '同上'
      },
      {
        name: '',
        relationship: '',
        cellphone_number: '',
        telephone_number: '',
        address: ''
      },
    ]
  )

  # create shift registration
  shifts_data = [
    { name: "希望休", abbreviation: "z", background_color: "#eb4034", text_color: "#fff", start_time: "00:00", end_time: "24:00" },
    { name: "休み", abbreviation: "x", background_color: "#eb4034", text_color: "#f7f71b", start_time: "00:00", end_time: "24:00" },
    { name: "夜勤明け", abbreviation: "明", background_color: "#1bf738", text_color: "#eb4034", start_time: "00:00", end_time: "09:00" },
    { name: "夜勤入り", abbreviation: "夜", background_color: "#1bf738", text_color: "#941bf7", start_time: "16:30", end_time: "24:00" },
    { name: "遅番", abbreviation: "9", background_color: "#f71bb1", text_color: "#fff", start_time: "09:00", end_time: "18:00" },
    { name: "早番", abbreviation: "8", background_color: "#941bf7", text_color: "#fff", start_time: "08:00", end_time: "17:00" }
  ]
  shifts_data.each do |shift_attributes|
    existing_shift_by_name = ShiftRegistration.find_by(name: shift_attributes[:name])
    existing_shift_by_time = ShiftRegistration.find_by(start_time: shift_attributes[:start_time], end_time: shift_attributes[:end_time])
    next if existing_shift_by_name || existing_shift_by_time

    last_shift_record = ShiftRegistration.order(shift_code: :desc).first
    next_shift_code = last_shift_record ? format('%04d', last_shift_record.shift_code.to_i + 1) : '0001'
    shift_attributes[:shift_code] = next_shift_code
    ShiftRegistration.create!(shift_attributes)
  end

  # create treatment imporovement patient_type: 'normal' and 'disability'
  improvement_data = [
    { name: '訪問介護処遇改善加算Ⅰ', patient_type: 'normal', rate: '13.7' },
    { name: '訪問介護ベースアップ等支援加算', patient_type: 'normal', rate: '2.4' },
    { name: '居介処遇改善加算Ⅰ', patient_type: 'disability', rate: '27.4' },
    { name: '居介ベースアップ等支援加算', patient_type: 'disability', rate: '4.5' }
  ]
  improvement_data.each do |data|
    existing_improvement = TreatmentImprovement.find_by(name: data[:name])
    next if existing_improvement

    TreatmentImprovement.create!(data)
  end
rescue ActiveRecord::RecordInvalid => e
  puts "Errors: #{e.record.errors.full_messages}"
end

puts "End time import data: #{DateTime.now}"
