class CreateNursingCarePlanService < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_care_plan_services do |t|
      t.references :nursing_care,    null: false, foreign_key: { to_table: :nursing_care_plans }
      t.references :service,         null: false, foreign_key: true

      t.timestamps
    end
  end
end
