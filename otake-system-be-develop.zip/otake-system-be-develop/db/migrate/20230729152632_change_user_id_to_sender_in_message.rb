class ChangeUserIdToSenderInMessage < ActiveRecord::Migration[7.0]
  def change 
    remove_reference :messages, :user, polymorphic: true
    add_column :messages, :sender_id, :integer, null: false
    add_column :messages, :sender_type, :string
    add_index :messages, [:sender_type, :sender_id]
  end
end
