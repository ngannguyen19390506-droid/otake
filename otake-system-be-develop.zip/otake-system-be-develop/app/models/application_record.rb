class ApplicationRecord < ActiveRecord::Base
  primary_abstract_class

  scope :by_created_at_asc, -> { order(created_at: :asc) }
  scope :by_created_at_desc, -> { order(created_at: :desc) }
  scope :with_registered, -> { where(registered: true) }
  scope :by_date_asc, -> { order(date: :asc) }
  scope :by_deployment_date_asc, -> { order(deployment_date: :asc) }
  scope :by_deployment_date_desc, -> { order(deployment_date: :desc) }
  scope :by_nurse_code_asc, -> { order(nurse_code: :asc) }
  scope :by_nurse_code_desc, -> { order(nurse_code: :desc) }

  def full_name
    "#{last_name} #{first_name}"
  end
end
