# == Schema Information
#
# Table name: services
#
#  id           :bigint           not null, primary key
#  patient_type :integer
#  service_code :string           not null
#  service_name :string           not null
#  unit_price   :integer
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#
# Indexes
#
#  index_services_on_service_name  (service_name) UNIQUE
#
class Service < ApplicationRecord
  include ApiCommon

  has_many :nursing_care_plan_services, dependent: :destroy
  has_many :nursing_care_plans, through: :nursing_care_plan_services
  has_many :service_shift_manages, dependent: :destroy
  has_many :shift_managements, through: :service_shift_manages, source: :shift
  has_many :schedules, dependent: :destroy
  has_many :nursing_care_histories, dependent: :destroy

  validates :service_name, :service_code, :patient_type, presence: true
  validates :service_name, uniqueness: true
  enum patient_type: { normal: 0, disability: 1 }
end
