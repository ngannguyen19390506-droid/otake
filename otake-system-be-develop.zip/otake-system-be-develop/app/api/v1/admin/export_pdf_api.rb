module V1
  module Admin
    class ExportPdfApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :export_pdf do
          # 代理受領額通知書
          desc 'POST /api/v1/admin/export_pdf/payment-receipt-notice',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String, desc: '2024-11'
            optional :client_ids, type: Array[Integer]
          end

          post '/payment-receipt-notice' do
            year_month = params[:year_month].to_date
            start_at = year_month.beginning_of_month
            end_at = year_month.end_of_month
            conditions = { date: start_at..end_at }

            clients = if params[:client_ids].present?
                        Patient.where(id: params[:client_ids])
                      else
                        Patient.all
                      end
            clients = clients.order("name_kana ASC NULLS LAST")
            profile = SystemManagementProfile.first

            patient_schedule_dates = ScheduleDate.joins("INNER JOIN schedules ON schedule_dates.scheduleable_id = schedules.id AND schedule_dates.scheduleable_type = 'Schedule'")
                                                 .where(conditions).where(schedules: { patient_id: clients.pluck(:id) })
                                                 .group_by { |f| f.scheduleable.patient_id }

            schedule_date_ids = patient_schedule_dates.values.flatten.pluck(:id).uniq
            nursing_histories = preload_change_histories(schedule_date_ids)
            nursing_care_histories = preload_nursing_change_histories(schedule_date_ids)

            data = clients.map { |client|
              client_data = PatientSerializer.new(client).as_json

              recipient = client.recipients.by_created_at_desc&.first&.attributes
              insurance_cards = client.insurance_cards.by_created_at_desc&.first&.attributes

              schedules = []
              care_plan_sum = 0
              schedule_dates = patient_schedule_dates[client.id]
              if schedule_dates.present?
                schedule_dates.each do |schedule|
                  next unless nursing_histories[schedule.id]
                  next if client.leave_date.present? && schedule.date >= client.leave_date

                  schedules << schedule

                  system_rate = if schedule.scheduleable.care_plan_type == 'NursingCarePlan'
                                  profile.rate_registration_nursing_care
                                else
                                  profile.rate_registration_disability
                                end
                  unit_price = schedule.scheduleable.service.unit_price
                  nursing_care_history = nursing_care_histories[schedule.id]

                  updated_time = if nursing_care_history.present?
                                   DateTime.parse(nursing_care_history.first.updated_time).strftime('%H:%M')
                                 else
                                   schedule.end_time_format
                                 end
                  quantity = parse_schedule_time(schedule.start_time_format, updated_time)
                  care_plan_sum += unit_price * quantity * 2 * system_rate.to_f
                end
              end
              { client: client_data, profile: profile, recipient: recipient, insurance_cards: insurance_cards, schedules: schedules, care_plan_sum: care_plan_sum.to_i }
            }

            present :data, data
          end

          # サービス提供票
          desc 'POST  /api/v1/admin/export_pdf/service-delivery',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String, desc: '2024-11'
            requires :client_ids, type: Array[Integer]
            optional :care_plan_type, type: String, desc: 'NursingCarePlan/ DisabilityCarePlan'
          end

          post '/service-delivery' do
            start_month = params[:year_month].to_date.beginning_of_month
            end_month = start_month.end_of_month

            clients = if params[:client_ids].present?
                        Patient.includes(schedules: [:schedule_dates])
                               .where(id: params[:client_ids])
                      else
                        Patient.all
                      end
            clients = clients.order("name_kana ASC NULLS LAST")

            insurance_cards_by_patient = InsuranceCard.where(patient_id: clients.pluck(:id)).group_by { |i_c| i_c.patient_id }.to_h

            schedule_dates = ScheduleDate.where(date: start_month..end_month)
            if params[:care_plan_type].present?
              schedule_dates = schedule_dates.joins("INNER JOIN schedules ON schedules.id = schedule_dates.scheduleable_id").where(schedules: {care_plan_type: params[:care_plan_type]})
            end
            schedule_dates_by_patient = schedule_dates.includes(scheduleable: :patients).group_by { |schedule_date| schedule_date.scheduleable.patient.id }


            schedule_ids = schedule_dates_by_patient.values&.flatten&.pluck(:scheduleable_id).to_a.uniq
            schedules_by_ids = Schedule.joins(:service, :service_type).where(id: schedule_ids).group_by { |schedule| schedule.id }

            schedule_date_ids = schedule_dates_by_patient.values.flatten.pluck(:id).uniq
            nursing_histories = preload_change_histories(schedule_date_ids)
            nursing_care_histories = NursingCareHistory.where(schedule_date_id: schedule_date_ids)
                                                       .group_by { |history| history.schedule_date_id }
            profile = SystemManagementProfile.first

            data = clients.map { |client|
              client_id = client.id
              client_data = client.attributes.except('password', 'encrypted_password', 'created_at', 'updated_at',
                                                     'hex_color', 'status', 'personal_interview')
              recipient = client.recipients.by_created_at_desc&.first&.attributes
              insurance_card = insurance_cards_by_patient[client_id]&.sort&.last
              schedule_dates = schedule_dates_by_patient[client_id]

              shifts = (start_month.to_date..end_month.to_date).map { |date|
                date_schedules = schedule_dates.to_a.select { |f| f.date == date }

                schedules_list = date_schedules.map do |schedule_date|
                  plan = DEFAULT_PLAN_NUMBER
                  is_history = nursing_histories[schedule_date.id]
                  nursing_care_history = nursing_care_histories[schedule_date.id]&.first
                  schedules = schedules_by_ids[schedule_date.scheduleable_id]
                  schedules.each do |schedule|
                    service = schedule.service
                    service_type = schedule.service_type
                    schedule.attributes.merge!({ service: service, service_type: service_type })
                  end
                  actual = is_history ? DEFAULT_HAS_ACTUAL : DEFAULT_HAS_NOT_ACTUAL
                  schedule_date.attributes.merge!({ plan: plan, actual: actual, nursing_care_history: nursing_care_history })
                end

                { date: date, schedules: schedules_list.compact }
              }

              { client: client_data, profile: profile, insurance_card: insurance_card, recipient: recipient, shifts: shifts }
            }

            present :data, data
          end

          # 居宅介護サービス提供実績記録票
          # desc 'POST  /api/v1/admin/export_pdf/home-care-service-record',
          #      headers: {
          #        'Authorization' => {
          #          description: 'Ex: Bearer [your_token]',
          #          required: true
          #        }
          #      }
          # params do
          #   requires :year_month, type: String, desc: '2024-11'
          #   requires :client_id, type: Integer
          # end
          #
          # post '/home-care-service-record' do
          #   start_month = params[:year_month].to_date.beginning_of_month
          #   end_month = start_month.end_of_month
          #
          #   clients = Patient.where(id: params[:client_id])
          #   schedule_dates_by_patient = ScheduleDate.includes(scheduleable: :patients)
          #                                           .where(date: start_month..end_month)
          #                                           .group_by { |schedule_date| schedule_date.scheduleable.patient.id }
          #
          #   schedule_ids = schedule_dates_by_patient.values&.flatten&.pluck(:scheduleable_id).to_a.uniq
          #   schedules_by_ids = Schedule.joins(:service, :service_type).where(id: schedule_ids).group_by { |schedule| schedule.id }
          #
          #   schedule_date_ids = schedule_dates_by_patient.values.flatten.pluck(:id).uniq
          #   nursing_histories = preload_change_histories(schedule_date_ids)
          #   nursing_care_histories = NursingCareHistory.where(schedule_date_id: schedule_date_ids)
          #                                              .group_by { |history| history.schedule_date_id }
          #   profile = SystemManagementProfile.first
          #   data = clients.map { |client|
          #     client_id = client.id
          #     client_data = client.attributes.except('password', 'encrypted_password', 'created_at', 'updated_at',
          #                                            'hex_color', 'status', 'personal_interview')
          #     recipient = client.recipients.by_created_at_desc&.first&.attributes
          #     schedule_dates = schedule_dates_by_patient[client_id]
          #
          #     shifts = (start_month.to_date..end_month.to_date).map { |date|
          #       date_schedules = schedule_dates.select { |f| f.date == date }
          #       plan = date_schedules.to_a.count
          #       actual = 0
          #       histories = []
          #       schedules_list = []
          #       date_schedules.each do |shift|
          #         is_history = nursing_histories[shift.id]
          #         histories << nursing_care_histories[shift.id]
          #         schedules = schedules_by_ids[shift.scheduleable_id]
          #         schedules_list = schedules.map do |schedule|
          #           service = schedule.service
          #           service_type = schedule.service_type
          #           schedule.attributes.merge!({ service: service, service_type: service_type })
          #         end
          #         actual += 1 if is_history
          #       end
          #
          #       { date: date, plan: plan, actual: actual, schedules: schedules_list.compact, histories: histories.compact }
          #     }
          #
          #     { client: client_data, profile: profile, recipient: recipient, shifts: shifts }
          #   }
          #   present :data, data
          # end
        end
      end

      helpers do
        def parse_schedule_time start_time, end_time
          return 0 if start_time.blank? || end_time.blank?

          start_time = Time.parse(start_time)
          end_time = Time.parse(end_time)

          (end_time - start_time) / 3600.0
        end
      end
    end
  end
end
