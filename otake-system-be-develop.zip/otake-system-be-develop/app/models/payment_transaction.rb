# == Schema Information
#
# Table name: payment_transactions
#
#  id         :bigint           not null, primary key
#  amount     :decimal(, )      not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  payment_id :bigint           not null
#
# Indexes
#
#  index_payment_transactions_on_payment_id  (payment_id)
#
# Foreign Keys
#
#  fk_rails_...  (payment_id => payments.id)
#
class PaymentTransaction < ApplicationRecord
  belongs_to :payment
end
