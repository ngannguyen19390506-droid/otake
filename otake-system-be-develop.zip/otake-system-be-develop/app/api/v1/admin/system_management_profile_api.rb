module V1
  module Admin
    class SystemManagementProfileApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :system_management_profiles do
          # get SystemManagementProfile
          desc 'GET api/v1/admin/system_management_profiles',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          get do
            @system_management_profile = SystemManagementProfile.first
            present @system_management_profile
          end

          desc 'PUT api/v1/admin/system_management_profiles',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :building_name, type: String
            optional :business_number, type: String
            optional :city, type: String
            optional :district, type: String
            optional :facility_name, type: String
            optional :fax, type: String
            optional :grade_registration, type: String
            optional :mobile_phone, type: String
            optional :rate_registration, type: Integer
            optional :street, type: String
            optional :zipcode, type: String
            optional :day_payment, type: Integer
            optional :rate_registration_nursing_care, type: Float
            optional :rate_registration_disability, type: Float
          end
          put do
            system_management_profile = SystemManagementProfile.first
            if system_management_profile&.update(system_management_profile_params)
              present system_management_profile
            else
              error!(system_management_profile&.error_messages, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end

      helpers do
        def system_management_profile_params
          params.slice(:building_name, :business_number, :city, :district, :facility_name, :fax, :grade_registration,
                       :mobile_phone, :street, :zipcode, :day_payment, :rate_registration_nursing_care,
                       :rate_registration_disability)
        end
      end
    end
  end
end
