module V1
  module Admin
    class PatientApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :patients do
          # index
          desc 'GET api/v1/admin/patients'
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :fullname, type: String
            optional :status, type: Array[String]
            optional :sortKey, type: String
            optional :order, type: String
            optional :care_plan_date, type: Date
            optional :year_month_payment, type: String
            optional :get_all, type: Boolean
            optional :schedule_date, type: String # get patient has schedule date
          end
          get do
            return [] if params[:care_plan_date].present? && params[:care_plan_date] > Time.zone.today.end_of_month

            @query = Patient.includes(:contact_relatives, :hospital, :equipment_service_payments, :payment_histories, :patient_receipts)
            sort_key = params[:sortKey]
            if params[:status].present?
              # enum status: { using: 0, pause: 1, suspended: 2 }
              @query = @query.where(status: params[:status])
              if params[:care_plan_date].present?
                @query = @query.includes(:schedule_dates).where(schedule_dates: { date: params[:care_plan_date] })
              end
            end
            return present :data, @query.includes(:schedule_dates)
                                        .where(schedule_dates: { date: convert_date(params[:schedule_date]), nurse_id: nil }) if params[:get_all] && params[:schedule_date].present?
            return present :data, @query.default_order.select(:id, :family_name, :name_kana) if params[:get_all]

            @q = @query.ransack(family_name_or_name_kana_cont: params[:fullname])
            page = (params[:page].presence || 1).to_i
            @patients = @q.result.by_patient_code_asc.page(page).per(params[:per]) if sort_key.blank?
            if sort_key.present?
              sort_key = 'name_kana' if sort_key == 'name'
              sort_key = 'district' if sort_key == 'residence'
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if sort_key == 'age'
                sort_key = 'birth_date'
                sort_order = sort_order == 'ASC' ? 'DESC' : 'ASC'
              end
              @patients = if sort_key == 'name_kana'
                            sorted = @q.result.sort_by(&:name_kana)
                            sorted.reverse! if sort_order != 'ASC'
                            sorted = Kaminari.paginate_array(sorted)
                            sorted
                          elsif %w(payment_history_status payment_history_expected_date payment_history_actual_date).include?(sort_key) # payment_histories index
                            @q.result.order_by_payment_history(sort_key, sort_order, params[:year_month_payment])
                          elsif %w(care_level insurance_number insurance_period responsible_policy_management).include?(sort_key)
                            sort_key = 'start_insurance' if sort_key == 'insurance_period'
                            @q.result.left_outer_joins(:insurance_cards)
                                      .select('patients.*, MAX(insurance_cards.id) AS max_insurance_card_id')
                                      .group('patients.id')
                                      .order("MAX(insurance_cards.#{sort_key}) #{sort_order} NULLS LAST")
                          else
                            @q.result.order(sort_key => sort_order)
                          end.page(page).per(params[:per])
            end
            serialized_patients = @patients.map do |patient|
              PatientSerializer.new(patient, { year_month_payment: params[:year_month_payment] }).as_json
            end
            present :page, page
            present :total_items, @patients.total_count
            present :total_pages, @patients.total_pages
            present :patients, serialized_patients
          end

          # Create Patient
          desc 'POST api/v1/admin/patients'
          params do
            optional :cellphone_number, type: String
            requires :telephone_number, type: String, message: I18n.t('patient.error.validate.blank')
            requires :password, type: String, message: I18n.t('patient.error.validate.blank')
            requires :birth_date, type: String, message: I18n.t('patient.error.validate.blank')
            requires :sex, type: String, message: I18n.t('patient.error.validate.blank'), values: Patient.sexes.keys
            requires :first_name, type: String, message: I18n.t('patient.error.validate.blank')
            requires :last_name_kana, type: String, message: I18n.t('patient.error.validate.blank')
            requires :first_name_kana, type: String, message: I18n.t('patient.error.validate.blank')
            optional :zipcode, type: String
            requires :district, type: String, message: I18n.t('patient.error.validate.blank')
            requires :city, type: String, message: I18n.t('patient.error.validate.blank')
            requires :street, type: String, message: I18n.t('patient.error.validate.blank')
            requires :status, type: String, message: I18n.t('patient.error.validate.blank'), values: Patient.statuses.keys
            requires :period_contract, type: String, message: I18n.t('patient.error.validate.blank')
            optional :current_illness_history, type: String
            optional :family_interview, type: String
            optional :personal_interview, type: String
            optional :building_name, type: String
            optional :hex_color, type: String
            optional :home_care_support_office_name, type: String
            optional :contact_relatives_attributes, type: Array do
              optional :name, type: String
              optional :relationship, type: String
              optional :cellphone_number, type: String
              optional :telephone_number, type: String
              optional :address, type: String
            end
            optional :hospital_attributes, type: Hash do
              optional :name, type: String
              optional :clinical_department, type: String
              optional :phone, type: String
              optional :address, type: String
            end
            optional :leave_date, type: String, desc: 'YYYY-mm-dd'
          end
          post do
            patient = Patient.new(params_patient)
            patient.password_valid?(params[:password])
            return error!(patient.error_messages, UNPROCESSABLE_ENTITY) if patient.error_messages.present?

            patient.patient_code = generate_code(Patient, :patient_code)
            patient.contact_relatives.each do |contact_relative|
              contact_relative.patient = patient
            end
            patient.hospital&.patient = patient
            patient.update_family_name_and_name_kana(params_patient)
            if patient.save
              { success: I18n.t('patient.success.added'), patient_id: patient.id }
            else
              error!(patient.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # patient detail
          desc 'GET api/v1/admin/patients/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              @patient = Patient.find_by(id: params[:id])
              return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @patient.blank?

              present @patient
            end
          end

          # Update patient
          desc 'PUT api/v1/admin/patients/:id'
          params do
            requires :id, type: Integer
            optional :cellphone_number, type: String
            optional :telephone_number, type: String
            optional :password, type: String
            optional :birth_date, type: String
            optional :sex, type: String, values: Patient.sexes.keys
            optional :last_name, type: String
            optional :first_name, type: String
            optional :last_name_kana, type: String
            optional :first_name_kana, type: String
            optional :zipcode, type: String
            optional :district, type: String
            optional :city, type: String
            optional :street, type: String
            optional :status, type: String, values: Patient.statuses.keys
            optional :period_contract, type: String
            optional :current_illness_history, type: String
            optional :family_interview, type: String
            optional :personal_interview, type: String
            optional :building_name, type: String
            optional :hex_color, type: String
            optional :home_care_support_office_name, type: String
            optional :contact_relatives_attributes, type: Array do
              optional :id, type: Integer
              optional :name, type: String
              optional :relationship, type: String
              optional :cellphone_number, type: String
              optional :telephone_number, type: String
              optional :address, type: String
            end
            optional :hospital_attributes, type: Hash do
              optional :id, type: Integer
              optional :name, type: String
              optional :clinical_department, type: String
              optional :phone, type: String
              optional :address, type: String
            end
            optional :leave_date, type: String, desc: 'YYYY-mm-dd'
          end
          put ':id' do
            patient = Patient.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            patient.update_family_name_and_name_kana(params_patient)
            if patient.update(params_patient)
              current_user_id = current_user(UserAdmin, :user_code).id
              patient.create_change_histories(current_user_id)
              { success: I18n.t('patient.success.updated') }
            else
              error!(patient.error_messages, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end

      helpers do
        def params_patient
          params_patient = params.slice(
            :cellphone_number, :telephone_number, :password, :birth_date, :sex, :last_name, :first_name, :last_name_kana,
            :first_name_kana, :zipcode, :district, :city, :street, :status, :period_contract, :current_illness_history,
            :family_interview, :building_name, :personal_interview, :hex_color, :leave_date, :home_care_support_office_name
          )
          params_patient[:birth_date] = convert_date(params[:birth_date]) if params[:birth_date].present?
          params_patient[:period_contract] = convert_date(params[:period_contract]) if params[:period_contract].present?

          if params[:contact_relatives_attributes].present?
            params_patient = params_patient.merge(contact_relatives_attributes: params_contact_relatives)
          end

          params_patient = params_patient.merge(hospital_attributes: params_hospital) if params[:hospital_attributes].present?
          params_patient
        end

        def params_contact_relatives
          params[:contact_relatives_attributes].map do |contact_relative_params|
            contact_relative_params.slice(
              :id, :name, :relationship, :cellphone_number, :telephone_number, :address
            )
          end
        end

        def params_hospital
          params[:hospital_attributes].slice(:id, :name, :clinical_department, :phone, :address)
        end
      end
    end
  end
end
