module V1
  module Client
    class PatientSerializer < ActiveModel::Serializer
      attributes :id,
                 :cellphone_number,
                 :telephone_number,
                 :birth_date,
                 :sex,
                 :last_name,
                 :first_name,
                 :last_name_kana,
                 :first_name_kana,
                 :zipcode,
                 :district,
                 :city,
                 :street,
                 :status,
                 :period_contract,
                 :current_illness_history,
                 :family_interview,
                 :personal_interview,
                 :patient_code,
                 :building_name,
                 :family_name,
                 :name_kana,
                 :hex_color
    end
  end
end
