module V1
  module Staff
    class MessageApi < V1::AppApi
      before {authenticate!(NursingStaff, :nurse_code)}

      namespace :staff do
        resource :rooms do
          desc 'GET api/v1/staff/rooms',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
            optional :search, type: String
            optional :unread, type: Boolean
          end
          get do
            page = (params[:page].presence || 1).to_i
            @query = Room.room_owner(current_staff.id).staff_only_unread(params[:unread], current_staff.id)
            if params[:search].present?
              admin_ids = UserAdmin.ransack(user_name_cont: params[:search]).result.pluck(:id)
              nurse_ids = NursingStaff.ransack(family_name_or_name_kana_cont: params[:search]).result.pluck(:id)
              @query = @query.where(source_id: admin_ids, source_type: 'admin')
                         .or(@query.where(target_id: admin_ids, target_type: 'user_admin'))
                         .or(@query.where(source_id: nurse_ids, source_type: 'staff'))
                         .or(@query.where(target_id: nurse_ids, target_type: 'nursing_staff'))
            end
            @rooms = @query.by_created_at_desc.page(page).per(params[:per])
            serialized_rooms = @rooms.map do |room|
              RoomSerializer.new(room, { params: { current_uid: current_staff.id } }).as_json
            end
            present :page, page
            present :total_page, @rooms.total_pages
            present :total_items, @rooms.total_count
            present :rooms, serialized_rooms
          end

          desc 'POST api/v1/staff/rooms',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :target_id, type: Integer
            requires :target_type, type: String, desc: 'nursing_staff/user_admin'
          end
          post do
            current_user_id = current_staff.id
            source_type = params[:target_type] == 'user_admin' ? 'admin' : 'staff'
            room = Room.where(source_id: current_user_id, source_type: 'staff',
                              target_id: params[:target_id], target_type: params[:target_type])
                       .or(Room.where(target_id: current_user_id, target_type: 'nursing_staff',
                                      source_id: params[:target_id], source_type: source_type))
            return present room.first if room.present?

            conditions = { source_id: current_user_id, source_type: 'staff', target_id: params[:target_id], target_type: params[:target_type] }
            @room = Room.find_or_create_by(conditions)

            if @room.save
              present @room
            else
              error!(@room.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/staff/rooms/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
          end

          get ':id' do
            page = (params[:page].presence || 1).to_i
            @room = Room.find(params[:id])
            @messages = @room.messages.order(created_at: :desc).page(page).per(params[:per])
            @room.messages.where(receiver_id: current_staff.id, read_at: nil, receiver_type: current_staff.class.name)&.update_all(read_at: Time.current)
            serialized_messages = @messages.reverse.map do |message|
              MessageSerializer.new(message, { params: { current_uid: current_staff.id } }).as_json
            end
            present :page, page
            present :total_page, @messages.total_pages
            present :total_items, @messages.total_count
            present :messages, serialized_messages, instance_options: current_staff.id
          end

          desc 'Put api/v1/staff/rooms/:id'
          params do
            requires :id, type: Integer
          end

          put ':id' do
            room = Room.find(params[:id])
            receiver_type = current_staff.class.name.to_s
            room.messages.where(receiver_id: current_staff.id, read_at: nil, receiver_type: receiver_type)&.update_all(read_at: Time.current)
            { success: true }
          end

          route_param :id do
            resource :messages do
              desc 'POST api/v1/staff/rooms/:id/messages',
                   headers: {
                     'Authorization' => {
                       description: 'Ex: Bearer [your_token]',
                       required: true
                     }
                   }
              params do
                requires :id, type: Integer
                requires :content, type: String
              end
              post do
                @room = Room.find(params[:id])
                receiver_id = @room.target_id == current_staff.id ? @room.source_id : @room.target_id

                if @room.target_id == current_staff.id && @room.target_type.camelize == current_staff.class.name
                  receiver_type = @room.source_type == 'admin' ? 'UserAdmin' : current_staff.class.name
                else
                  receiver_type = @room.target_type.camelize
                end
                @message = @room.messages.new(content: params[:content], sender_id: current_staff.id,
                                              sender_type: current_staff.class.name,
                                              receiver_id: receiver_id, receiver_type: receiver_type)
                if @message.save
                  present @message
                else
                  error!(@message.error_messages, UNPROCESSABLE_ENTITY)
                end
              end
            end
          end
        end
      end
    end
  end
end
