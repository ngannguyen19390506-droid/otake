# == Schema Information
#
# Table name: nursing_care_histories
#
#  id                        :bigint           not null, primary key
#  blood_pressure            :string
#  cleaning                  :string
#  complexion                :integer
#  consultation_assistance   :boolean
#  defecation                :integer
#  diaper_check              :boolean
#  division                  :integer
#  dressing_assistance       :boolean
#  eating_assistance         :string
#  end_time                  :string
#  end_time_format           :string
#  environmental_arrangement :boolean
#  full_body_bath            :string
#  full_body_bath_procedure  :boolean
#  hydration                 :integer
#  is_staff_update           :boolean
#  maintain_posture          :boolean
#  note                      :text
#  oral_care                 :boolean
#  pad_confirmation          :boolean
#  physical_care             :integer
#  position_exchange         :boolean
#  record                    :boolean
#  start_time                :string
#  start_time_format         :string
#  summary                   :text
#  sweating                  :integer
#  temperature               :string
#  toilet_assistance         :boolean
#  transfer_assistance       :boolean
#  updated_time              :string
#  urinal_cleaning           :boolean
#  urination                 :integer
#  washbasin                 :boolean
#  washing_hair              :boolean
#  watch_over                :boolean
#  created_at                :datetime         not null
#  updated_at                :datetime         not null
#  nurse_id                  :bigint
#  patient_id                :bigint           not null
#  schedule_date_id          :bigint
#  service_id                :bigint
#  service_type_id           :bigint
#
# Indexes
#
#  index_nursing_care_histories_on_patient_id        (patient_id)
#  index_nursing_care_histories_on_schedule_date_id  (schedule_date_id)
#  index_nursing_care_histories_on_service_id        (service_id)
#  index_nursing_care_histories_on_service_type_id   (service_type_id)
#
class NursingCareHistory < ApplicationRecord
  include ApiCommon

  belongs_to :nurse, class_name: 'NursingStaff', optional: true
  belongs_to :patient
  belongs_to :schedule_date
  belongs_to :service
  belongs_to :service_type
  has_many :nursing_care_history_changes, dependent: :destroy

  validates :division, :complexion, :sweating, presence: true

  enum division: { disability: 0, normal: 1 }
  enum physical_care: { body: 1, life: 2, severe_visit: 3 }
  enum complexion: { bad: 0, good: 1 }
  enum sweating: { no: 0, yes: 1 }

  validates :hydration, numericality: { only_integer: true }, length: { in: 0..MAX_LENGTH_FIVE_HUNDRED }, allow_nil: true
  validates :defecation, :urination, numericality: { only_integer: true }, length: { in: 0..MIN_LENGTH_TEN }, allow_nil: true
  validates :eating_assistance, :cleaning, inclusion: { in: %w[なし 全部 一部], allow_nil: true }
  validates :full_body_bath, inclusion: { in: %w[なし 入浴 シャワー浴], allow_nil: true }

  validate :validate_physical_care
  validate :validate_service

  scope :staff_updated, -> { where(is_staff_update: true) }

  ransacker :status, formatter: proc { |v| statuses[v] } do |parent|
    parent.table[:status]
  end

  def validate_physical_care
    return if physical_care.blank?

    if normal? && %w[body life].exclude?(physical_care)
      errors.add(:physical_care, 'should be body or life when division is normal')
    elsif disability? && %w[body severe_visit].exclude?(physical_care)
      errors.add(:physical_care, 'should be body or severe_visit when division is disability')
    end
  end

  def validate_service
    service = Service.find(service_id)
    if normal?
      errors.add(:messages, I18n.t('activerecord.errors.messages.record_invalid')) unless service.normal?
    elsif disability?
      errors.add(:messages, I18n.t('activerecord.errors.messages.record_invalid')) unless service.disability?
    end
  end

  def self.ransackable_attributes(auth_object = nil)
    ["cleaning", "complexion", "consultation_assistance", "created_at", "defecation", "diaper_check", "division", "dressing_assistance", "eating_assistance", "end_time", "environmental_arrangement", "full_body_bath", "full_body_bath_procedure", "hydration", "id", "maintain_posture", "note", "nurse_id", "oral_care", "pad_confirmation", "patient_id", "physical_care", "position_exchange", "record", "schedule_date_id", "service_id", "service_type_id", "start_time", "sweating", "toilet_assistance", "transfer_assistance", "updated_at", "urinal_cleaning", "urination", "washbasin", "washing_hair", "watch_over"]
  end

  def self.ransackable_associations(auth_object = nil)
    ["nurse", "patient", "schedule_date", "service", "service_type"]
  end
end
