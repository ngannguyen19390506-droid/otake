class UpdateToEvalueTwo < ActiveRecord::Migration[7.0]
  def change
    # staple_food
    change_column :evalue_twos, :staple_food, :string
    add_column :evalue_twos, :has_regular_staple_food, :boolean, default: false
    add_column :evalue_twos, :has_porridge_staple_food, :boolean, default: false
    add_column :evalue_twos, :has_rice_staple_food, :boolean, default: false
    # side_meal
    add_column :evalue_twos, :has_regular_side_meal, :boolean, default: false
    add_column :evalue_twos, :has_minced_side_meal, :boolean, default: false
    add_column :evalue_twos, :has_blended_side_meal, :boolean, default: false
    add_column :evalue_twos, :has_bite_sized_side_meal, :boolean, default: false
    # toromi
    add_column :evalue_twos, :is_toromi, :boolean, default: false
    # support
    add_column :evalue_twos, :support_level, :integer
    # eating_utensil
    add_column :evalue_twos, :has_chopsticks, :boolean, default: false
    add_column :evalue_twos, :has_spoon, :boolean, default: false
    add_column :evalue_twos, :has_fork, :boolean, default: false
    # luxury_goods
    add_column :evalue_twos, :has_tobacco, :boolean, default: false
    add_column :evalue_twos, :has_alcohol, :boolean, default: false
    add_column :evalue_twos, :has_no_luxury_goods, :boolean, default: false
    # is_allergic
    add_column :evalue_twos, :allergic, :string
    # neck
    add_column :evalue_twos, :has_paralysis_neck, :boolean, default: false
    add_column :evalue_twos, :has_contracture_neck, :boolean, default: false
    add_column :evalue_twos, :has_other_neck, :boolean, default: false
    add_column :evalue_twos, :has_no_problem_neck, :boolean, default: false
    # upper_limb
    add_column :evalue_twos, :has_paralysis_upper_limb, :boolean, default: false
    add_column :evalue_twos, :has_contracture_upper_limb, :boolean, default: false
    add_column :evalue_twos, :has_other_upper_limb, :boolean, default: false
    add_column :evalue_twos, :has_no_problem_upper_limb, :boolean, default: false
    # belt
    add_column :evalue_twos, :has_paralysis_belt, :boolean, default: false
    add_column :evalue_twos, :has_contracture_belt, :boolean, default: false
    add_column :evalue_twos, :has_other_belt, :boolean, default: false
    add_column :evalue_twos, :has_no_problem_belt, :boolean, default: false
    # hip_joint
    add_column :evalue_twos, :has_paralysis_hip_joint, :boolean, default: false
    add_column :evalue_twos, :has_contracture_hip_joint, :boolean, default: false
    add_column :evalue_twos, :has_other_hip_joint, :boolean, default: false
    add_column :evalue_twos, :has_no_problem_hip_joint, :boolean, default: false
    # bottom
    add_column :evalue_twos, :has_paralysis_bottom, :boolean, default: false
    add_column :evalue_twos, :has_contracture_bottom, :boolean, default: false
    add_column :evalue_twos, :has_other_bottom, :boolean, default: false
    add_column :evalue_twos, :has_no_problem_bottom, :boolean, default: false
    # sight
    add_column :evalue_twos, :is_disability_sight, :boolean, default: true
    # glasses
    add_column :evalue_twos, :has_glasses, :boolean, default: true
    # hearing
    add_column :evalue_twos, :is_disability_hearing, :boolean, default: true
    # language
    add_column :evalue_twos, :is_disability_language, :boolean, default: true
    # form_movement
    add_column :evalue_twos, :has_independence, :boolean, default: false
    add_column :evalue_twos, :has_cane, :boolean, default: false
    add_column :evalue_twos, :has_wheelchair, :boolean, default: false
    add_column :evalue_twos, :has_walker, :boolean, default: false
    add_column :evalue_twos, :has_support_person, :boolean, default: false
    # move
    add_column :evalue_twos, :move_level, :integer
    # stand
    add_column :evalue_twos, :stand_level, :integer
    # sit
    add_column :evalue_twos, :sit_level, :integer
    # wash_face
    add_column :evalue_twos, :wash_face_level, :integer
    # head_washing
    add_column :evalue_twos, :head_washing_level, :integer
    # removable
    add_column :evalue_twos, :removable_level, :integer
    # grooming
    add_column :evalue_twos, :grooming_level, :integer
    # excretory_form
    add_column :evalue_twos, :has_independence_excretory, :boolean, default: false
    add_column :evalue_twos, :has_rehab_pant_excretory, :boolean, default: false
    add_column :evalue_twos, :has_paper_diaper_excretory, :boolean, default: false
    add_column :evalue_twos, :has_pad_excretory, :boolean, default: false
    # is_urgent_urination
    add_column :evalue_twos, :urgent_urination_excretion, :string
    # is_benefit
    add_column :evalue_twos, :benefit_excretion, :string
    # is_incontinence
    add_column :evalue_twos, :allergic_excretion, :string
    # is_crushing_process
    add_column :evalue_twos, :crushing_process, :string
    # swallow
    add_column :evalue_twos, :is_normal_swallow, :boolean, default: true
    # dentures
    add_column :evalue_twos, :has_full_dentures, :boolean, default: false
    add_column :evalue_twos, :has_upper_dentures, :boolean, default: false
    add_column :evalue_twos, :has_lower_dentures, :boolean, default: false
    add_column :evalue_twos, :has_partial_dentures, :boolean, default: false
    add_column :evalue_twos, :has_no_dentures, :boolean, default: false
    # recognition
    add_column :evalue_twos, :cognitive_level, :integer
    # declaration_intent
    add_column :evalue_twos, :is_possible_declaration_intent, :boolean, default: true
    # understanding
    add_column :evalue_twos, :is_possible_understanding, :boolean, default: true
    # is_wandering
    add_column :evalue_twos, :wandering, :string
    # is_violence
    add_column :evalue_twos, :violence, :string
    # is_delusion
    add_column :evalue_twos, :delusion, :string
    # is_denial
    add_column :evalue_twos, :denial, :string
    # is_treatment
    add_column :evalue_twos, :treatment, :string
    # dosage
    add_column :evalue_twos, :dosage_level, :integer
  end
end
