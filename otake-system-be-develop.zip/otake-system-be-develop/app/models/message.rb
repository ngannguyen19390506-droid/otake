# == Schema Information
#
# Table name: messages
#
#  id            :bigint           not null, primary key
#  content       :string           not null
#  read_at       :datetime
#  receiver_type :string
#  sender_type   :string
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#  receiver_id   :integer
#  room_id       :bigint           not null
#  sender_id     :bigint           not null
#
# Indexes
#
#  index_messages_on_room_id                    (room_id)
#  index_messages_on_sender_type_and_sender_id  (sender_type,sender_id)
#
# Foreign Keys
#
#  fk_rails_...  (room_id => rooms.id)
#
class Message < ApplicationRecord
  include ApiCommon
  belongs_to :room
  belongs_to :sender, polymorphic: true

  validates :content, presence: true
end
