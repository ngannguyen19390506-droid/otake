# == Schema Information
#
# Table name: patients
#
#  id                            :bigint           not null, primary key
#  birth_date                    :date             not null
#  building_name                 :string
#  cellphone_number              :string
#  city                          :string           not null
#  current_illness_history       :text
#  district                      :string           not null
#  encrypted_password            :string
#  family_interview              :text
#  family_name                   :string
#  first_name                    :string           not null
#  first_name_kana               :string           not null
#  hex_color                     :string
#  home_care_support_office_name :text
#  last_name                     :string           not null
#  last_name_kana                :string           not null
#  leave_date                    :date
#  name_kana                     :string
#  password                      :string
#  patient_code                  :string           not null
#  period_contract               :date             not null
#  personal_interview            :text
#  sex                           :integer          not null
#  status                        :integer          not null
#  street                        :string           not null
#  telephone_number              :string           not null
#  zipcode                       :string
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#
require 'bcrypt'
class Patient < ApplicationRecord
  include ApiCommon

  enum status: { using: 0, pause: 1, suspended: 2 }
  enum sex: { 女: 0, 男: 1 } # female: 0, male: 1

  has_many :patient_shift_manages, dependent: :destroy
  has_many :messages, as: :user
  has_many :contact_relatives, dependent: :destroy
  has_many :authentication_tokens, dependent: :destroy
  has_many :public_expenses, dependent: :destroy
  has_many :nursing_care_plans, dependent: :destroy
  has_many :disability_care_plans, dependent: :destroy
  has_many :schedules, dependent: :destroy
  has_many :schedule_dates, through: :schedules
  has_many :nursing_care_histories, dependent: :destroy
  has_many :change_histories, as: :changeable, dependent: :destroy
  has_many :insurance_cards, dependent: :destroy
  has_many :equipment_service_payments, dependent: :destroy
  has_many :payment_histories, dependent: :destroy
  has_many :usage_billings, dependent: :destroy
  has_many :rent_billings, dependent: :destroy
  has_many :patient_receipts, dependent: :destroy
  has_many :care_plan_at_homes, dependent: :destroy
  has_many :schedule_memo_at_homes, through: :care_plan_at_homes
  has_many :schedule_at_homes, through: :care_plan_at_homes
  has_many :service_home_systems, through: :schedule_at_homes
  has_many :daily_healths, through: :care_plan_at_homes
  has_many :equipment_home_systems, dependent: :destroy
  has_many :schedule_routines, through: :schedules

  has_many :evalue_ones, dependent: :destroy
  has_many :evalue_twos, dependent: :destroy
  has_one :hospital, dependent: :destroy
  has_one :payment, dependent: :destroy
  has_many :recipients, dependent: :destroy

  validates :telephone_number, :birth_date, :sex, :last_name, :first_name, :last_name_kana, :first_name_kana,
            :district, :city, :street, :period_contract, :patient_code, presence: true
  validates :telephone_number, length: { in: MIN_LENGTH_TEN..MAX_LENGTH_TWENTY }
  validates :cellphone_number, length: { in: MIN_LENGTH_TEN..MAX_LENGTH_TWENTY }, allow_blank: true
  validates :zipcode, format: { with: ZIP_CODE_REGEX }
  validates :last_name, :first_name,
            format: { with: NAME_REGEX, message: I18n.t('errors.messages.name_invalid') }
  validates :last_name_kana, :first_name_kana,
            format: { with: NAME_KATAKANA_REGEX, message: I18n.t('errors.messages.name_invalid') }
  # validate :validate_address_with_zipcode

  scope :by_patient_code_asc, -> { order(patient_code: :asc) }
  scope :by_patient_code_desc, -> { order(patient_code: :desc) }
  accepts_nested_attributes_for :contact_relatives
  accepts_nested_attributes_for :hospital

  scope :order_by_payment_history, ->(sort_key, sort_order, year_month_payment) do
    query = left_outer_joins(:payment_histories)

    query = case sort_key
            when 'payment_history_expected_date'
              query.order(Arel.sql("COALESCE(payment_histories.expected_date, '#{year_month_payment}/20') #{sort_order}"))
            when 'payment_history_status'
              query.order("payment_histories.actual_date #{sort_order}")
            else
              query.order("payment_histories.actual_date #{sort_order} NULLS LAST")
            end

    query
  end

  def self.ransackable_attributes(_auth_object = nil)
    %w[family_name name_kana]
  end

  def self.ransackable_associations(_auth_object = nil)
    %w[contact_relatives hospital]
  end

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_tracked_changes
      all_changes.each do |changed_attribute, (before_value, after_value)|
        process_changes(changed_attribute, before_value, after_value, user_admin_id)
      end
    rescue StandardError => e
      e
    end
  end

  def schedule_date_at_homes
    schedule_homeable_id = schedule_memo_at_homes.pluck(:id) + schedule_at_homes.pluck(:id)
    ScheduleDateAtHome.where(schedule_homeable_id: schedule_homeable_id)
  end

  private

  def extract_tracked_changes
    tracked_changes = previous_changes.reject do |attr, _|
      %w[encrypted_password first_name last_name first_name_kana last_name_kana created_at updated_at].include?(attr)
    end
    contact_relatives_changes = extract_contact_relatives_changes(contact_relatives)
    hospital_changes = extract_hospital_changes(hospital)
    tracked_changes.merge(contact_relatives: contact_relatives_changes, hospital: hospital_changes)
  end

  def process_changes(changed_attribute, before_value, after_value, user_admin_id)
    if changed_attribute == 'contact_relatives'
      process_contact_relatives_changes(before_value, after_value, user_admin_id)
    elsif changed_attribute == 'hospital' && before_value.present?
      process_hospital_changes(before_value, user_admin_id)
    elsif changed_attribute != 'contact_relatives' && changed_attribute != 'hospital'
      if changed_attribute == 'status'
        before_value = attribute_description("status.#{before_value}")
        after_value = attribute_description("status.#{after_value}")
      end

      text_description = attribute_description(changed_attribute)
      create_change_history(user_admin_id, text_description, before_value, after_value)
    end
  end

  def process_hospital_changes(before_value, user_admin_id)
    before_value.each do |attr, (before_hospital_value, after_hospital_value)|
      hospital_text_description = attribute_description("hospital.#{attr}")
      create_change_history(user_admin_id, hospital_text_description, before_hospital_value, after_hospital_value)
    end
  end

  def extract_hospital_changes(hospital)
    extract_changes_without_timestamps(hospital&.previous_changes) || {}
  end

  def attribute_description(attribute_name)
    descriptions = {
      'family_name' => '氏名',
      'name_kana' => '氏名(カナ)',
      'sex' => '性別',
      'birth_date' => '生年月日',
      'zipcode' => '郵便番号',
      'district' => '都道府県',
      'city' => '市区町村',
      'street' => '町名・番地',
      'building_name' => 'ビル・マンション名',
      'telephone_number' => '携帯番号1',
      'cellphone_number' => '携帯番号2',
      'my_number' => 'マイナンバー',
      'status' => '利用状況',
      'period_contract' => '契約日',
      'current_illness_history' => '現病・既往歴',
      'family_interview' => 'ご家族聞き取り',
      'personal_interview' => 'ご本人聞き取り',
      'leave_date' => '退所日',
      'contact_relatives.first.name' => '緊急連絡先①の氏名',
      'contact_relatives.first.relationship' => '緊急連絡先①の続柄',
      'contact_relatives.first.address' => '緊急連絡先①の住所',
      'contact_relatives.first.telephone_number' => '緊急連絡先①の電話番号',
      'contact_relatives.first.cellphone_number' => '緊急連絡先①の携帯番号',
      'contact_relatives.second.name' => '緊急連絡先②の氏名',
      'contact_relatives.second.relationship' => '緊急連絡先②の続柄',
      'contact_relatives.second.address' => '緊急連絡先②の住所',
      'contact_relatives.second.telephone_number' => '緊急連絡先②の電話番号',
      'contact_relatives.second.cellphone_number' => '緊急連絡先②の携帯番号',
      'hospital.name' => '病院名',
      'hospital.clinical_department' => '診療科',
      'hospital.phone' => '電話番号',
      'hospital.address' => '住所',
      'status.using' => '利用中',
      'status.pause' => '一時停止',
      'status.suspended' => '利用停止'
    }
    descriptions[attribute_name] || attribute_name
  end
end
