class CreateMessage < ActiveRecord::Migration[7.0]
  def change
    create_table :messages do |t|
      t.references :user,     null: false, polymorphic: true
      t.references :room,     null: false, foreign_key: true
      t.string     :content,  null: false
      t.datetime   :day_send, null: false

      t.timestamps
    end
  end
end
