module V1
  module AdminHomeSystem
    class EquipmentServiceSerializer < ActiveModel::Serializer
      attributes :id,
                 :position,
                 :category,
                 :display_name,
                 :service_name,
                 :stock_quantity,
                 :unit_price,
                 :unit_price_setting

      has_many :equipment_home_systems

      def initialize(equipment_service, options = {})
        super(equipment_service, options)
        @year_month = options[:year_month]
        @patient_id = options[:patient_id]
      end

      def equipment_home_systems
        equipment_home_system = object.equipment_home_systems.find do |payment|
          payment.patient_id == @patient_id && payment.year_month == @year_month
        end
        if equipment_home_system.present?
          EquipmentHomeSystemSerializer.new(equipment_home_system).as_json
        else
          nil
        end
      end
    end
  end
end
