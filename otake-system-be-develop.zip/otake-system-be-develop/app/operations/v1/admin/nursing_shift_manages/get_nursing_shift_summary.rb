module V1
  module Admin
    module NursingShiftManages
      class GetNursingShiftSummary < ::ApplicationOperation
        def call(params)
          if params[:tab] == 'client'
            return { data: handle_client_tab(params).merge!(confirm_shift: confirm_shift) } if params[:month_date].present?

            { data: handle_client_tab(params) }.merge!(has_initial: has_initial(params[:tab]))
          else
            return { data: handle_staff_tab(params).merge!(confirm_shift: confirm_shift) } if params[:month_date].present?

            { data: handle_staff_tab(params) }.merge!(has_initial: has_initial(params[:tab]))
          end
        end

        private

        def handle_client_tab(params)
          if params[:month_date].present?
            get_nursing_shift_summary_by_month(params[:month_date], params[:tab])
          elsif params[:week_start_date].present? && params[:week_end_date].present?
            get_nursing_shift_summary_by_week(params[:week_start_date], params[:week_end_date]).values
          elsif params[:specific_date].present?
            get_nursing_shift_summary_by_date(params[:specific_date]).values
          end
        end

        def handle_staff_tab(params)
          if params[:month_date].present?
            get_nursing_shift_summary_by_month(params[:month_date], params[:tab])
          elsif params[:week_start_date].present? && params[:week_end_date].present?
            get_staff_shift_summary_by_week(params[:week_start_date], params[:week_end_date]).values
          elsif params[:specific_date].present?
            get_staff_shift_summary_by_date(params[:specific_date]).values
          end
        end

        def format_duration(hours)
          minutes = ((hours - hours.floor) * 60).round
          "#{hours.floor}時間#{minutes}分"
        end

        def calculate_formatted_nurse_work_duration(start_date, end_date)
          nursing_staffs = NursingStaff.includes(:shifts).default_order
          results = []

          nursing_staffs.each do |staff|
            total_work_time = 0
            staff.shifts.where(shift_date: start_date..end_date).each do |shift|
              start_time = Time.zone.parse(shift.start_time)
              end_time = Time.zone.parse(shift.end_time)
              work_duration = (end_time - start_time) / 3600.0
              total_work_time += work_duration
            end

            results << staff.attributes.merge!(format_duration_hash({ total_work_time: total_work_time })).slice('id', 'name_kana', 'family_name', :total_work_time)
          end

          results
        end

        def calculate_time_shifts_per_day(start_date, end_date)
          shifts = ShiftManagement.joins(:nursing_shift_manages).where(shift_date: (start_date..end_date)).where.not(nursing_shift_manages: { status: 'initial' }).group_by(&:shift_date)
          total_work_time_per_day = {}
          shifts.each do |shift_date, shift_managements|
            total_work_time = 0
            shift_managements.each do |shift_management|
              start_time = Time.zone.parse(shift_management.start_time)
              end_time = Time.zone.parse(shift_management.end_time)
              work_duration = (end_time - start_time) / 3600.0 # Chuyển đổi sang giờ
              total_work_time += work_duration
            end

            total_work_time_per_day[shift_date] = total_work_time
          end

          format_duration_hash(total_work_time_per_day.sort.to_h)
        end

        def format_duration_hash(duration_hash)
          formatted_hash = {}
          duration_hash.each do |key, total_hours|
            formatted_hash[key] = format_duration(total_hours)
          end
          formatted_hash
        end

        def get_nursing_shift_summary_by_month(month_date, tab)
          start_date = month_date.to_date.beginning_of_month
          end_date = month_date.to_date.end_of_month
          total_shifts_per_day = Schedule.joins(:schedule_dates)
                                         .where('schedule_dates.date BETWEEN :start_date AND :end_date', {
                                                  start_date: start_date,
                                                  end_date: end_date
                                                }).group(
                                                  'schedule_dates.date'
                                                ).count

          nurse_shifts = ScheduleDate.where(date: start_date..end_date).pluck(:nurse_id, :date).select { |nurse_id, _| nurse_id.present? }
          shifts_with_nurses_per_day = nurse_shifts.reject do |nurse_id, _|
                                         nurse_id.nil?
                                       end.group_by { |_, date| date }.transform_values(&:count)
          formatted_nurse_work_duration = calculate_formatted_nurse_work_duration(start_date, end_date)
          total_time_shifts_per_day = calculate_time_shifts_per_day(start_date, end_date)
          beginning_of_next_month = Date.current.at_beginning_of_month.next_month
          end_of_next_month = Date.current.end_of_month.next_month
          {
            total_shifts_per_day: total_shifts_per_day,
            shifts_with_nurses_per_day: shifts_with_nurses_per_day,
            total_time_shifts_per_day: total_time_shifts_per_day,
            nurse_work_duration_on_month: formatted_nurse_work_duration,
            has_initial: has_initial(tab).present?,
            show_create_buttons: (beginning_of_next_month..end_of_next_month).include?(start_date)
          }
        end

        def get_nursing_shift_summary_by_week(week_start_date, week_end_date)
          schedules_with_dates_on_week = Schedule.includes(:patient, :schedule_dates).for_week(week_start_date, week_end_date)

          data_by_patient = {}
          schedules_with_dates_on_week.each do |schedule|
            schedule.schedule_dates.each do |schedule_date|
              add_shift_to_data(data_by_patient, schedule.patient, schedule, schedule_date)
            end
          end

          data_by_patient
        end

        def add_shift_to_data(data_by_patient, patient, schedule, schedule_date)
          date = schedule_date.date.to_s
          time_range = "#{schedule_date.start_time} ~ #{schedule_date.end_time}"
          nurse_name = nurse_name(schedule_date)
          service_name = schedule.service_type.detail
          data_by_patient[patient.id] ||= patient.attributes.merge!({ shifts: {} }).slice('id', 'name_kana', 'family_name', :shifts)
          data_by_patient[patient.id][:shifts][date] ||= []

          return if shift_exists?(data_by_patient[patient.id][:shifts][date], nurse_name, time_range, service_name)

          data_by_patient[patient.id][:shifts][date] << { nurse_name: nurse_name, time_range: time_range,
                                                          service_name: service_name }
        end

        def shift_exists?(shifts, nurse_name, time_range, service_name)
          shifts.any? do |entry|
            entry[:nurse_name] == nurse_name && entry[:time_range] == time_range && entry[:service_name] == service_name
          end
        end

        def get_nursing_shift_summary_by_date(specific_date)
          date = specific_date.to_date

          data_by_patient = {}
          schedules_with_dates_on_date = Schedule.includes(:patient, :schedule_dates).for_date(date)

          schedules_with_dates_on_date.each do |schedule|
            schedule.schedule_dates.each do |schedule_date|
              add_shift_to_patient(data_by_patient, schedule_date)
            end
          end

          data_by_patient
        end

        def add_shift_to_patient(data_by_patient, schedule_date)
          time_range = "#{schedule_date.start_time} ~ #{schedule_date.end_time}"
          patient = schedule_date.scheduleable&.patient
          service_name = schedule_date.scheduleable.service_type.detail
          date = schedule_date.date.to_s
          nurse_name = nurse_name(schedule_date)
          data_by_patient[patient.id] ||= patient.attributes.merge!({ shifts: {} }).slice('id', 'name_kana', 'family_name', :shifts, :scheduleable)
          data_by_patient[patient.id][:shifts] ||= {}
          data_by_patient[patient.id][:shifts][service_name] ||= []
          data_by_patient[patient.id][:shifts][service_name] << { time_range: time_range, nurse_name: nurse_name,
            schedule: schedule_date.scheduleable, schedule_date: schedule_date }
        end

        def nurse_name(schedule_date)
          schedule_date.nurse&.family_name
        end

        def get_staff_shift_summary_by_week(week_start_date, week_end_date)
          staffs = NursingStaff.includes(:schedule_dates, nursing_shift_manages: :shift)
                                       .where(shift: { shift_date: week_start_date..week_end_date })
          shifts_by_nurse = {}
          staffs.each do |staff|
            schedule_dates = staff.schedule_dates.select do |schedule_date|
              (week_start_date..week_end_date).include?(schedule_date.date)
            end
            if schedule_dates.blank?
              shifts_by_nurse[staff.id] ||= staff.attributes.merge!({ shifts: {} }).slice('id', 'name_kana', 'family_name', :shifts)
              next
            end

            schedule_dates.each do |schedule_date|
              shifts_by_nurse[staff.id] ||= staff.attributes.merge!({ shifts: {} }).slice('id', 'name_kana', 'family_name', :shifts)
              shifts_by_nurse[staff.id][:shifts][schedule_date.date] ||= []
              shifts_by_nurse[staff.id][:shifts][schedule_date.date] << nursing_shift_data(schedule_date)
            end
          end

          shifts_by_nurse
        end

        def get_staff_shift_summary_by_date(specific_date)
          staffs = NursingStaff.includes(:schedule_dates, :shifts, nursing_shift_manages: :shift).where(shift: { shift_date: specific_date }).default_order
          shifts_by_nurse = {}
          staffs.each do |staff|
            schedule_dates = staff.schedule_dates.select { |schedule_date| schedule_date.date == specific_date }
            shift_managements = staff.shifts.select { |shift| shift.shift_date == specific_date }

            shifts_by_nurse[staff.id] ||= staff.attributes.merge!({ shifts: {}, shift_managements: shift_managements })
                                                          .slice('id', 'name_kana', 'family_name', :shifts, :shift_managements)

            next if schedule_dates.blank?

            schedule_dates.each do |schedule_date|
              service_name = schedule_date.scheduleable.service_type.detail
              shifts_by_nurse[staff.id][:shifts] ||= {}
              shifts_by_nurse[staff.id][:shifts][service_name] ||= []
              shifts_by_nurse[staff.id][:shifts][service_name] << nursing_shift_data(schedule_date)
            end
          end

          shifts_by_nurse
        end

        def nursing_shift_data(schedule_date)
          time_range = "#{schedule_date.start_time} ~ #{schedule_date.end_time}"
          {
            patient_name: schedule_date.scheduleable.patient.family_name,
            time_range: time_range,
            service_name: schedule_date&.scheduleable&.service_type&.detail,
            schedule_date: schedule_date
          }
        end

        def find_schedule_date(nursing_shift)
          date = nursing_shift.shift.shift_date.to_s
          ScheduleDate.where(nurse_id: nursing_shift.nurse_id)
                      .find_by(date: date,
                               start_time: nursing_shift.shift.start_time,
                               end_time: nursing_shift.shift.end_time)
        end

        def has_initial(tab)
          next_month = Date.current.next_month
          year_month = next_month.strftime('%Y/%m')
          beginning_of_next_month = next_month.at_beginning_of_month
          end_of_next_month = next_month.end_of_month
          if tab == 'client'
            ScheduleDate.where(status: 'initial', date: beginning_of_next_month..end_of_next_month).where.not(nurse: nil).present?
          else
            shifts = NursingShiftManage.includes(:shift).where(status: 'initial', shift: { shift_date: beginning_of_next_month..end_of_next_month }).present?
            holidays = Holiday.where(date: beginning_of_next_month..end_of_next_month, status: 'initial' )
            shifts.present? || holidays.present?
          end
        end

        def confirm_shift()
          year_month = Date.current.next_month.strftime('%Y/%m')
          confirmed_by_admin = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_admin: false)
          confirmed_by_staff = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_staff: false)
          staffs_acitve = NursingStaff.active
          monthly_holidays = MonthlyHoliday.where(year_month: year_month)
          return {} if monthly_holidays.count < staffs_acitve.count

          { confirmed_by_admin: confirmed_by_admin.blank?, confirmed_by_staff: confirmed_by_staff.blank?, status: monthly_holidays.last.status }
        end
      end
    end
  end
end
