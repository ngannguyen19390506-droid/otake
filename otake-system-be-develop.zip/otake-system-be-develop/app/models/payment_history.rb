# == Schema Information
#
# Table name: payment_histories
#
#  id            :bigint           not null, primary key
#  actual_date   :date             not null
#  expected_date :date             not null
#  year_month    :string           not null
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#  patient_id    :bigint           not null
#
# Indexes
#
#  index_payment_histories_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class PaymentHistory < ApplicationRecord
  include ApiCommon
  belongs_to :patient

  validates :expected_date, :actual_date, :year_month, presence: true
  validates :year_month, format: { with: YEAR_MONTH, message: I18n.t('errors.messages.year_month_format_invalid') }
end
