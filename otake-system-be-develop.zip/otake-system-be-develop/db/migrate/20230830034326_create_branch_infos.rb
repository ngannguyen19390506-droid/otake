class CreateBranchInfos < ActiveRecord::Migration[7.0]
  def change
    create_table :branch_infos do |t|
      t.string :branch_name
      t.string :brach_name_kana
      t.string :branch_code
      t.integer :bank_info_id

      t.timestamps
    end

    remove_column :bank_infos, :branch_name
    remove_column :bank_infos, :branch_name_kana
    remove_column :bank_infos, :branch_code
  end
end
