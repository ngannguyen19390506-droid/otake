module V1
  module Admin
    class ScheduleDateApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :schedule_dates do
          # index services
          desc 'GET /api/v1/admin/schedule_dates/by_month'
          params do
            requires :date_from, type: Date, default: Date.current.beginning_of_month
            requires :date_to, type: Date, default: Date.current.end_of_month
          end
          get 'by_month' do
            service = ::V1::Admin::ScheduleDates::GetByMonth.call(params[:date_from], params[:date_to])

            present :schedule_dates, service.value!
          end

          desc 'GET /api/v1/admin/schedule_dates/by_customer'
          params do
            requires :date_from, type: Date, default: Date.current.beginning_of_month
            requires :date_to, type: Date, default: Date.current.end_of_month
          end
          get 'by_customer' do
            service = ::V1::Admin::ScheduleDates::GetByCustomer.call(params[:date_from], params[:date_to])

            present :patients, service.value!
          end

          desc 'PUT api/v1/admin/schedule_dates/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
            requires :nurse_id, type: Integer, message: I18n.t('error.validate.blank')
          end

          put ':id' do
            schedule_date = ScheduleDate.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            start_time = schedule_date.start_time
            end_time = schedule_date.end_time
            date = schedule_date.date
            working_nurse_ids = ScheduleDate.where.not(id: params[:id]).for_working_nurses_on_date(date, start_time, end_time).pluck(:nurse_id)
            available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(date, start_time, end_time)
            nursing_staff_ids = NursingStaff.where(id: available_nurse_ids)
                                         .where.not(id: working_nurse_ids)
                                         .includes(:degrees, nursing_shift_manages: :shift)
                                         .active.pluck(:id)
            return error!({ 'message': I18n.t('errors.messages.nurse_is_busy') }, UNPROCESSABLE_ENTITY) if nursing_staff_ids.exclude?(params[:nurse_id])

            previous_data = schedule_date.status != 'initial' ?  schedule_date.attributes : schedule_date.previous_data
            if schedule_date.update(nurse_id: params[:nurse_id], previous_data: previous_data, status: 'initial')
              { success: I18n.t('success.messages.updated'), schedule_date: schedule_date }
            else
              error!(schedule_date.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/schedule_dates/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
          end
          get ':id' do
            schedule_date = ScheduleDate.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            present schedule_date
          end
        end
      end
    end
  end
end
