module V1
  module Staff
    class NursingCarePlanSerializer < ActiveModel::Serializer
      attributes :id,
                 :patient_id,
                 :comprehensive_aid_policy,
                 :individual_family_intention,
                 :aid_purpose,
                 :start_long_term,
                 :end_long_term,
                 :start_short_term,
                 :end_short_term,
                 :remarks,
                 :year_month,
                 :aid_purpose,
                 :plan_long_terms,
                 :plan_short_terms,
                 :note

      has_many :improvement_nursing_care_plans, serializer: ImprovementNursingCarePlanSerializer
      # has_many :treatment_improvements, through: :improvement_nursing_care_plans, serializer: TreatmentImprovementSerializer
      has_many :nursing_care_plan_terms, dependent: :destroy
      def patient_id
        object.patient.id
      end

      def serializable_hash(adapter_options = nil, options = {}, adapter_instance = self.class.serialization_adapter_instance)
        hash = super
        hash[:schedules] = format_schedule(object.schedules.by_created_at_asc)
        hash
      end

      def plan_long_terms
        object.nursing_care_plan_terms.long_term
      end

      def plan_short_terms
        object.nursing_care_plan_terms.short_term
      end

      private

      def format_schedule(schedules)
        schedules_with_dates = schedules.includes(:schedule_dates)

        schedules_with_dates.map do |schedule|
          shift_dates = schedule.schedule_dates
          {
            id: schedule.id,
            service_id: schedule.service_id,
            service_type_id: schedule.service_type_id,
            frequency: schedule.frequency,
            shift_type: schedule.shift_type,
            start_time: schedule.start_time,
            end_time: schedule.end_time,
            shift_dates: shift_dates.pluck(:date).map { |date| date.strftime('%Y/%m/%d') },
            schedule_routines: schedule.schedule_routines,
            sort_index: schedule.sort_index
          }
        end
      end
    end
  end
end
