module V1
  module Admin
    class UsageBillingSerializer < ActiveModel::Serializer
      attributes :id, :patient_id, :year_month, :subsidy_amount, :exceeding_amount, :other_charge, :billing_amount, :additional, :invoice_type

      belongs_to :patient, serializer: PatientSerializer
    end
  end
end