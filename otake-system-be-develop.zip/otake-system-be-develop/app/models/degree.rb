# == Schema Information
#
# Table name: degrees
#
#  id           :bigint           not null, primary key
#  expired_date :date
#  name         :string
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#  nurse_id     :bigint           not null
#
# Indexes
#
#  index_degrees_on_nurse_id  (nurse_id)
#
# Foreign Keys
#
#  fk_rails_...  (nurse_id => nursing_staffs.id)
#
class Degree < ApplicationRecord
  belongs_to :nurse, class_name: 'NursingStaff'
end
