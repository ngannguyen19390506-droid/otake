module V1
  module Staff
    class RoutineApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :routines do
          desc 'GET api/v1/staff/routines',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          get do
            staff_routines = current_staff.routines.pluck(:regis_day)

            routines = Routine.week_days.map { |routin|
              { value: routin, text: I18n.t("day_name.#{routin}"), checked: staff_routines.include?(routin) }
            }

            data = { routines: routines }
            return data
          end

          desc 'POST api/v1/staff/routines',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :data, type: Array[JSON], desc: 'Eg: [{value: 1, checked: true}, {value: 1, checked: false},...]'
          end
          post do
            if params[:data].all? do |data|
              data[:checked] == false
            end
              return error!({ 'data': I18n.t('routine.error.all_false') },
                            BAD_REQUEST)
            end

            current_staff.routines&.destroy_all
            current_staff.nursing_schedules&.destroy_all
            params[:data].each do |data|
              next unless data[:checked]

              current_staff.routines.create(regis_day: data[:value])
            end

            staff_routines = current_staff.routines.pluck(:regis_day)

            routines = Routine.week_days.map { |routin|
              { value: routin, text: I18n.t("day_name.#{routin}"), checked: staff_routines.include?(routin) }
            }

            current_year_month = Time.current.strftime("%Y/%m")
            next_month = (Time.current.beginning_of_month + 1.month).strftime("%Y/%m")
            next_two_month = (Time.current.beginning_of_month + 2.month).strftime("%Y/%m")
            [current_year_month, next_month, next_two_month].each do |year_month|
              days = working_days_options(year_month, staff_routines, 'weekly')

              days.each do |day|
                date_format = year_month + "/#{day.to_s.rjust(2, '0')}"
                current_staff.nursing_schedules.create(date: date_format)
              end
            end

            data = { routines: routines }
            return data
          end
        end
      end
    end
  end
end
