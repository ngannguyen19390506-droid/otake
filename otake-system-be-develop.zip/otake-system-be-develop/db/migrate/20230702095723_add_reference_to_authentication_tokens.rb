class AddReferenceToAuthenticationTokens < ActiveRecord::Migration[7.0]
  def change
    change_column_null :authentication_tokens, :user_id, true

    add_reference :authentication_tokens, :nursing_staff, foreign_key: true
  end
end
