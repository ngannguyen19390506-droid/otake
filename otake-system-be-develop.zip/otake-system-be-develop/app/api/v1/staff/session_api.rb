module V1
  module Staff
    class SessionApi < V1::AppApi
      namespace :staff do
        desc 'POST api/v1/staff/login'
        params do
          requires :nurse_code, type: String, message: I18n.t('login.validate.blank')
          requires :password, type: String, message: I18n.t('login.validate.blank')
        end
        post 'login' do
          begin
            return error!(I18n.t('login.validate.blank'), UNAUTHORIZED) if params[:nurse_code].blank? || params[:password].blank?

            nursing_staff = NursingStaff.find_by(nurse_code: params[:nurse_code])
            return error!(I18n.t('login.code.invalid'), UNAUTHORIZED) if nursing_staff.blank?
            return error!(I18n.t('login.permission.not_permission'), UNAUTHORIZED) if nursing_staff.resigned?

            if nursing_staff&.password_matches?(params[:password])
              token = nursing_staff.generate_jwt(nursing_staff.nurse_code, :staff)
              { access_token: token, name_kana: nursing_staff.name_kana }
            else
              error!(I18n.t('login.password.invalid'), UNAUTHORIZED)
            end
          rescue StandardError => e
            error!(e.message, UNAUTHORIZED)
          end
        end
      end
    end
  end
end
