class ChangeColumnEvalueOnes < ActiveRecord::Migration[7.0]
  def change
    remove_column :evalue_ones, :heartbeat
    rename_column :evalue_ones, :pre_history, :life_history
    add_column :evalue_ones, :daily_rhythm_of_life, :text
  end
end
