class UpdateToEvalueOne < ActiveRecord::Migration[7.0]
  def change
    rename_column :evalue_ones, :hobby, :hobbies
    change_column :evalue_ones, :hobbies, :string
  end
end
