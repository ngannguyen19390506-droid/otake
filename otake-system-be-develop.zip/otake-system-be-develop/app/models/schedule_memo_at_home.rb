# == Schema Information
#
# Table name: schedule_memo_at_homes
#
#  id                   :bigint           not null, primary key
#  content              :string           not null
#  created_at           :datetime         not null
#  updated_at           :datetime         not null
#  care_plan_at_home_id :bigint           not null
#
# Indexes
#
#  index_schedule_memo_at_homes_on_care_plan_at_home_id  (care_plan_at_home_id)
#
# Foreign Keys
#
#  fk_rails_...  (care_plan_at_home_id => care_plan_at_homes.id)
#
class ScheduleMemoAtHome < ApplicationRecord
  include ApiCommon

  belongs_to :care_plan_at_home
  has_many :schedule_date_at_homes, as: :schedule_homeable, dependent: :destroy
end
