module V1
  module Staff
    class ScheduleApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :schedules do
          # Get schedule detail
          desc 'GET api/v1/staff/schedules/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
          end
          get ':id' do
            schedule = Schedule.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule.blank?

            present schedule
          end
        end
      end
    end
  end
end
