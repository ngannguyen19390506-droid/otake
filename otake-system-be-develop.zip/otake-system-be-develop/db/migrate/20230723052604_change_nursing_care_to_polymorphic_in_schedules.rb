class ChangeNursingCareToPolymorphicInSchedules < ActiveRecord::Migration[7.0]
  def change
    remove_column :schedules, :nursing_care_id

    add_reference :schedules, :care_plan, polymorphic: true, index: true
  end
end
