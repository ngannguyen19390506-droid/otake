class CreateImprovementNursingCarePlans < ActiveRecord::Migration[7.0]
  def change
    create_table :improvement_nursing_care_plans do |t|
      t.references :nursing_care, null: false, foreign_key: { to_table: :nursing_care_plans }
      t.references :treatment_improvement, null: false, foreign_key: true, index: { name: :idx_incp_on_improvement_id }

      t.timestamps
    end
  end
end
