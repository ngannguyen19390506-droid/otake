# == Schema Information
#
# Table name: shift_registrations
#
#  id         :bigint           not null, primary key
#  date       :date
#  note       :text
#  shift_type :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  nurse_id   :string
#
class ShiftRegistration < ApplicationRecord
  belongs_to :nurse, class_name: 'NursingStaff'

  validates :nurse_id, :date, :shift_type, presence: true
  enum shift_type: { day_off: 0, early_shift: 1, late_shift: 2, night_shift: 3, afternoon_shift: 4,
                     day_shift_1: 5, day_shift_2: 6, day_shift_3: 7, day_shift_4: 8, day_shift_5: 9,
                     required: 10, rarely: 11, day_shift: 12,
                     paid_leave: 13, symbol_o: 14, symbol_x: 15, early: 16 }

  scope :by_nurse_ids, ->(ids) { where(nurse_id: ids) }
  scope :skip_unused_shifts, -> { where.not(shift_type: ['day_shift_4', 'day_shift_5']) }

  def self.ransackable_attributes(auth_object = nil)
    ["date", "id", "nurse_id", "shift_type"]
  end

  def self.ransackable_associations(auth_object = nil)
    ["nurse"]
  end
end
