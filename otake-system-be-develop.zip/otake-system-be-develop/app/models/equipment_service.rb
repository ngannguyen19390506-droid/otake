# == Schema Information
#
# Table name: equipment_services
#
#  id                 :bigint           not null, primary key
#  category           :integer          not null
#  display_name       :string           not null
#  position           :integer
#  service_name       :string           not null
#  stock_quantity     :string
#  unit_price         :integer
#  unit_price_setting :boolean          default(FALSE)
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#
class EquipmentService < ApplicationRecord
  include ApiCommon

  has_many :equipment_service_payments, dependent: :destroy
  has_many :equipment_service_usages, through: :equipment_service_payments
  has_many :equipment_home_systems, dependent: :destroy
  has_many :equipment_usage_home_systems, through: :equipment_home_systems

  enum category: { equipment: 1, service: 2, potoro: 3 }

  validates :display_name, :service_name, :category, presence: true
  validates :unit_price, presence: true, if: :unit_price_setting?
  validates :unit_price, absence: true, unless: :unit_price_setting?
  # validates :stock_quantity, inclusion: { in: ['管理しない'] + (0..100).map(&:to_s), allow_blank: true }
  validate :unique_display_name_and_service_name_per_category
  before_create :set_default_position

  private

  def unique_display_name_and_service_name_per_category
    existing_service_name_record = EquipmentService.find_by(category: category, service_name: service_name)
    existing_display_name_record = EquipmentService.find_by(category: category, display_name: display_name)

    if existing_service_name_record != self && existing_service_name_record ||
       existing_display_name_record != self && existing_display_name_record
      errors.add(:message,
                 I18n.t('errors.messages.service_already_exists'))
    end
  end

  def set_default_position
    highest_position = EquipmentService.where(category: category).maximum(:position) || 0

    self.position = highest_position + 1
  end
end
