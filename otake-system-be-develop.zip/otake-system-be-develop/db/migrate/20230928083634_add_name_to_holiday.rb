class AddNameToHoliday < ActiveRecord::Migration[7.0]
  def change
    add_column :holidays, :name, :string, default: '希望休'
  end
end
