# == Schema Information
#
# Table name: holidays
#
#  id                 :bigint           not null, primary key
#  create_type        :integer
#  date               :date             not null
#  name               :string           default("希望休")
#  status             :integer
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#  monthly_holiday_id :bigint
#
# Indexes
#
#  index_holidays_on_monthly_holiday_id  (monthly_holiday_id)
#
# Foreign Keys
#
#  fk_rails_...  (monthly_holiday_id => monthly_holidays.id)
#
class Holiday < ApplicationRecord
  belongs_to :monthly_holiday

  enum create_type: { staff: 1, admin: 2 }
  enum status: { initial: -1, sent: 1, approved: 2 } # draft: 0, sent: 1, approved: 2

  scope :not_initial, -> { where.not(status: 'initial') }
  scope :data_display, -> { where(status: ['approved', 'sent', nil]) }
end
