module V1
  module Admin
    class SystemManagementProfileSerializer < ActiveModel::Serializer
      attributes :id, :facility_name, :zipcode, :district, :city, :street, :building_name, :mobile_phone,
                 :fax, :business_number, :grade_registration, :day_payment,
                 :rate_registration_nursing_care, :rate_registration_disability
    end
  end
end
