module V1
  module Admin
    module ScheduleDates
      class GetByCustomer < ::ApplicationOperation
        def call(date_from, date_to, params = {})
          patient_ids = ScheduleDate.
                          where(date: [date_from..date_to]).
                          joins(:schedule).
                          select('schedules.patient_id').
                          distinct.
                          page(params[:page]).per(params[:per]).pluck(:patient_id)

          patients = Patient.where(id: patient_ids).includes(:schedule_dates).
                            joins(:schedule_dates).
                            where('schedule_dates.date >= ? and schedule_dates.date <= ?', date_from, date_to)

          result_array = patients.map do |patient|
            {
              name_kana: patient.name_kana,
              first_name_kana: patient.first_name_kana,
              last_name_kana: patient.last_name_kana,
              schedule_dates: patient.schedule_dates.map do |date|
                schedule = Schedule.find(date.scheduleable_id)
                {
                  end_time: date.end_time,
                  start_time: date.start_time,
                  date: date.date,
                  nurse_first_name_kana: date.nurse.first_name_kana,
                  nurse_last_name_kana: date.nurse.last_name_kana,
                  service_name: Service.find_by(id: schedule.service_id)&.service_name,
                  service_type_detail: ServiceType.find_by(id: schedule.service_type_id)&.detail
                }
              end
            }
          end


          Success(result_array)
        end
      end
    end
  end
end
