class ChangeSendDayToReadAtInMessage < ActiveRecord::Migration[7.0]
  def change
    rename_column :messages, :day_send, :read_at
  end
end
