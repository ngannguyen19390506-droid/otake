class AddFieldsToPayment < ActiveRecord::Migration[7.0]
  def change
    rename_column :payments, :account_number_kana, :customer_number
    add_column :payments, :bank_info_id, :integer
    add_column :payments, :branch_info_id, :integer
  end
end
