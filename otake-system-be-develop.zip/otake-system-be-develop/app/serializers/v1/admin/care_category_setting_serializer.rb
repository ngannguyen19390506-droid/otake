module V1
  module Admin
    class CareCategorySettingSerializer < ActiveModel::Serializer
      attributes :id, :name, :unit, :price
    end
  end
end
