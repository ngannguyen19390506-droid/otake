module V1
  module Admin
    class NursingCareHistoryApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :nursing_care_histories do
          desc 'GET /api/v1/admin/nursing_care_histories/calendar',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :date, type: String, desc: '2024/05/10'
          end
          get 'calendar' do
            date = params[:date]
            error!({ 'messages': I18n.t('patient.error.validate.blank') }, UNPROCESSABLE_ENTITY) if date.blank?

            data = get_patient_schedules(date)
            present :patient_schedules, data
          end

          # index nursing_care_histories
          desc 'GET /api/v1/admin/nursing_care_histories',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :patient_id, type: String
            requires :start_date, type: Date, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :end_date, type: Date, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :tab, type: String, message: I18n.t('nursing_care_history.error.validate.blank'), values: %w[patient staff]
            optional :care_plan_type, type: String
            optional :nurse_id, type: String
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :no_care_history, type: String, desc: 'all|new|history'
            optional :sortKey, type: String
            optional :division, type: String
            optional :order, type: String
            optional :is_print, type: Boolean
            optional :is_pdf, type: Boolean
            optional :is_get_all, type: Boolean
          end
          get do
            if params[:tab] == 'patient'
              patient = Patient.find_by(id: params[:patient_id])
              return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

              @query = patient.schedule_dates.where(schedule_dates: { date: [params[:start_date]..params[:end_date]] })
              if params[:care_plan_type].present?
                schedule_ids_by_care_plan_type = patient.schedules.where(care_plan_type: params[:care_plan_type]).pluck(:id)
                @query = @query.where(scheduleable_id: schedule_ids_by_care_plan_type)
              end
            else
              nursing_care_conditions = { is_staff_update: true }
              if params[:is_get_all] && params[:is_pdf]
                @query = ScheduleDate.where(schedule_dates: { date: [params[:start_date]..params[:end_date]] })
                @query = @query.joins(:nursing_care_history).where(nursing_care_histories: nursing_care_conditions)
              else
                nursing_staff = NursingStaff.find_by(id: params[:nurse_id])
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_staff.blank?

                if params[:is_pdf]
                  nursing_care_conditions.merge!({ patient_id: params[:patient_id] }) if params[:patient_id].present?

                  @query = nursing_staff.schedule_dates.where(schedule_dates: { date: [params[:start_date]..params[:end_date]] })
                  @query = @query.joins(:nursing_care_history).where(nursing_care_histories: nursing_care_conditions)
                else
                  schedule_ids_by_care_plan_type = nursing_staff.schedules.where(care_plan_type: params[:care_plan_type]).pluck(:id)
                  @query = nursing_staff.schedule_dates.where(schedule_dates: { date: [params[:start_date]..params[:end_date]] })
                                        .where(scheduleable_id: schedule_ids_by_care_plan_type)
                end
              end
            end

            @query = @query.where(division: params[:division]) if params[:division].present?

            if params[:no_care_history] == 'new'
              @query = @query.joins(:nursing_care_history)
                             .where(nursing_care_histories: { complexion: nil, sweating: nil, defecation: nil,
                                                              urination: nil, hydration: nil, full_body_bath: nil })
            elsif params[:no_care_history] == 'history'
              @query = @query.joins(:nursing_care_history)
                             .where.not(nursing_care_histories: { complexion: nil, sweating: nil, defecation: nil,
                                                                  urination: nil, hydration: nil, full_body_bath: nil })
            end

            if params[:tab] == 'patient'
              @query = @query.order(date: :desc).order(:start_time_format)
            else
              @query = @query.order(date: :desc)
            end

            sort_key = params[:sortKey]
            sort_key = 'time' if sort_key == 'time-range'
            page = (params[:page].presence || 1).to_i

            if params[:tab] == 'patient'
              @nursing_care_histories = @query
            else
              @nursing_care_histories = @query.default_order
            end

            if sort_key.present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if %w[date time].include?(sort_key)
                sort_key = 'start_time' if sort_key == 'time'
                @nursing_care_histories = @query.order(sort_key => sort_order)
              elsif sort_key == 'name'
                @nursing_care_histories = @query.left_outer_joins(nursing_care_history: :nurse)
                                                .order("nurse.name_kana #{sort_order} NULLS LAST")
              else
                @nursing_care_histories = @query.left_outer_joins(:nursing_care_history)
                                                .order("nursing_care_histories.#{sort_key} #{sort_order} NULLS LAST")
              end
            end

            division_last_month = @nursing_care_histories&.first&.nursing_care_history&.division
            if !params[:is_print] && !params[:is_pdf]
              if @nursing_care_histories.is_a?(Array)
                @nursing_care_histories = Kaminari.paginate_array(@nursing_care_histories).page(page).per(params[:per])
              else
                @nursing_care_histories = @nursing_care_histories.page(page).per(params[:per])
              end
            end

            serialized_nursing_care_histories = @nursing_care_histories.map do |nursing_care_history|
              ScheduleDateSerializer.new(nursing_care_history).as_json
            end
            total_items = params[:is_print] || params[:is_pdf] ? @nursing_care_histories.count : @nursing_care_histories.total_count
            total_pages = params[:is_print] || params[:is_pdf] ? 1 : @nursing_care_histories.total_pages

            present :division_last_month, division_last_month
            present :page, page
            present :total_items, total_items
            present :total_pages, total_pages
            present :serialized_nursing_care_histories, serialized_nursing_care_histories
          end

          desc 'POST /api/v1/admin/nursing_care_histories'
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :patient_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :nurse_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :service_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :service_type_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :division, type: String, values: NursingCareHistory.divisions.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :defecation, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :complexion, type: String, values: NursingCareHistory.complexions.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :sweating, type: String, values: NursingCareHistory.sweatings.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :physical_care, type: String, values: NursingCareHistory.physical_cares.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :urination, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :hydration, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            optional :full_body_bath, type: String
            optional :environmental_arrangement, type: Boolean
            optional :consultation_assistance, type: Boolean
            optional :note, type: String
            optional :toilet_assistance, type: Boolean
            optional :diaper_check, type: Boolean
            optional :pad_confirmation, type: Boolean
            optional :urinal_cleaning, type: Boolean
            optional :maintain_posture, type: Boolean
            optional :eating_assistance, type: String
            optional :cleaning, type: String
            optional :full_body_bath_procedure, type: Boolean
            optional :washing_hair, type: Boolean
            optional :washbasin, type: Boolean
            optional :oral_care, type: Boolean
            optional :dressing_assistance, type: Boolean
            optional :position_exchange, type: Boolean
            optional :transfer_assistance, type: Boolean
            optional :watch_over, type: Boolean
            optional :start_time, type: String
            optional :end_time, type: String
            optional :start_time_format, type: String
            optional :end_time_format, type: String
            optional :record, type: Boolean
            optional :blood_pressure, type: String
            optional :temperature, type: String
            optional :summary, type: String
          end

          post do
            schedule_date = ScheduleDate.find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            if schedule_date.date > Time.zone.today.end_of_month
              return error!({ 'messages': I18n.t('errors.messages.not_found') },
                            NOT_FOUND)
            end

            nursing_staff = NursingStaff.find_by(id: params[:nurse_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_staff.blank?

            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            service = Service.find_by(id: params[:service_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service.blank?

            service_type = ServiceType.find_by(id: params[:service_type_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_type.blank?

            # if schedule_date.nursing_care_history.present?
            #   return error!({ 'messages': I18n.t('errors.messages.already_exists') },
            #                 UNPROCESSABLE_ENTITY)
            # end
            nursing_care_history = NursingCareHistory.new(params_nursing_care_history)
            if nursing_care_history.save
              { success: I18n.t('nursing_care_history.success.added') }
            else
              error!(nursing_care_history.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT /api/v1/admin/nursing_care_histories'
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            optional :patient_id, type: Integer
            optional :nurse_id, type: Integer
            optional :service_id, type: Integer
            optional :service_type_id, type: Integer
            optional :division, type: String, values: NursingCareHistory.divisions.keys
            optional :defecation, type: Integer
            optional :complexion, type: String, values: NursingCareHistory.complexions.keys
            optional :sweating, type: String, values: NursingCareHistory.sweatings.keys
            optional :physical_care, type: String, values: NursingCareHistory.physical_cares.keys
            optional :urination, type: Integer
            optional :hydration, type: Integer
            optional :full_body_bath, type: String
            optional :environmental_arrangement, type: Boolean
            optional :consultation_assistance, type: Boolean
            optional :note, type: String
            optional :toilet_assistance, type: Boolean
            optional :diaper_check, type: Boolean
            optional :pad_confirmation, type: Boolean
            optional :urinal_cleaning, type: Boolean
            optional :maintain_posture, type: Boolean
            optional :eating_assistance, type: String
            optional :cleaning, type: String
            optional :full_body_bath_procedure, type: Boolean
            optional :washing_hair, type: Boolean
            optional :washbasin, type: Boolean
            optional :oral_care, type: Boolean
            optional :dressing_assistance, type: Boolean
            optional :position_exchange, type: Boolean
            optional :transfer_assistance, type: Boolean
            optional :watch_over, type: Boolean
            optional :start_time, type: String
            optional :end_time, type: String
            optional :start_time_format, type: String
            optional :end_time_format, type: String
            optional :record, type: Boolean
            optional :updated_time, type: String
            optional :blood_pressure, type: String
            optional :temperature, type: String
            optional :summary, type: String
          end

          put do
            schedule_date = ScheduleDate.find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            nursing_care_history = schedule_date.nursing_care_history
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_care_history.blank?

            history_params = params_nursing_care_history
            if params[:updated_time].present?
              history_params.merge!({ 'updated_time' => params[:updated_time] })
            end

            if nursing_care_history.update_columns(history_params)
              schedule_date.update(nurse_id: nursing_care_history.nurse_id)
              { success: I18n.t('nursing_care_history.success.updated') }
            else
              error!(nursing_care_history.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET /api/v1/admin/nursing_care_histories/schedule_date',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
          end

          get 'schedule_date' do
            schedule_date = ScheduleDate.find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            # if schedule_date.date > Time.zone.today.end_of_month
            #   return error!({ 'messages': I18n.t('errors.messages.not_found') },
            #                 NOT_FOUND)
            # end

            @nursing_care_history = schedule_date.nursing_care_history
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @nursing_care_history.blank?

            present @nursing_care_history
          end

          desc 'GET /api/v1/admin/nursing_care_histories/pdf',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :patient_id, type: String
            requires :start_date, type: Date, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :end_date, type: Date, message: I18n.t('nursing_care_history.error.validate.blank')
            optional :nurse_id, type: String
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
          end
          get 'pdf' do
            nursing_staff = NursingStaff.find_by(id: params[:nurse_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_staff.blank?

            @query = NursingCareHistory.joins(:schedule_date)
                                       .where(nurse_id: params[:nurse_id],
                                              schedule_dates: { date: params[:start_date].to_date..params[:end_date].to_date })
            @query = @query.where.not(complexion: nil, sweating: nil, defecation: nil,
                                      urination: nil, hydration: nil, full_body_bath: nil)
            page = (params[:page].presence || 1).to_i
            @nursing_care_histories = @query.default_order
            serialized_nursing_care_histories = @nursing_care_histories.map do |nursing_care_history|
              NursingCareHistorySerializer.new(nursing_care_history).as_json
            end
            total_items = @nursing_care_histories.count
            total_pages = 1

            present :page, page
            present :total_items, total_items
            present :total_pages, total_pages
            present :serialized_nursing_care_histories, serialized_nursing_care_histories
          end
        end
      end

      helpers do
        def params_nursing_care_history
          params.slice(:schedule_date_id, :patient_id, :nurse_id, :service_id, :service_type_id, :division, :defecation,
                       :complexion, :sweating, :physical_care, :urination, :hydration, :full_body_bath, :environmental_arrangement,
                       :consultation_assistance, :note, :toilet_assistance, :diaper_check, :pad_confirmation, :urinal_cleaning,
                       :maintain_posture, :eating_assistance, :cleaning, :full_body_bath_procedure, :washing_hair, :washbasin,
                       :oral_care, :dressing_assistance, :position_exchange, :transfer_assistance, :watch_over, :start_time,
                       :end_time, :start_time_format, :end_time_format, :record, :updated_time, :blood_pressure, :temperature,
                       :summary)
        end
      end
    end
  end
end
