module V1
  module Admin
    include Rails.application.routes.url_helpers

    class ReceiptApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :receipts do
          desc 'GET  /api/v1/admin/receipts/by_patient',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
          end

          get '/by_patient' do
            patient_receipt = PatientReceipt.find_or_create_by(patient_id: params[:patient_id], year_month: params[:year_month])
            present patient_receipt
          end

          desc 'POST /api/v1/admin/receipts'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            optional :registered, type: Boolean
          end
          post do
            registered = params[:registered].present? ? params[:registered] : false
            patient_receipt = PatientReceipt.create(patient_id: params[:patient_id], year_month: params[:year_month], registered: registered)
            if params[:receipts].present?
              params[:receipts].values.each do |receipt|
                recipt = patient_receipt.receipts.create(price: receipt[:price], memo: receipt[:memo])
                if receipt[:files].present?
                  file = receipt[:files]
                  document = recipt.document_receipts.new
                  document.image.attach(io: file[:tempfile], filename: file[:filename], content_type: file[:type])
                  document.save
                end
              end
            end

            present patient_receipt
          end

          desc 'PUT /api/v1/admin/receipts/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
            optional :registered, type: Boolean
          end

          put ':id' do
            validate_file_params

            patient_receipt = PatientReceipt.find(params[:id])
            patient_receipt.update(registered: params[:registered]) if params[:registered].present?

            if params[:deleted_ids].present?
              Receipt.where(id: params[:deleted_ids])&.destroy_all
            end

            if params[:image_deleted_ids].present?
              DocumentReceipt.where(id: params[:image_deleted_ids])&.destroy_all
            end

            if params[:receipts].present?
              params[:receipts].values.each do |receipt|
                if receipt[:receipt_id].present?
                  recipt = patient_receipt.receipts.find_by(id: receipt[:receipt_id])
                  recipt.update(price: receipt[:price], memo: receipt[:memo])
                else
                  recipt = patient_receipt.receipts.create(price: receipt[:price], memo: receipt[:memo])
                end

                if receipt[:files].present?
                  recipt.document_receipts.destroy_all if recipt.document_receipts.present?

                  file = receipt[:files]
                  document = recipt.document_receipts.new
                  document.image.attach(io: file[:tempfile], filename: file[:filename], content_type: file[:type])
                  document.save
                end
              end
            end

            { success: I18n.t('success.messages.updated') }
          end

          desc 'POST /api/v1/admin/receipts/cancel-patient-receipt',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
          end

          post '/cancel-patient-receipt' do
            patient_receipt = PatientReceipt.where(patient_id: params[:patient_id],
                                                   year_month: params[:year_month])
            patient_receipt&.update_all(registered: false)

            { success: I18n.t('success.messages.updated') }
          end

          desc 'DELETE /api/v1/admin/receipts/:document_receipt_id'
          params do
            requires :document_receipt_id, type: Integer, message: I18n.t('error.validate.blank')
          end

          delete ':document_receipt_id' do
            DocumentReceipt.find_by(id: params[:document_receipt_id])&.destroy
            { success: true }
          end
        end

        helpers do
          def params_find_billing
            params.slice(:patient_id, :year_month)
          end

          def validate_file_params
            if params[:receipts].present?
              params[:receipts].values.each do |receipt|
                if receipt[:files].present?
                  file_ext = receipt[:files][:filename].to_s.delete(' ').split('.').last
                  next if ['png', 'jpg', 'jpeg', 'gif'].include?(file_ext)

                  return error!(I18n.t('error.files.format_invalid'), UNPROCESSABLE_ENTITY)
                end
              end
            end
          end
        end
      end
    end
  end
end
