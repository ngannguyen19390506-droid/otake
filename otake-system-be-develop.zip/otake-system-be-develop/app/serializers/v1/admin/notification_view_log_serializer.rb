module V1
  module Admin
    class NotificationViewLogSerializer < ActiveModel::Serializer
      attributes :id,
                 :name

      def name
        case object.viewer_type
        when 'UserAdmin'
          UserAdmin.find_by(id: object.viewer_id)&.user_name
        when 'NursingStaff'
          NursingStaff.find_by(id: object.viewer_id)&.full_name
        else
          Patient.find_by(id: object.viewer_id)&.full_name
        end
      end
    end
  end
end
