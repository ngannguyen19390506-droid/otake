class AddFieldsToInsuranceCards < ActiveRecord::Migration[7.0]
  def change
    add_column :insurance_cards, :zipcode, :string
    add_column :insurance_cards, :city, :string
    add_column :insurance_cards, :district, :string
    add_column :insurance_cards, :street, :string
  end
end
