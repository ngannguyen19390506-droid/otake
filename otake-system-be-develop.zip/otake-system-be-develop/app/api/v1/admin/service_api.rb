module V1
  module Admin
    class ServiceApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :services do
          # index services all || patient_type=normal || patient_type=disability
          desc 'GET /api/v1/admin/services'
          params do
            optional :patient_type, type: String
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
          end
          get do
            @query = Service.all
            @query = Service.where(patient_type: params[:patient_type]) if params[:patient_type].present?
            return present :data, @query.default_order if params[:get_all] == true

            page = (params[:page].presence || 1).to_i
            @services = @query.default_order
            if params[:sortKey].present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              @services = @query.order(params[:sortKey] => sort_order)
            end
            @services = @services.page(page).per(params[:per])
            serialized_services = @services.map do |service|
              ServiceSerializer.new(service).as_json
            end
            present :page, page
            present :total_items, @services.total_count
            present :total_pages, @services.total_pages
            present :serialized_services, serialized_services
          end

          desc 'POST api/v1/admin/services'
          params do
            requires :service_name, type: String, message: I18n.t('service.error.validate.blank')
            requires :unit_price, type: Integer, message: I18n.t('service.error.validate.blank')
            requires :patient_type, type: String, message: I18n.t('service.error.validate.blank'),
                                    values: Service.patient_types.keys
          end
          post do
            service = Service.new(params_service)
            service.service_code = generate_code(Service, :service_code)
            if service.save
              { success: I18n.t('success.messages.added') }
            else
              error!(service.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/services/:id'
          params do
            requires :id, type: Integer
            optional :service_name, type: String
            optional :unit_price, type: Integer
            optional :patient_type, type: String, values: Service.patient_types.keys
          end
          put ':id' do
            service = Service.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service.blank?

            if service.update(params_service)
              { success: I18n.t('success.messages.updated') }
            else
              error!(service.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Get service detail
          desc 'GET api/v1/admin/services/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            @service = Service.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @service.blank?

            present @service
          end
        end
      end

      helpers do
        def params_service
          params.slice(:service_name, :unit_price, :patient_type)
        end
      end
    end
  end
end
