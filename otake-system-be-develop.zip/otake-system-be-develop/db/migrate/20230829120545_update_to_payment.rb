class UpdateToPayment < ActiveRecord::Migration[7.0]
  def change
    change_column_null :payments, :account_number, true
    change_column_null :payments, :bank_name, true
    change_column_null :payments, :branch_name, true
    change_column_null :payments, :account_name_kana, true
    rename_column :payments, :postal_code, :zipcode
    change_column_null :payments, :zipcode, true
    remove_column :payments, :ward
    change_column :payments, :account_number_kana, :string
    change_column_default :payments, :account_type, nil
    change_column :payments, :account_type, :integer, null: true
  end
end
