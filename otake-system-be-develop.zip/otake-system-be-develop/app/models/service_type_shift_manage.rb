# == Schema Information
#
# Table name: service_type_shift_manages
#
#  id              :bigint           not null, primary key
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  service_type_id :bigint           not null
#  shift_id        :bigint           not null
#
# Indexes
#
#  index_service_type_shift_manages_on_service_type_id  (service_type_id)
#  index_service_type_shift_manages_on_shift_id         (shift_id)
#
class ServiceTypeShiftManage < ApplicationRecord
  belongs_to :shift, class_name: 'ShiftManagement'
  belongs_to :service_type
end
