module V1
  module Admin
    class ScheduleRoutineSerializer < ActiveModel::Serializer
      attributes :id,
                 :schedule_id,
                 :regis_day

    end
  end
end
