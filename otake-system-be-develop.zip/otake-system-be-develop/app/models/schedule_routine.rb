# == Schema Information
#
# Table name: schedule_routines
#
#  id          :bigint           not null, primary key
#  regis_day   :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  schedule_id :integer          not null
#
class ScheduleRoutine < ApplicationRecord
  belongs_to :schedule
end
