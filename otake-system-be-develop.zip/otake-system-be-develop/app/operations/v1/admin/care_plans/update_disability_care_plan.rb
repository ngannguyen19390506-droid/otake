module V1
  module Admin
    module CarePlans
      class UpdateDisabilityCarePlan < CarePlanBaseOperation
        def call(disability_care_plan, params_disability_care_plan, schedules, improvement_nursing_care_plans, current_user_id, patient)
          begin
            ActiveRecord::Base.transaction do
              long_terms = params_disability_care_plan[:long_terms]
              short_terms = params_disability_care_plan[:short_terms]
              if disability_care_plan.update(params_disability_care_plan.except(:long_terms, :short_terms, :is_clone))
                care_plan_type = 'DisabilityCarePlan'
                patient_type = 'disability'
                disability_care_plan.schedules.where.not(id: schedules.pluck(:id)).each do |schedule|
                  before_change = ""
                  after_change = 'プランが削除されました。'
                  create_change_history(schedule, current_user_id, '予定表', before_change, after_change)
                end

                if long_terms.present?
                  source_terms = disability_care_plan.disability_care_plan_terms.long_term.pluck(:term_goal)
                  term_histories = get_terms_change(source_terms, long_terms, 'long')
                  if term_histories.present?
                    term_histories.each do |term|
                      create_plan_change_history(disability_care_plan, current_user_id, "長期目標#{term[:row]}", term[:before_change], term[:after_change])
                    end
                  end

                  disability_care_plan.disability_care_plan_terms.long_term&.destroy_all
                  long_terms.each do |term|
                    disability_care_plan.disability_care_plan_terms.long_term.create(term_goal: term)
                  end
                end

                if short_terms.present?
                  source_terms = disability_care_plan.disability_care_plan_terms.short_term.pluck(:term_goal)
                  term_histories = get_terms_change(source_terms, long_terms, 'short')
                  if term_histories.present?
                    term_histories.each do |term|
                      create_plan_change_history(disability_care_plan, current_user_id, "短期目標#{term[:row]}", term[:before_change], term[:after_change])
                    end
                  end

                  disability_care_plan.disability_care_plan_terms.short_term&.destroy_all
                  short_terms.each do |term|
                    disability_care_plan.disability_care_plan_terms.short_term.create(term_goal: term)
                  end
                end

                disability_care_plan.schedules.where.not(id: schedules.pluck(:id))&.destroy_all
                schedules.each do |schedule_params|
                  if schedule_params[:id].present?
                    schedule = Schedule.find(schedule_params[:id])

                    # Get schedule value before change
                    source_service_id = schedule.service_id
                    source_service_name = schedule.service.service_name
                    source_service_type = schedule.service_type.detail
                    source_service_type_id = schedule.service_type_id
                    source_frequency = match_frequency_text(schedule.frequency)
                    change_service_name = Service.find_by_id(schedule_params[:service_id])&.service_name

                    # Service name
                    if source_service_id != schedule_params[:service_id]
                      before_change = source_service_name
                      after_change = change_service_name
                      create_change_history(schedule, current_user_id, '予定表のサービス名称', before_change, after_change)
                    end

                    source_start_time = schedule.start_time
                    source_end_time = schedule.end_time
                    source_start_time_convert = convert_str_to_time(source_start_time)
                    source_end_time_convert = convert_str_to_time(source_end_time)
                    param_start_time_convert = convert_str_to_time(schedule_params[:start_time])
                    param_end_time_convert = convert_str_to_time(schedule_params[:end_time])

                    # Time range
                    if source_start_time_convert != param_start_time_convert || source_end_time_convert != param_end_time_convert
                      before_change = "サービス名称: #{source_service_name}(#{source_start_time_convert}~#{source_end_time_convert})"
                      after_change = "サービス名称: #{source_service_name}(#{param_start_time_convert}~#{param_end_time_convert})"
                      create_change_history(schedule, current_user_id, '予定表の提供時間', before_change, after_change)
                    end

                    # Service type change
                    if source_service_type_id != schedule_params[:service_type_id]
                      service_type_change = ServiceType.find_by_id(schedule_params[:service_type_id])&.detail
                      before_change = "サービス名称: #{change_service_name}, 提供時間: #{source_start_time_convert}~#{source_end_time_convert}(#{source_service_type})"
                      after_change = "サービス名称: #{change_service_name}, 提供時間: #{source_start_time_convert}~#{source_end_time_convert}(#{service_type_change})"
                      create_change_history(schedule, current_user_id, '予定表のサービス内容', before_change, after_change)
                    end

                    # Routines
                    source_routines = schedule.schedule_routines.pluck(:regis_day)
                    source_routine_text = source_routines.map{|f| I18n.t("day_name.#{f}")}
                    routine_changes = schedule_params[:schedule_routines].select{|f| f[:checked]}.pluck(:regis_day)
                    routines_text = routine_changes.map{|f| I18n.t("day_name.#{f}")}
                    is_routine_change = source_routine_text - routines_text | routines_text - source_routine_text
                    if is_routine_change.present?
                      before_change = "サービス名称: #{change_service_name}, 提供時間: #{source_start_time_convert}~#{source_end_time_convert} (#{source_routine_text.join(',')})"
                      after_change = "サービス名称: #{change_service_name}, 提供時間: #{source_start_time_convert}~#{source_end_time_convert} (#{routines_text.join(',')})"
                      create_change_history(schedule, current_user_id, '予定表のルーティン', before_change, after_change)
                    end
                    update_schedule_routines(schedule, schedule_params, current_user_id)

                    # Frequency
                    frequency_change = match_frequency_text(schedule_params[:frequency])
                    if source_frequency != frequency_change
                      before_change = "サービス名称: #{change_service_name}, 提供時間: #{source_start_time_convert}~#{source_end_time_convert} (#{source_frequency})"
                      after_change = "サービス名称: #{change_service_name}, 提供時間: #{source_start_time_convert}~#{source_end_time_convert} (#{frequency_change})"
                      create_change_history(schedule, current_user_id, '予定表の頻度', before_change, after_change)
                    end

                    # Update schedule
                    update_schedule(schedule, schedule_params)
                  else
                    schedule = create_schedule(disability_care_plan, schedule_params, care_plan_type)
                    create_schedule_routine(schedule.id, schedule_params)

                    before_change =  ''
                    after_change = "予定表が追加されました。"
                    create_change_history(schedule, current_user_id, '予定表', before_change, after_change)
                  end
                end
                improvement_nursing_care_plans_to_destroy = disability_care_plan.improvement_nursing_care_plans.where.not(id: improvement_nursing_care_plans.pluck(:id))
                improvement_nursing_care_plans_to_destroy.each do |improvement_nursing_care_plan|
                  treatment_improvement_name = improvement_nursing_care_plan.treatment_improvement.name
                  before_change = treatment_improvement_name
                  after_change = "#{treatment_improvement_name} が削除されました"
                  create_change_history(improvement_nursing_care_plan, current_user_id, '処遇改善加算', before_change, after_change)
                end
                improvement_nursing_care_plans_to_destroy.destroy_all
                treatments_found = create_improvement_nursing_care_plans(disability_care_plan.id, improvement_nursing_care_plans,
                                                                         care_plan_type, patient_type, current_user_id)
                return Failure({ 'treatment_improvement_id': I18n.t('errors.messages.not_found') }) unless treatments_found

                disability_care_plan.create_change_histories(current_user_id)
                Success(disability_care_plan)
              else
                Failure(disability_care_plan.error_messages)
              end
            end
          rescue StandardError => e
            Failure(e.message)
          end
        end

        def match_frequency_text frequency
          case frequency
          when 'weekly'
            '毎週'
          when 'other_week'
            '1週間おき'
          when 'twice_week'
            '2週間おき'
          end
        end

        def convert_str_to_time time
          return "" if time.nil?
          time.in_time_zone("Asia/Tokyo").strftime("%H:%M")
        end

        def create_change_history(schedule, current_user_id, changed_attribute, before_change, after_change)
          ChangeHistory.create(
            user_admin_id: current_user_id,
            changeable_id: schedule.care_plan_id,
            changeable_type: schedule.care_plan.class.name,
            changed_attribute: changed_attribute,
            before_change: before_change,
            after_change: after_change,
            date: Time.zone.today
          )
        end

        def create_plan_change_history(object, user_admin_id, text_description, before_value, after_value)
          ChangeHistory.create(
            user_admin_id: user_admin_id,
            changeable_id: object.id,
            changeable_type: object.class.name,
            changed_attribute: text_description,
            before_change: before_value,
            after_change: after_value,
            date: Time.zone.today
          )
        end

        def get_terms_change source_terms, term_changes, type
          term_histories = []
          loop_times = [source_terms.count, term_changes.count].max
          loop_times.times do |i|
            row = i + 1
            source_term = source_terms[i]
            term_change = term_changes[i]
            next if source_term.blank? && term_change.blank?

            if source_term.blank? && term_change.present?
              before_change = ''
              type_text = type == 'long' ? '長期目標' : '短期目標'
              after_change = "#{type_text}#{row}が追加されました。(#{term_change}) "
            end

            if source_term.present? && term_change.present?
              next if source_term == term_change

              before_change = source_term
              after_change = term_change
            end

            if source_term.present? && term_change.blank?
              before_change = source_term
              after_change = '削除してよろしいです。'
            end

            term_histories << { row: row, before_change: before_change, after_change: after_change }
          end

          term_histories
        end
      end
    end
  end
end
