class ChangeUserIdToUserAdminId < ActiveRecord::Migration[7.0]
  def change
    # authentication_tokens
    rename_column :authentication_tokens, :user_id, :user_admin_id
    # notifications
    rename_column :notifications, :user_id, :user_admin_id
    # rooms
    rename_column :rooms, :user_id, :user_admin_id
  end
end
