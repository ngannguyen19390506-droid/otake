class UpdateToTableEvalueTwo < ActiveRecord::Migration[7.0]
  def change
    add_column :evalue_twos, :staple_food_option, :xml
    add_column :evalue_twos, :side_meal_option, :xml
    add_column :evalue_twos, :eating_utensil_option, :xml
    add_column :evalue_twos, :luxury_goods_option, :xml
    add_column :evalue_twos, :neck_option, :xml
    add_column :evalue_twos, :upper_limb_option, :xml
    add_column :evalue_twos, :belt_option, :xml
    add_column :evalue_twos, :hip_joint_option, :xml
    add_column :evalue_twos, :bottom_option, :xml
    add_column :evalue_twos, :form_movement_option, :xml
    add_column :evalue_twos, :excretory_form_option, :xml
    add_column :evalue_twos, :dentures_option, :xml

    # staple_food
    remove_column :evalue_twos, :has_regular_staple_food
    remove_column :evalue_twos, :has_porridge_staple_food
    remove_column :evalue_twos, :has_rice_staple_food

    # side_meal
    remove_column :evalue_twos, :has_regular_side_meal
    remove_column :evalue_twos, :has_minced_side_meal
    remove_column :evalue_twos, :has_blended_side_meal
    remove_column :evalue_twos, :has_bite_sized_side_meal

    # eating_utensil
    remove_column :evalue_twos, :has_chopsticks
    remove_column :evalue_twos, :has_spoon
    remove_column :evalue_twos, :has_fork

    # luxury_goods
    remove_column :evalue_twos, :has_tobacco
    remove_column :evalue_twos, :has_alcohol
    remove_column :evalue_twos, :has_no_luxury_goods

    # neck
    remove_column :evalue_twos, :has_paralysis_neck
    remove_column :evalue_twos, :has_contracture_neck
    remove_column :evalue_twos, :has_other_neck
    remove_column :evalue_twos, :has_no_problem_neck

    # upper_limb
    remove_column :evalue_twos, :has_paralysis_upper_limb
    remove_column :evalue_twos, :has_contracture_upper_limb
    remove_column :evalue_twos, :has_other_upper_limb
    remove_column :evalue_twos, :has_no_problem_upper_limb

    # belt
    remove_column :evalue_twos, :has_paralysis_belt
    remove_column :evalue_twos, :has_contracture_belt
    remove_column :evalue_twos, :has_other_belt
    remove_column :evalue_twos, :has_no_problem_belt

    # hip_joint
    remove_column :evalue_twos, :has_paralysis_hip_joint
    remove_column :evalue_twos, :has_contracture_hip_joint
    remove_column :evalue_twos, :has_other_hip_joint
    remove_column :evalue_twos, :has_no_problem_hip_joint

    # bottom
    remove_column :evalue_twos, :has_paralysis_bottom
    remove_column :evalue_twos, :has_contracture_bottom
    remove_column :evalue_twos, :has_other_bottom
    remove_column :evalue_twos, :has_no_problem_bottom

    # form_movement
    remove_column :evalue_twos, :has_independence
    remove_column :evalue_twos, :has_cane
    remove_column :evalue_twos, :has_wheelchair
    remove_column :evalue_twos, :has_walker
    remove_column :evalue_twos, :has_support_person

    # excretory_form
    remove_column :evalue_twos, :has_independence_excretory
    remove_column :evalue_twos, :has_rehab_pant_excretory
    remove_column :evalue_twos, :has_paper_diaper_excretory
    remove_column :evalue_twos, :has_pad_excretory

    # dentures
    remove_column :evalue_twos, :has_full_dentures
    remove_column :evalue_twos, :has_upper_dentures
    remove_column :evalue_twos, :has_lower_dentures
    remove_column :evalue_twos, :has_partial_dentures
    remove_column :evalue_twos, :has_no_dentures
  end
end
