module V1
  module Admin
    class RentBillingSerializer < ActiveModel::Serializer
      attributes :id, :patient_id, :year_month, :rent_cost, :utility_cost, :food_cost, :living_cost, :subtotal, :refund_cost

      belongs_to :patient, serializer: PatientSerializer

      def subtotal
        [object.rent_cost.to_i, object.utility_cost.to_i, object.food_cost.to_i, object.living_cost.to_i].sum
      end
    end
  end
end