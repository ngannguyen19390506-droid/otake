module V1
  module Admin
    class EvalueTwoApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :evalue_twos do
          desc 'GET api/v1/admin/evalue_twos',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per_page, type: Integer, default: 10
            requires :patient_id, type: Integer, message: I18n.t('evalue_one.error.validate.blank')
          end
          get do
            page = (params[:page].presence || 1).to_i
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @evalue_twos = patient.evalue_twos.order(created_date: :desc).page(page).per(params[:per_page])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @evalue_twos.blank?

            present :page, page
            present :total_items, @evalue_twos.total_count
            present :total_pages, @evalue_twos.total_pages
            present :evalue_twos, @evalue_twos
          end

          # Create EvalueTwo
          desc 'POST api/v1/admin/evalue_twos'
          params do
            requires :patient_id, type: Integer
            requires :staple_food_opt, type: String
            requires :staple_food_txt, type: String
            requires :side_dish_opt, type: String
            requires :side_dish_txt, type: String
            requires :thoromi_opt, type: String
            requires :thoromi_txt, type: String
            requires :assistance_opt, type: String
            requires :assistance_txt, type: String
            requires :tool_opt, type: String
            requires :tool_txt, type: String
            requires :hobby_goods_opt, type: String
            requires :hobby_goods_txt, type: String
            requires :allergy_opt, type: String
            requires :allergy_txt, type: String
            requires :head_opt, type: String
            requires :head_txt, type: String
            requires :upper_limbs_opt, type: String
            requires :upper_limbs_txt, type: String
            requires :waist_opt, type: String
            requires :waist_txt, type: String
            requires :hip_joint_opt, type: String
            requires :hip_joint_txt, type: String
            requires :lower_limbs_opt, type: String
            requires :lower_limbs_txt, type: String
            requires :eyesight_opt, type: String
            requires :eyesight_txt, type: String
            requires :glasses_opt, type: String
            requires :glasses_txt, type: String
            requires :hearing_opt, type: String
            requires :hearing_txt, type: String
            requires :language_opt, type: String
            requires :language_txt, type: String
            requires :morphology_opt, type: String
            requires :morphology_txt, type: String
            requires :move_opt, type: String
            requires :move_txt, type: String
            requires :standing_position_opt, type: String
            requires :standing_position_txt, type: String
            requires :seat_opt, type: String
            requires :seat_txt, type: String
            requires :wash_body_opt, type: String
            requires :wash_body_txt, type: String
            requires :hair_washing_opt, type: String
            requires :hair_washing_txt, type: String
            requires :attaching_and_detaching_opt, type: String
            requires :attaching_and_detaching_txt, type: String
            requires :plastic_surgery_opt, type: String
            requires :plastic_surgery_txt, type: String
            requires :excretion_form_opt, type: String
            requires :excretion_form_txt, type: String
            requires :urge_to_urinate_opt, type: String
            requires :urge_to_urinate_txt, type: String
            requires :convenience_opt, type: String
            requires :convenience_txt, type: String
            requires :incontinence_opt, type: String
            requires :incontinence_txt, type: String
            requires :chew_opt, type: String
            requires :chew_txt, type: String
            requires :swallowing_opt, type: String
            requires :swallowing_txt, type: String
            requires :denture_opt, type: String
            requires :denture_txt, type: String
            requires :understanding_opt, type: String
            requires :understanding_txt, type: String
            requires :expression_of_meaning_opt, type: String
            requires :expression_of_meaning_txt, type: String
            requires :understand_opt, type: String
            requires :understand_txt, type: String
            requires :wander_opt, type: String
            requires :wander_txt, type: String
            requires :violence_opt, type: String
            requires :violence_txt, type: String
            requires :delusion_opt, type: String
            requires :delusion_txt, type: String
            requires :rejection_opt, type: String
            requires :rejection_txt, type: String
            requires :treatment_opt, type: String
            requires :treatment_txt, type: String
            requires :dosage_opt, type: String
            requires :dosage_txt, type: String
            optional :created_date, type: String, desc: '2024/04/01'
          end
          post do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            created_date = convert_date(params[:created_date])
            params.merge!({ "created_date" => created_date }) if created_date.present?
            params.merge!({ "created_date" => Time.current.to_date }) if created_date.blank?
            evalue_two = EvalueTwo.new(params)
            if evalue_two.save
              { success: I18n.t('evalue_two.success.added') }
            else
              error!(evalue_two.error_messages, UNPROCESSABLE_ENTITY)
            end
          end
          # Update EvalueTwo
          desc 'PUT api/v1/admin/evalue_twos/:id'
          params do
            requires :id, type: Integer
            optional :staple_food_opt, type: String
            optional :staple_food_txt, type: String
            optional :side_dish_opt, type: String
            optional :side_dish_txt, type: String
            optional :thoromi_opt, type: String
            optional :thoromi_txt, type: String
            optional :assistance_opt, type: String
            optional :assistance_txt, type: String
            optional :tool_opt, type: String
            optional :tool_txt, type: String
            optional :hobby_goods_opt, type: String
            optional :hobby_goods_txt, type: String
            optional :allergy_opt, type: String
            optional :allergy_txt, type: String
            optional :head_opt, type: String
            optional :head_txt, type: String
            optional :upper_limbs_opt, type: String
            optional :upper_limbs_txt, type: String
            optional :waist_opt, type: String
            optional :waist_txt, type: String
            optional :hip_joint_opt, type: String
            optional :hip_joint_txt, type: String
            optional :lower_limbs_opt, type: String
            optional :lower_limbs_txt, type: String
            optional :eyesight_opt, type: String
            optional :eyesight_txt, type: String
            optional :glasses_opt, type: String
            optional :glasses_txt, type: String
            optional :hearing_opt, type: String
            optional :hearing_txt, type: String
            optional :language_opt, type: String
            optional :language_txt, type: String
            optional :morphology_opt, type: String
            optional :morphology_txt, type: String
            optional :move_opt, type: String
            optional :move_txt, type: String
            optional :standing_position_opt, type: String
            optional :standing_position_txt, type: String
            optional :seat_opt, type: String
            optional :seat_txt, type: String
            optional :wash_body_opt, type: String
            optional :wash_body_txt, type: String
            optional :hair_washing_opt, type: String
            optional :hair_washing_txt, type: String
            optional :attaching_and_detaching_opt, type: String
            optional :attaching_and_detaching_txt, type: String
            optional :plastic_surgery_opt, type: String
            optional :plastic_surgery_txt, type: String
            optional :excretion_form_opt, type: String
            optional :excretion_form_txt, type: String
            optional :urge_to_urinate_opt, type: String
            optional :urge_to_urinate_txt, type: String
            optional :convenience_opt, type: String
            optional :convenience_txt, type: String
            optional :incontinence_opt, type: String
            optional :incontinence_txt, type: String
            optional :chew_opt, type: String
            optional :chew_txt, type: String
            optional :swallowing_opt, type: String
            optional :swallowing_txt, type: String
            optional :denture_opt, type: String
            optional :denture_txt, type: String
            optional :understanding_opt, type: String
            optional :understanding_txt, type: String
            optional :expression_of_meaning_opt, type: String
            optional :expression_of_meaning_txt, type: String
            optional :understand_opt, type: String
            optional :understand_txt, type: String
            optional :wander_opt, type: String
            optional :wander_txt, type: String
            optional :violence_opt, type: String
            optional :violence_txt, type: String
            optional :delusion_opt, type: String
            optional :delusion_txt, type: String
            optional :rejection_opt, type: String
            optional :rejection_txt, type: String
            optional :treatment_opt, type: String
            optional :treatment_txt, type: String
            optional :dosage_opt, type: String
            optional :dosage_txt, type: String
            optional :created_date, type: String, desc: '2024/04/01'
          end
          put '/:id' do
            evalue_two = EvalueTwo.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_two.blank?

            created_date = convert_date(params[:created_date])
            params.merge!({ "created_date" => Time.current.to_date }) if created_date.blank?

            if evalue_two.update(params)
              { success: I18n.t('evalue_two.success.updated') }
            else
              error!(evalue_two.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/evalue_twos/:id'
          params do
          end
          get '/:id' do
            evalue_two = EvalueTwo.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_two.blank?

            present evalue_two
          end

          desc 'DELETE api/v1/admin/evalue_twos/:id'
          params do
          end
          delete '/:id' do
            evalue_two = EvalueTwo.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_two.blank?

            evalue_two&.destroy
            { success: true }
          end
        end

      end
    end
  end
end
