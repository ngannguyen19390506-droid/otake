# == Schema Information
#
# Table name: nursing_care_plan_service_types
#
#  id              :bigint           not null, primary key
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  nursing_care_id :bigint           not null
#  service_type_id :bigint           not null
#
# Indexes
#
#  index_nursing_care_plan_service_types_on_nursing_care_id  (nursing_care_id)
#  index_nursing_care_plan_service_types_on_service_type_id  (service_type_id)
#
# Foreign Keys
#
#  fk_rails_...  (nursing_care_id => nursing_care_plans.id)
#  fk_rails_...  (service_type_id => service_types.id)
#
class NursingCarePlanServiceType < ApplicationRecord
  belongs_to :service_type
  belongs_to :nursing_care, class_name: 'NursingCarePlan'
end
