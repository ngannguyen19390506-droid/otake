# == Schema Information
#
# Table name: bank_infos
#
#  id             :bigint           not null, primary key
#  bank_code      :string
#  bank_name      :string
#  bank_name_kana :string
#  formal_name    :string
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#
class BankInfo < ApplicationRecord
  include ApiCommon
  has_many :branch_infos, dependent: :destroy

  def self.ransackable_attributes(_auth_object = nil)
    %w[bank_name bank_name_kana bank_code]
  end

  def self.ransackable_associations(_auth_object = nil)
    %w[]
  end
end
