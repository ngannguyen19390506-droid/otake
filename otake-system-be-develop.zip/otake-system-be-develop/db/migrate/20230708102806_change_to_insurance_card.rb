class ChangeToInsuranceCard < ActiveRecord::Migration[7.0]
  def change
    change_column :insurance_cards, :certification_department, 'integer USING certification_department::integer'
    add_column :insurance_cards, :home_care_office_type, :integer
    rename_column :insurance_cards, :home_care_office, :home_care_office_input_first
    add_column :insurance_cards, :home_care_office_input_second, :string
  end
end
