class RemoveNotNullNursingCarePlan < ActiveRecord::Migration[7.0]
  def change
    change_column_null :nursing_care_plans, :start_long_term, true
    change_column_null :nursing_care_plans, :end_long_term, true
    change_column_null :nursing_care_plans, :start_short_term, true
    change_column_null :nursing_care_plans, :end_short_term, true
    change_column_null :nursing_care_plans, :short_term_goal_four, true
  end
end
