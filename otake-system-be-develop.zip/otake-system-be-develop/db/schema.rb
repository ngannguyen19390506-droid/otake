# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2024_07_03_031811) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "active_storage_attachments", force: :cascade do |t|
    t.string "name", null: false
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "index_active_storage_attachments_uniqueness", unique: true
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.string "key", null: false
    t.string "filename", null: false
    t.string "content_type"
    t.text "metadata"
    t.string "service_name", null: false
    t.bigint "byte_size", null: false
    t.string "checksum"
    t.datetime "created_at", null: false
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
  end

  create_table "active_storage_variant_records", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.string "variation_digest", null: false
    t.index ["blob_id", "variation_digest"], name: "index_active_storage_variant_records_uniqueness", unique: true
  end

  create_table "addresses", force: :cascade do |t|
    t.bigint "city_id", null: false
    t.string "name", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["city_id"], name: "index_addresses_on_city_id"
  end

  create_table "authentication_tokens", force: :cascade do |t|
    t.bigint "user_admin_id"
    t.string "hashed_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "nursing_staff_id"
    t.bigint "patient_id"
    t.bigint "user_home_system_id"
    t.index ["hashed_id"], name: "index_authentication_tokens_on_hashed_id", unique: true
    t.index ["nursing_staff_id"], name: "index_authentication_tokens_on_nursing_staff_id"
    t.index ["patient_id"], name: "index_authentication_tokens_on_patient_id"
    t.index ["user_admin_id"], name: "index_authentication_tokens_on_user_admin_id"
    t.index ["user_home_system_id"], name: "index_authentication_tokens_on_user_home_system_id"
  end

  create_table "bank_infos", force: :cascade do |t|
    t.string "formal_name"
    t.string "bank_name"
    t.string "bank_name_kana"
    t.string "bank_code"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "branch_infos", force: :cascade do |t|
    t.string "branch_name"
    t.string "branch_name_kana"
    t.string "branch_code"
    t.integer "bank_info_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "care_category_settings", force: :cascade do |t|
    t.string "name", null: false
    t.string "unit", null: false
    t.string "price", null: false
    t.index ["id"], name: "index_care_category_settings_on_id"
  end

  create_table "care_plan_at_homes", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.string "year_month", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["patient_id"], name: "index_care_plan_at_homes_on_patient_id"
  end

  create_table "change_histories", force: :cascade do |t|
    t.bigint "user_admin_id", null: false
    t.string "changeable_type", null: false
    t.bigint "changeable_id", null: false
    t.string "changed_attribute", null: false
    t.text "before_change"
    t.text "after_change"
    t.date "date", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["changeable_type", "changeable_id"], name: "index_change_histories_on_changeable"
    t.index ["user_admin_id"], name: "index_change_histories_on_user_admin_id"
  end

  create_table "cities", force: :cascade do |t|
    t.bigint "district_id", null: false
    t.string "name", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["district_id"], name: "index_cities_on_district_id"
  end

  create_table "contact_relatives", force: :cascade do |t|
    t.bigint "nurse_id"
    t.string "name"
    t.string "relationship"
    t.string "cellphone_number"
    t.string "telephone_number"
    t.string "address"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "patient_id"
    t.index ["nurse_id"], name: "index_contact_relatives_on_nurse_id"
    t.index ["patient_id"], name: "index_contact_relatives_on_patient_id"
  end

  create_table "daily_healths", force: :cascade do |t|
    t.bigint "care_plan_at_home_id", null: false
    t.string "body_temperature_first"
    t.string "body_temperature_second"
    t.string "blood_pressure_first"
    t.string "blood_pressure_second"
    t.string "blood_pressure_third"
    t.string "blood_pressure_fourth"
    t.string "pulse_first"
    t.string "pulse_second"
    t.string "oxygen_first"
    t.string "oxygen_second"
    t.string "bathing"
    t.string "wiping"
    t.date "date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["care_plan_at_home_id"], name: "index_daily_healths_on_care_plan_at_home_id"
  end

  create_table "degrees", force: :cascade do |t|
    t.bigint "nurse_id", null: false
    t.string "name"
    t.date "expired_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["nurse_id"], name: "index_degrees_on_nurse_id"
  end

  create_table "disability_care_plan_terms", force: :cascade do |t|
    t.integer "disability_care_plan_id", null: false
    t.integer "plan_type"
    t.string "term_goal"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "disability_care_plans", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.text "comprehensive_aid_policy"
    t.text "individual_family_intention"
    t.text "aid_purpose"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "remarks"
    t.string "year_month"
    t.date "start_long_term"
    t.date "end_long_term"
    t.date "start_short_term"
    t.date "end_short_term"
    t.text "note"
    t.index ["patient_id"], name: "index_disability_care_plans_on_patient_id"
  end

  create_table "districts", force: :cascade do |t|
    t.string "name", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "document_receipts", force: :cascade do |t|
    t.text "files"
    t.integer "receipt_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "equipment_home_systems", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "equipment_service_id", null: false
    t.string "year_month", null: false
    t.integer "unit_price"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["equipment_service_id"], name: "index_equipment_home_systems_on_equipment_service_id"
    t.index ["patient_id"], name: "index_equipment_home_systems_on_patient_id"
  end

  create_table "equipment_service_payments", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "equipment_service_id"
    t.string "year_month", null: false
    t.integer "unit_price"
    t.integer "remaining_stock_quantity"
    t.boolean "registered", default: false, null: false
    t.integer "category", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["equipment_service_id"], name: "index_equipment_service_payments_on_equipment_service_id"
    t.index ["patient_id"], name: "index_equipment_service_payments_on_patient_id"
  end

  create_table "equipment_service_usages", force: :cascade do |t|
    t.bigint "equipment_service_payment_id", null: false
    t.date "date", null: false
    t.float "quantity", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["equipment_service_payment_id"], name: "index_equipment_service_usages_on_equipment_service_payment_id"
  end

  create_table "equipment_services", force: :cascade do |t|
    t.string "service_name", null: false
    t.string "display_name", null: false
    t.integer "category", null: false
    t.integer "unit_price"
    t.string "stock_quantity"
    t.boolean "unit_price_setting", default: false
    t.integer "position"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "equipment_usage_home_systems", force: :cascade do |t|
    t.bigint "equipment_home_system_id", null: false
    t.date "date", null: false
    t.integer "quantity", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["equipment_home_system_id"], name: "index_equipment_usage_home_systems_on_equipment_home_system_id"
  end

  create_table "evalue_ones", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.text "life_history"
    t.text "daily_life_challenges"
    t.text "note"
    t.text "character"
    t.text "hobbies"
    t.text "family_circumstances"
    t.text "special_notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "daily_rhythm_of_life"
    t.text "current_illness_history"
    t.text "family_interview"
    t.text "personal_interview"
    t.date "created_date"
    t.index ["patient_id"], name: "index_evalue_ones_on_patient_id"
  end

  create_table "evalue_twos", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "staple_food_opt"
    t.text "staple_food_txt"
    t.text "side_dish_opt"
    t.text "side_dish_txt"
    t.integer "thoromi_opt"
    t.text "thoromi_txt"
    t.integer "assistance_opt"
    t.text "assistance_txt"
    t.text "tool_opt"
    t.text "tool_txt"
    t.text "hobby_goods_opt"
    t.text "hobby_goods_txt"
    t.integer "allergy_opt"
    t.text "allergy_txt"
    t.text "head_opt"
    t.text "head_txt"
    t.text "upper_limbs_opt"
    t.text "upper_limbs_txt"
    t.text "waist_opt"
    t.text "waist_txt"
    t.text "hip_joint_opt"
    t.text "hip_joint_txt"
    t.text "lower_limbs_opt"
    t.text "lower_limbs_txt"
    t.integer "eyesight_opt"
    t.text "eyesight_txt"
    t.integer "glasses_opt"
    t.text "glasses_txt"
    t.integer "hearing_opt"
    t.text "hearing_txt"
    t.integer "language_opt"
    t.text "language_txt"
    t.text "morphology_opt"
    t.text "morphology_txt"
    t.integer "move_opt"
    t.text "move_txt"
    t.integer "standing_position_opt"
    t.text "standing_position_txt"
    t.integer "seat_opt"
    t.text "seat_txt"
    t.integer "wash_body_opt"
    t.text "wash_body_txt"
    t.integer "hair_washing_opt"
    t.text "hair_washing_txt"
    t.integer "attaching_and_detaching_opt"
    t.text "attaching_and_detaching_txt"
    t.integer "plastic_surgery_opt"
    t.text "plastic_surgery_txt"
    t.text "excretion_form_opt"
    t.text "excretion_form_txt"
    t.integer "urge_to_urinate_opt"
    t.text "urge_to_urinate_txt"
    t.integer "convenience_opt"
    t.text "convenience_txt"
    t.integer "incontinence_opt"
    t.text "incontinence_txt"
    t.integer "chew_opt"
    t.text "chew_txt"
    t.integer "swallowing_opt"
    t.text "swallowing_txt"
    t.text "denture_opt"
    t.text "denture_txt"
    t.integer "understanding_opt"
    t.text "understanding_txt"
    t.integer "expression_of_meaning_opt"
    t.text "expression_of_meaning_txt"
    t.integer "understand_opt"
    t.text "understand_txt"
    t.integer "wander_opt"
    t.text "wander_txt"
    t.integer "violence_opt"
    t.text "violence_txt"
    t.integer "delusion_opt"
    t.text "delusion_txt"
    t.integer "rejection_opt"
    t.text "rejection_txt"
    t.integer "treatment_opt"
    t.text "treatment_txt"
    t.integer "dosage_opt"
    t.text "dosage_txt"
    t.date "created_date"
    t.index ["patient_id"], name: "index_evalue_twos_on_patient_id"
  end

  create_table "holidays", force: :cascade do |t|
    t.date "date", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "monthly_holiday_id"
    t.integer "create_type"
    t.integer "status"
    t.string "name", default: "希望休"
    t.index ["monthly_holiday_id"], name: "index_holidays_on_monthly_holiday_id"
  end

  create_table "hospitals", force: :cascade do |t|
    t.string "name"
    t.string "clinical_department"
    t.string "phone"
    t.string "address"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "patient_id", null: false
    t.index ["patient_id"], name: "index_hospitals_on_patient_id"
  end

  create_table "improvement_nursing_care_plans", force: :cascade do |t|
    t.bigint "treatment_improvement_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "care_plan_type"
    t.bigint "care_plan_id"
    t.index ["care_plan_type", "care_plan_id"], name: "index_improvement_nursing_care_plans_on_care_plan"
    t.index ["treatment_improvement_id"], name: "idx_incp_on_improvement_id"
  end

  create_table "insurance_cards", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.string "insurance_name"
    t.string "insurance_number"
    t.date "start_insurance"
    t.date "end_insurance"
    t.string "insurance_company_number"
    t.integer "certification_department"
    t.date "release_date"
    t.date "certification_date"
    t.date "start_validate"
    t.date "end_validate"
    t.string "care_level"
    t.string "home_care_office_input_first"
    t.date "care_application_start_date"
    t.string "responsible_policy_management"
    t.string "comprehensive_support_center"
    t.date "announcement_date"
    t.float "benefit_limit"
    t.date "start_date_apply_benefits"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "home_care_office_type"
    t.string "home_care_office_input_second"
    t.string "zipcode"
    t.string "city"
    t.string "district"
    t.string "street"
    t.string "home_care_support_office_name"
    t.index ["patient_id"], name: "index_insurance_cards_on_patient_id"
  end

  create_table "mention_notifications", force: :cascade do |t|
    t.string "name"
    t.integer "m_id"
    t.integer "notification_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "mention_type"
  end

  create_table "message_notifications", force: :cascade do |t|
    t.bigint "notification_id"
    t.string "content", null: false
    t.datetime "read_at"
    t.bigint "sender_id", null: false
    t.string "sender_type"
    t.integer "receiver_id", null: false
    t.string "receiver_type"
    t.integer "notification_room_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["sender_type", "sender_id"], name: "index_message_notifications_on_sender_type_and_sender_id"
  end

  create_table "messages", force: :cascade do |t|
    t.bigint "room_id", null: false
    t.string "content", null: false
    t.datetime "read_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "sender_id", null: false
    t.string "sender_type"
    t.integer "receiver_id"
    t.string "receiver_type"
    t.index ["room_id"], name: "index_messages_on_room_id"
    t.index ["sender_type", "sender_id"], name: "index_messages_on_sender_type_and_sender_id"
  end

  create_table "monthly_holidays", force: :cascade do |t|
    t.bigint "nurse_id", null: false
    t.string "year_month", null: false
    t.integer "status", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "confirmed_by_admin", default: false
    t.boolean "confirmed_by_staff", default: false
    t.integer "create_type"
    t.index ["nurse_id"], name: "index_monthly_holidays_on_nurse_id"
  end

  create_table "notification_categories", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "notification_rooms", force: :cascade do |t|
    t.bigint "sender_id", null: false
    t.string "sender_type"
    t.integer "receiver_id"
    t.string "receiver_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "notification_view_logs", force: :cascade do |t|
    t.bigint "notification_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "viewer_id"
    t.string "viewer_type"
    t.index ["notification_id"], name: "index_notification_view_logs_on_notification_id"
  end

  create_table "notifications", force: :cascade do |t|
    t.string "content", null: false
    t.string "poster", null: false
    t.integer "notify_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_important", default: false
    t.boolean "is_deleted", default: false
    t.datetime "deleted_at"
    t.integer "sender_id"
    t.string "sender_type"
    t.string "title"
    t.integer "patient_id"
    t.integer "notification_category_id"
    t.date "deployment_date"
    t.string "target_person"
    t.string "discoverer"
    t.datetime "occurred_at"
    t.string "occurrence_status"
    t.text "response_action"
    t.string "confirmer"
    t.index ["created_at"], name: "index_notifications_on_created_at"
    t.index ["notification_category_id", "created_at"], name: "index_notifications_on_category_and_created_at"
    t.index ["notification_category_id"], name: "index_notifications_on_notification_category_id"
    t.index ["patient_id", "created_at"], name: "index_notifications_on_patient_and_created_at"
    t.index ["patient_id"], name: "index_notifications_on_patient_id"
    t.index ["sender_type", "sender_id"], name: "index_notifications_on_sender_type_and_sender_id"
  end

  create_table "nursing_care_histories", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "nurse_id"
    t.integer "division"
    t.integer "defecation"
    t.string "full_body_bath"
    t.integer "complexion"
    t.integer "sweating"
    t.boolean "environmental_arrangement"
    t.boolean "consultation_assistance"
    t.text "note"
    t.boolean "toilet_assistance"
    t.boolean "diaper_check"
    t.boolean "pad_confirmation"
    t.integer "urination"
    t.boolean "urinal_cleaning"
    t.boolean "maintain_posture"
    t.integer "hydration"
    t.string "eating_assistance"
    t.string "cleaning"
    t.boolean "full_body_bath_procedure"
    t.boolean "washing_hair"
    t.boolean "washbasin"
    t.boolean "oral_care"
    t.boolean "dressing_assistance"
    t.boolean "position_exchange"
    t.boolean "transfer_assistance"
    t.boolean "watch_over"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "schedule_date_id"
    t.bigint "service_id"
    t.bigint "service_type_id"
    t.string "start_time"
    t.string "end_time"
    t.integer "physical_care"
    t.boolean "record"
    t.string "start_time_format"
    t.string "end_time_format"
    t.string "updated_time"
    t.string "blood_pressure"
    t.string "temperature"
    t.boolean "is_staff_update"
    t.text "summary"
    t.index ["patient_id"], name: "index_nursing_care_histories_on_patient_id"
    t.index ["schedule_date_id"], name: "index_nursing_care_histories_on_schedule_date_id"
    t.index ["service_id"], name: "index_nursing_care_histories_on_service_id"
    t.index ["service_type_id"], name: "index_nursing_care_histories_on_service_type_id"
  end

  create_table "nursing_care_history_changes", force: :cascade do |t|
    t.bigint "nursing_care_history_id", null: false
    t.bigint "patient_id", null: false
    t.bigint "nurse_id", null: false
    t.integer "division"
    t.integer "defecation"
    t.string "full_body_bath"
    t.integer "complexion"
    t.integer "sweating"
    t.boolean "environmental_arrangement"
    t.boolean "consultation_assistance"
    t.text "note"
    t.boolean "toilet_assistance"
    t.boolean "diaper_check"
    t.boolean "pad_confirmation"
    t.integer "urination"
    t.boolean "urinal_cleaning"
    t.boolean "maintain_posture"
    t.integer "hydration"
    t.string "eating_assistance"
    t.string "cleaning"
    t.boolean "full_body_bath_procedure"
    t.boolean "washing_hair"
    t.boolean "washbasin"
    t.boolean "oral_care"
    t.boolean "dressing_assistance"
    t.boolean "position_exchange"
    t.boolean "transfer_assistance"
    t.boolean "watch_over"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "schedule_date_id"
    t.bigint "service_id"
    t.bigint "service_type_id"
    t.string "start_time"
    t.string "end_time"
    t.integer "physical_care"
    t.boolean "record"
    t.string "start_time_format"
    t.string "end_time_format"
    t.string "updated_time"
    t.string "blood_pressure"
    t.string "temperature"
    t.boolean "is_staff_update"
    t.index ["nursing_care_history_id"], name: "index_nursing_care_history_changes_on_nursing_care_history_id"
    t.index ["patient_id"], name: "index_nursing_care_history_changes_on_patient_id"
    t.index ["schedule_date_id"], name: "index_nursing_care_history_changes_on_schedule_date_id"
    t.index ["service_id"], name: "index_nursing_care_history_changes_on_service_id"
    t.index ["service_type_id"], name: "index_nursing_care_history_changes_on_service_type_id"
  end

  create_table "nursing_care_plan_service_types", force: :cascade do |t|
    t.bigint "nursing_care_id", null: false
    t.bigint "service_type_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["nursing_care_id"], name: "index_nursing_care_plan_service_types_on_nursing_care_id"
    t.index ["service_type_id"], name: "index_nursing_care_plan_service_types_on_service_type_id"
  end

  create_table "nursing_care_plan_services", force: :cascade do |t|
    t.bigint "nursing_care_id", null: false
    t.bigint "service_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["nursing_care_id"], name: "index_nursing_care_plan_services_on_nursing_care_id"
    t.index ["service_id"], name: "index_nursing_care_plan_services_on_service_id"
  end

  create_table "nursing_care_plan_terms", force: :cascade do |t|
    t.integer "nursing_care_plan_id", null: false
    t.integer "plan_type"
    t.string "term_goal"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "nursing_care_plans", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.text "comprehensive_aid_policy"
    t.text "individual_family_intention"
    t.text "aid_purpose"
    t.date "start_long_term"
    t.date "end_long_term"
    t.text "long_term_goal_one"
    t.text "long_term_goal_two"
    t.text "long_term_goal_three"
    t.text "long_term_goal_four"
    t.date "start_short_term"
    t.date "end_short_term"
    t.text "short_term_goal_one"
    t.text "short_term_goal_two"
    t.text "short_term_goal_three"
    t.string "short_term_goal_four"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "remarks"
    t.string "year_month"
    t.text "note"
    t.index ["patient_id"], name: "index_nursing_care_plans_on_patient_id"
  end

  create_table "nursing_schedules", force: :cascade do |t|
    t.bigint "nurse_id"
    t.date "date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["nurse_id"], name: "index_nursing_schedules_on_patient_id"
  end

  create_table "nursing_shift_manages", force: :cascade do |t|
    t.bigint "nurse_id", null: false
    t.bigint "shift_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_sent_for_staff", default: false
    t.boolean "confirmed_by_admin", default: false
    t.boolean "confirmed_by_staff", default: false
    t.integer "status", default: 0
    t.index ["nurse_id"], name: "index_nursing_shift_manages_on_nurse_id"
    t.index ["shift_id"], name: "index_nursing_shift_manages_on_shift_id"
  end

  create_table "nursing_staffs", force: :cascade do |t|
    t.string "cellphone_number"
    t.string "telephone_number", null: false
    t.string "password"
    t.date "birth_date", null: false
    t.integer "sex", limit: 2, null: false
    t.string "last_name", null: false
    t.string "first_name", null: false
    t.string "last_name_kana", null: false
    t.string "first_name_kana", null: false
    t.string "zipcode", null: false
    t.string "district", null: false
    t.string "city", null: false
    t.string "street", null: false
    t.string "nurse_code", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "encrypted_password"
    t.string "my_number"
    t.string "building_name"
    t.string "family_name"
    t.string "name_kana"
    t.date "join_date"
    t.integer "status"
    t.integer "employment_type", default: 3
  end

  create_table "patient_receipts", force: :cascade do |t|
    t.integer "patient_id", null: false
    t.string "year_month", null: false
    t.boolean "registered", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "patient_shift_manages", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "shift_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["patient_id"], name: "index_patient_shift_manages_on_patient_id"
    t.index ["shift_id"], name: "index_patient_shift_manages_on_shift_id"
  end

  create_table "patients", force: :cascade do |t|
    t.string "cellphone_number"
    t.string "telephone_number", null: false
    t.string "password"
    t.date "birth_date", null: false
    t.integer "sex", limit: 2, null: false
    t.string "last_name", null: false
    t.string "first_name", null: false
    t.string "last_name_kana", null: false
    t.string "first_name_kana", null: false
    t.string "zipcode"
    t.string "district", null: false
    t.string "city", null: false
    t.string "street", null: false
    t.integer "status", limit: 2, null: false
    t.date "period_contract", null: false
    t.text "current_illness_history"
    t.text "family_interview"
    t.text "personal_interview"
    t.string "patient_code", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "encrypted_password"
    t.string "building_name"
    t.string "family_name"
    t.string "name_kana"
    t.string "hex_color"
    t.date "leave_date"
    t.text "home_care_support_office_name"
  end

  create_table "payment_histories", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.date "expected_date", null: false
    t.date "actual_date", null: false
    t.string "year_month", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["patient_id"], name: "index_payment_histories_on_patient_id"
  end

  create_table "payment_transactions", force: :cascade do |t|
    t.bigint "payment_id", null: false
    t.decimal "amount", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["payment_id"], name: "index_payment_transactions_on_payment_id"
  end

  create_table "payments", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.integer "payment_method", default: 3, null: false
    t.string "account_number"
    t.string "bank_name"
    t.string "branch_name"
    t.integer "account_type"
    t.string "account_name_kana"
    t.string "customer_number"
    t.string "payer", default: "other", null: false
    t.string "zipcode"
    t.string "district"
    t.string "city"
    t.string "street"
    t.string "building_name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "bank_info_id"
    t.integer "branch_info_id"
    t.index ["patient_id"], name: "index_payments_on_patient_id"
  end

  create_table "post_codes", force: :cascade do |t|
    t.bigint "city_id", null: false
    t.bigint "district_id", null: false
    t.bigint "address_id", null: false
    t.string "code", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["address_id"], name: "index_post_codes_on_address_id"
    t.index ["city_id"], name: "index_post_codes_on_city_id"
    t.index ["code"], name: "index_post_codes_on_code", unique: true
    t.index ["district_id"], name: "index_post_codes_on_district_id"
  end

  create_table "public_expenses", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.date "start_date", null: false
    t.date "end_date", null: false
    t.string "system_name", null: false
    t.string "cost_number", null: false
    t.string "beneficiary_number", null: false
    t.integer "payment_amount"
    t.float "benefit_rate", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["patient_id"], name: "index_public_expenses_on_patient_id"
  end

  create_table "receipts", force: :cascade do |t|
    t.integer "price"
    t.integer "patient_receipt_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "memo"
  end

  create_table "recipients", force: :cascade do |t|
    t.text "business_code"
    t.text "recipient_code"
    t.text "service_content"
    t.text "contract_allocation_amount"
    t.date "contract_date"
    t.date "service_end_date"
    t.date "applicable_start_date"
    t.text "user_burden_percentage"
    t.text "monthly_cost_limit"
    t.integer "patient_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["id"], name: "index_recipients_on_id"
  end

  create_table "rent_billings", force: :cascade do |t|
    t.integer "patient_id"
    t.string "year_month"
    t.bigint "rent_cost"
    t.bigint "utility_cost"
    t.bigint "food_cost"
    t.bigint "living_cost"
    t.bigint "refund_cost"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "rooms", force: :cascade do |t|
    t.string "code"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "source_id"
    t.integer "source_type"
    t.integer "target_id"
    t.integer "target_type"
  end

  create_table "routines", force: :cascade do |t|
    t.integer "nurse_id", null: false
    t.integer "regis_day"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "schedule_at_homes", force: :cascade do |t|
    t.bigint "care_plan_at_home_id", null: false
    t.bigint "service_home_system_id", null: false
    t.integer "supplement_options", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["care_plan_at_home_id"], name: "index_schedule_at_homes_on_care_plan_at_home_id"
    t.index ["service_home_system_id"], name: "index_schedule_at_homes_on_service_home_system_id"
  end

  create_table "schedule_date_at_homes", force: :cascade do |t|
    t.string "schedule_homeable_type"
    t.bigint "schedule_homeable_id"
    t.date "date", null: false
    t.string "start_time", null: false
    t.string "end_time", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "value"
    t.index ["schedule_homeable_type", "schedule_homeable_id"], name: "index_schedule_date_at_homes_on_schedule_homeable"
  end

  create_table "schedule_dates", force: :cascade do |t|
    t.string "scheduleable_type", null: false
    t.bigint "scheduleable_id", null: false
    t.date "date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "nurse_id"
    t.integer "status", default: 0
    t.string "start_time"
    t.string "end_time"
    t.json "previous_data"
    t.string "start_time_format"
    t.string "end_time_format"
    t.string "shift_type"
    t.index ["scheduleable_type", "scheduleable_id"], name: "index_schedule_dates_on_scheduleable"
  end

  create_table "schedule_memo_at_homes", force: :cascade do |t|
    t.bigint "care_plan_at_home_id", null: false
    t.string "content", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["care_plan_at_home_id"], name: "index_schedule_memo_at_homes_on_care_plan_at_home_id"
  end

  create_table "schedule_routines", force: :cascade do |t|
    t.integer "schedule_id", null: false
    t.integer "regis_day"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "schedules", force: :cascade do |t|
    t.bigint "service_id", null: false
    t.bigint "service_type_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "care_plan_type"
    t.bigint "care_plan_id"
    t.bigint "patient_id"
    t.integer "frequency"
    t.date "date"
    t.string "start_time"
    t.string "end_time"
    t.integer "shift_type"
    t.integer "sort_index"
    t.index ["care_plan_type", "care_plan_id"], name: "index_schedules_on_care_plan"
    t.index ["patient_id"], name: "index_schedules_on_patient_id"
    t.index ["service_id"], name: "index_schedules_on_service_id"
    t.index ["service_type_id"], name: "index_schedules_on_service_type_id"
  end

  create_table "service_home_systems", force: :cascade do |t|
    t.string "service_name", null: false
    t.string "display_name", null: false
    t.integer "position", null: false
    t.integer "selection_method", null: false
    t.json "dropdown_values"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["display_name"], name: "index_service_home_systems_on_display_name", unique: true
    t.index ["service_name"], name: "index_service_home_systems_on_service_name", unique: true
  end

  create_table "service_shift_manages", force: :cascade do |t|
    t.bigint "shift_id", null: false
    t.bigint "service_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["service_id"], name: "index_service_shift_manages_on_service_id"
    t.index ["shift_id"], name: "index_service_shift_manages_on_shift_id"
  end

  create_table "service_type_shift_manages", force: :cascade do |t|
    t.bigint "shift_id", null: false
    t.bigint "service_type_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["service_type_id"], name: "index_service_type_shift_manages_on_service_type_id"
    t.index ["shift_id"], name: "index_service_type_shift_manages_on_shift_id"
  end

  create_table "service_types", force: :cascade do |t|
    t.string "detail", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["detail"], name: "index_service_types_on_detail", unique: true
  end

  create_table "services", force: :cascade do |t|
    t.string "service_name", null: false
    t.string "service_code", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "unit_price"
    t.integer "patient_type"
    t.index ["service_name"], name: "index_services_on_service_name", unique: true
  end

  create_table "shift_managements", force: :cascade do |t|
    t.date "shift_date", null: false
    t.string "shift_registration_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "start_time"
    t.string "end_time"
    t.json "previous_data"
    t.integer "status", default: 0
    t.integer "create_type"
  end

  create_table "shift_registrations", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "nurse_id"
    t.integer "shift_type"
    t.date "date"
    t.text "note"
  end

  create_table "shift_statuses", force: :cascade do |t|
    t.string "year_month", null: false
    t.integer "status", null: false
    t.index ["id"], name: "index_shift_statuses_on_id"
  end

  create_table "system_management_profiles", force: :cascade do |t|
    t.string "facility_name", null: false
    t.string "zipcode", null: false
    t.string "district", null: false
    t.string "city", null: false
    t.string "street", null: false
    t.string "building_name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "mobile_phone"
    t.string "fax"
    t.string "business_number"
    t.string "grade_registration"
    t.string "rate_registration"
    t.integer "day_payment"
    t.float "rate_registration_nursing_care"
    t.float "rate_registration_disability"
  end

  create_table "treatment_improvements", force: :cascade do |t|
    t.string "name", null: false
    t.integer "patient_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.float "rate"
    t.index ["name"], name: "index_treatment_improvements_on_name", unique: true
  end

  create_table "usage_billings", force: :cascade do |t|
    t.integer "invoice_type"
    t.float "subsidy_amount"
    t.float "exceeding_amount"
    t.float "other_charge"
    t.float "billing_amount"
    t.float "additional"
    t.integer "patient_id"
    t.string "year_month"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "user_admins", force: :cascade do |t|
    t.string "email", default: ""
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "user_code"
    t.string "user_name"
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["user_code"], name: "index_users_on_user_code", unique: true
  end

  create_table "user_home_systems", force: :cascade do |t|
    t.string "encrypted_password", null: false
    t.string "user_code", null: false
    t.string "user_name"
    t.integer "user_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_code"], name: "index_user_home_systems_on_user_code", unique: true
  end

  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "active_storage_variant_records", "active_storage_blobs", column: "blob_id"
  add_foreign_key "addresses", "cities"
  add_foreign_key "authentication_tokens", "nursing_staffs"
  add_foreign_key "authentication_tokens", "patients"
  add_foreign_key "authentication_tokens", "user_admins"
  add_foreign_key "authentication_tokens", "user_home_systems"
  add_foreign_key "care_plan_at_homes", "patients"
  add_foreign_key "change_histories", "user_admins"
  add_foreign_key "cities", "districts"
  add_foreign_key "contact_relatives", "nursing_staffs", column: "nurse_id"
  add_foreign_key "contact_relatives", "patients"
  add_foreign_key "daily_healths", "care_plan_at_homes"
  add_foreign_key "degrees", "nursing_staffs", column: "nurse_id"
  add_foreign_key "equipment_home_systems", "equipment_services"
  add_foreign_key "equipment_home_systems", "patients"
  add_foreign_key "equipment_service_payments", "equipment_services"
  add_foreign_key "equipment_service_payments", "patients"
  add_foreign_key "equipment_usage_home_systems", "equipment_home_systems"
  add_foreign_key "evalue_ones", "patients"
  add_foreign_key "evalue_twos", "patients"
  add_foreign_key "holidays", "monthly_holidays"
  add_foreign_key "hospitals", "patients"
  add_foreign_key "improvement_nursing_care_plans", "treatment_improvements"
  add_foreign_key "insurance_cards", "patients"
  add_foreign_key "messages", "rooms"
  add_foreign_key "monthly_holidays", "nursing_staffs", column: "nurse_id"
  add_foreign_key "nursing_care_plan_service_types", "nursing_care_plans", column: "nursing_care_id"
  add_foreign_key "nursing_care_plan_service_types", "service_types"
  add_foreign_key "nursing_care_plan_services", "nursing_care_plans", column: "nursing_care_id"
  add_foreign_key "nursing_care_plan_services", "services"
  add_foreign_key "nursing_shift_manages", "nursing_staffs", column: "nurse_id"
  add_foreign_key "nursing_shift_manages", "shift_managements", column: "shift_id"
  add_foreign_key "patient_shift_manages", "patients"
  add_foreign_key "patient_shift_manages", "shift_managements", column: "shift_id"
  add_foreign_key "payment_histories", "patients"
  add_foreign_key "payment_transactions", "payments"
  add_foreign_key "payments", "patients"
  add_foreign_key "post_codes", "addresses"
  add_foreign_key "post_codes", "cities"
  add_foreign_key "post_codes", "districts"
  add_foreign_key "public_expenses", "patients"
  add_foreign_key "schedule_at_homes", "care_plan_at_homes"
  add_foreign_key "schedule_at_homes", "service_home_systems"
  add_foreign_key "schedule_memo_at_homes", "care_plan_at_homes"
  add_foreign_key "service_shift_manages", "services"
  add_foreign_key "service_shift_manages", "shift_managements", column: "shift_id"
end
