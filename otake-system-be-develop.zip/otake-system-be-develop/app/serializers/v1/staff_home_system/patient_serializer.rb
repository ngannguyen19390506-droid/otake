module V1
  module StaffHomeSystem
    class PatientSerializer < ActiveModel::Serializer
      attributes :id,
                 :cellphone_number,
                 :telephone_number,
                 :birth_date,
                 :sex,
                 :last_name,
                 :first_name,
                 :last_name_kana,
                 :first_name_kana,
                 :zipcode,
                 :district,
                 :city,
                 :street,
                 :status,
                 :period_contract,
                 :current_illness_history,
                 :family_interview,
                 :personal_interview,
                 :patient_code,
                 :building_name,
                 :family_name,
                 :name_kana,
                 :insurance_card,
                 :age,
                 :residence,
                 :hex_color,
                 :home_care_support_office_name

      def initialize(patient, options = {})
        super(patient, options)
        @year_month_payment = options[:year_month_payment]
      end

      def insurance_card
        return nil if object.insurance_cards.blank?

        object.insurance_cards.default_order.first
      end

      def residence
        "#{object.district}市#{object.city}区"
      end
    end
  end
end
