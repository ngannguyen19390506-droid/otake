# == Schema Information
#
# Table name: change_histories
#
#  id                :bigint           not null, primary key
#  after_change      :text
#  before_change     :text
#  changeable_type   :string           not null
#  changed_attribute :string           not null
#  date              :date             not null
#  created_at        :datetime         not null
#  updated_at        :datetime         not null
#  changeable_id     :bigint           not null
#  user_admin_id     :bigint           not null
#
# Indexes
#
#  index_change_histories_on_changeable     (changeable_type,changeable_id)
#  index_change_histories_on_user_admin_id  (user_admin_id)
#
# Foreign Keys
#
#  fk_rails_...  (user_admin_id => user_admins.id)
#
class ChangeHistory < ApplicationRecord
  include ApiCommon

  belongs_to :user_admin
  belongs_to :changeable, polymorphic: true

  validates :user_admin, :changeable_type, :changed_attribute, :date, presence: true
end
