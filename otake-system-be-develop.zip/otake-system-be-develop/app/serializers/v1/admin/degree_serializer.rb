module V1
  module Admin
    class DegreeSerializer < ActiveModel::Serializer
      attributes :id, :name, :expired_date
    end
  end
end
