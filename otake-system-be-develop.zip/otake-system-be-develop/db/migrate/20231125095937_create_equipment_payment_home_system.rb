class CreateEquipmentPaymentHomeSystem < ActiveRecord::Migration[7.0]
  def change
    create_table :equipment_home_systems do |t|
      t.references :patient,           null: false, foreign_key: true
      t.references :equipment_service, null: false, foreign_key: true
      t.string     :year_month, null: false
      t.integer    :unit_price

      t.timestamps
    end

    create_table :equipment_usage_home_systems do |t|
      t.references :equipment_home_system, null: false, foreign_key: true
      t.date :date, null: false
      t.integer :quantity, null: false

      t.timestamps
    end
  end
end
