module V1
  module Staff
    class EvalueTwoApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :evalue_twos do
          desc 'get api/v1/staff/evalue_twos',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per_page, type: Integer, default: 10
            requires :patient_id, type: Integer, message: I18n.t('evalue_one.error.validate.blank')
          end
          get do
            page = (params[:page].presence || 1).to_i
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @evalue_twos = patient.evalue_twos.order(created_date: :desc).page(page).per(params[:per_page])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @evalue_twos.blank?

            present :page, page
            present :total_items, @evalue_twos.total_count
            present :total_pages, @evalue_twos.total_pages
            present :evalue_twos, @evalue_twos
          end

          desc 'GET api/v1/staff/evalue_twos/:id'
          params do
          end
          get '/:id' do
            evalue_two = EvalueTwo.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_two.blank?

            present evalue_two
          end
        end
      end
    end
  end
end
