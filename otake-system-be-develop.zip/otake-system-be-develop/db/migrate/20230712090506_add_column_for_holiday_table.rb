class AddColumnForHolidayTable < ActiveRecord::Migration[7.0]
  def change
    add_reference :holidays,:nurse, null: false, foreign_key: { to_table: :nursing_staffs }
    # remove_column :holidays, :start_date
    rename_column :holidays, :end_date, :date

    add_column :holidays, :start_time, :time, null: false
    add_column :holidays, :end_time, :time, null: false
    add_column :holidays, :approved_by, :string

    change_column :holidays, :content, :string, null: true
    change_column :holidays, :registered, :string, null: true

  end
end
