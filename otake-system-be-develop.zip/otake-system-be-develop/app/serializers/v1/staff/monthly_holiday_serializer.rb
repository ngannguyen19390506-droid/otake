module V1
  module Staff
    class MonthlyHolidaySerializer < ActiveModel::Serializer
      attributes :id, :status, :year_month

      has_many :holidays, serializer: HolidaySerializer
    end
  end
end
