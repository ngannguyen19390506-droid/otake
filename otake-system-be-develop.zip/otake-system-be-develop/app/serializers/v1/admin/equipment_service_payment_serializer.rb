module V1
  module Admin
    class EquipmentServicePaymentSerializer < ActiveModel::Serializer
      attributes :id,
                 :category,
                 :registered,
                 :remaining_stock_quantity,
                 :unit_price,
                 :year_month,
                 :patient_id,
                 :equipment_service_id

      belongs_to :equipment_service, serializer: EquipmentServiceSerializer
      has_many :equipment_service_usages, serializer: EquipmentServiceUsageSerializer

    end
  end
end
