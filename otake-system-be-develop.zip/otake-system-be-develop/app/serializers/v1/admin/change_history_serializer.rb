module V1
  module Admin
    class ChangeHistorySerializer < ActiveModel::Serializer
      attributes :id,
                 :after_change,
                 :before_change,
                 :date,
                 :changeable_type,
                 :changeable_type,
                 :changed_attribute

      belongs_to :user_admin, serializer: UserAdminSerializer

      def after_change
        convert_to_date_format(object.after_change)
      end

      def before_change
        convert_to_date_format(object.before_change)
      end

      private

      def convert_to_date_format(date_string)
        return date_string unless DATE_REGEX.match?(date_string)

        parsed_date = Date.parse(date_string)
        parsed_date.strftime('%Y年%m月%d日')
      rescue ArgumentError => e
        date_string
      end
    end
  end
end
