module V1
  module AdminHomeSystem
    class DailyHealthApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resources :daily_healths do
          desc 'GET api/v1/admin_home_system/daily_healths'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            care_plan_at_home = patient.care_plan_at_homes.find_by(year_month: params[:year_month])
            if care_plan_at_home.present?
              return present :data, care_plan_at_home.daily_healths.order(:date)
            else
              return present :data, []
            end
          end

          desc 'POST api/v1/admin_home_system/daily_healths'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :dates, type: Array[String], message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            optional :blood_pressure_first, type: Integer
            optional :blood_pressure_second, type: Integer
            optional :blood_pressure_third, type: Integer
            optional :blood_pressure_fourth, type: Integer
            optional :body_temperature_first, type: Float
            optional :body_temperature_second, type: Float
            optional :oxygen_first, type: Integer
            optional :oxygen_second, type: Integer
            optional :pulse_first, type: Integer
            optional :pulse_second, type: Integer
            optional :bathing, type: Integer
            optional :wiping, type: Integer
          end
          post do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            ActiveRecord::Base.transaction do
              care_plan_at_home = patient.care_plan_at_homes.find_or_create_by(year_month: params[:year_month])
              care_plan_at_home.daily_healths.where(date: params[:dates]).destroy_all
              start_of_month = params[:year_month].to_date.beginning_of_month
              end_of_month = params[:year_month].to_date.end_of_month
              params[:dates].each do |date|
                return error!({ 'messages': I18n.t('errors.messages.invalid_date') }, UNPROCESSABLE_ENTITY) if (start_of_month..end_of_month).exclude?(date.to_date)

                care_plan_at_home.daily_healths.create!(
                  date: date,
                  bathing: params[:bathing],
                  blood_pressure_first: params[:blood_pressure_first],
                  blood_pressure_second: params[:blood_pressure_second],
                  blood_pressure_third: params[:blood_pressure_third],
                  blood_pressure_fourth: params[:blood_pressure_fourth],
                  body_temperature_first: params[:body_temperature_first],
                  body_temperature_second: params[:body_temperature_second],
                  oxygen_first: params[:oxygen_first],
                  oxygen_second: params[:oxygen_second],
                  pulse_first: params[:pulse_first],
                  pulse_second: params[:pulse_second],
                  wiping: params[:wiping]
                )
              end

              { success: I18n.t('success.messages.added') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin_home_system/daily_healths/id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
          end
          get ':id' do
            daily_health = DailyHealth.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if daily_health.blank?

            present daily_health
          end
        end
      end

      helpers do

      end
    end
  end
end
