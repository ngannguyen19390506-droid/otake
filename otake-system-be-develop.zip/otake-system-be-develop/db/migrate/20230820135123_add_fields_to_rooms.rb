class AddFieldsToRooms < ActiveRecord::Migration[7.0]
  def change
    add_column :rooms, :source_id, :integer
    add_column :rooms, :source_type, :integer
    add_column :rooms, :target_id, :integer
    add_column :rooms, :target_type, :integer
  end
end
