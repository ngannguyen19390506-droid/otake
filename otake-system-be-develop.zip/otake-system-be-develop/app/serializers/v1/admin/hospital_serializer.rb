module V1
  module Admin
    class HospitalSerializer < ActiveModel::Serializer
      attributes :id,
                 :name,
                 :clinical_department,
                 :phone,
                 :address
    end
  end
end
