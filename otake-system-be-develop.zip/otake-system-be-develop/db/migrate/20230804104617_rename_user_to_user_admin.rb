class RenameUserToUserAdmin < ActiveRecord::Migration[7.0]
  def change
    rename_table :users, :user_admins
  end
end
