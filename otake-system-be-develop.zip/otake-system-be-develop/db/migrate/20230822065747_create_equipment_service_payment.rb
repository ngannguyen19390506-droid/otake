class CreateEquipmentServicePayment < ActiveRecord::Migration[7.0]
  def change
    create_table :equipment_service_payments do |t|
      t.references :patient,           null: false, foreign_key: true
      t.references :equipment_service, null: false, foreign_key: true
      t.string     :year_month, null: false
      t.integer    :unit_price
      t.integer    :total_usage_quantity
      t.integer    :remaining_stock_quantity
      t.boolean    :registered, default: false, null: false
      t.integer    :category, null: false

      t.timestamps
    end
  end
end
