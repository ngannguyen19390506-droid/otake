# == Schema Information
#
# Table name: notification_view_logs
#
#  id              :bigint           not null, primary key
#  viewer_type     :string
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  notification_id :bigint           not null
#  viewer_id       :integer
#
# Indexes
#
#  index_notification_view_logs_on_notification_id  (notification_id)
#
class NotificationViewLog < ApplicationRecord
  # belongs_to :nursing_staff, foreign_key: :nurse_id
  belongs_to :notification, foreign_key: :notification_id

  scope :only_staffs, -> { where(viewer_type: 'NursingStaff') }
end
