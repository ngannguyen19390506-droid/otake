module V1
  module Client
    class NursingCareHistoryApi < V1::AppApi
      before { authenticate!(Patient, :patient_code) }

      namespace :client do
        resources :nursing_care_histories do
          # index nursing_care_histories
          desc 'GET /api/v1/client/nursing_care_histories'
          params do
            requires :date, type: Date, message: I18n.t('nursing_care_history.error.validate.blank')
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
          end
          get do
            return [] if params[:date] > Time.zone.today.end_of_month

            schedule_ids = current_client.schedules.pluck(:id)
            @query = current_client.schedule_dates.joins(:nursing_care_history).where(schedule_dates: { date: params[:date] })
                                   .where(scheduleable_id: schedule_ids)
            sort_key = params[:sortKey]
            page = (params[:page].presence || 1).to_i
            @nursing_care_histories = @query.default_order
            if sort_key.present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if sort_key == 'time'
                sort_key = 'start_time' if sort_key == 'time'
                @nursing_care_histories = @query.order(sort_key => sort_order)
              elsif sort_key == 'name'
                @nursing_care_histories = @query.left_outer_joins(nursing_care_history: :nurse)
                                                .order("nurse.name_kana #{sort_order}")
              else
                @nursing_care_histories = @query.left_outer_joins(:nursing_care_history)
                                                .order("nursing_care_histories.#{sort_key} #{sort_order}")
              end
            end
            @nursing_care_histories = @nursing_care_histories.page(page).per(params[:per])
            serialized_nursing_care_histories = @nursing_care_histories.map do |nursing_care_history|
              V1::Admin::ScheduleDateSerializer.new(nursing_care_history).as_json
            end
            present :page, page
            present :total_items, @nursing_care_histories.total_count
            present :total_pages, @nursing_care_histories.total_pages
            present :data, serialized_nursing_care_histories
          end

          desc 'GET /api/v1/client/nursing_care_histories/schedule_date'
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
          end

          get ':schedule_date' do
            schedule_date = current_client.schedule_dates.joins(:nursing_care_history).find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            if schedule_date.date > Time.zone.today.end_of_month
              return error!({ 'messages': I18n.t('errors.messages.not_found') },
                            NOT_FOUND)
            end

            nursing_care_history = schedule_date.nursing_care_history
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_care_history.blank?

            nursing_care_history_serializer =  NursingCareHistorySerializer.new(nursing_care_history)
            present :data, nursing_care_history_serializer
          end
        end
      end
    end
  end
end
