require 'dry/monads'
require 'dry/monads/do'

class ApplicationOperation
  include Dry::Monads[:result]
  include Dry::Monads::Do.for(:call)
  def self.call(*args, &block)
    new.call(*args, &block)
  end

  protected

  # Start time cannot bigger end time and The distance between start and end time cannot be more than 24 hours

  def invalid_time_rage?(start_time, end_time)
    end_time.to_time <= start_time.to_time || (end_time.to_time - start_time.to_time) / 60 / 60 > 24
  end

  def invalid_date?(date)
    date.to_datetime < Date.current
  end

  def convert_date(date)
    date.in_time_zone('Asia/Tokyo').strftime('%Y-%m-%d').to_date
  end
end
