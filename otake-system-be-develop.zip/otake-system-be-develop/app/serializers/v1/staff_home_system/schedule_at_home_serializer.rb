module V1
  module StaffHomeSystem
    class ScheduleAtHomeSerializer < ActiveModel::Serializer
      attributes :id,
                 :service_home_system_id,
                 :supplement_options

      has_many :schedule_date_at_homes, serializer: ScheduleDateAtHomeSerializer
    end
  end
end
