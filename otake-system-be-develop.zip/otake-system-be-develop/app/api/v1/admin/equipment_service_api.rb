module V1
  module Admin
    class EquipmentServiceApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :equipment_services do
          # index
          desc 'GET api/v1/admin/equipment_services'
          params do
            optional :category, type: String, values: EquipmentService.categories.keys
            optional :sortKey, type: String
            optional :order, type: String
            optional :year_month, type: String
            optional :patient_id, type: Integer
          end
          get do
            if params[:category].present? && params[:year_month].present? && params[:patient_id].present?
              @equipment_services = EquipmentService.includes(:equipment_service_payments).where(category: params[:category]).sort_by(&:position)
              patient = Patient.find(params[:patient_id])
              equipment_service_payment = patient.equipment_service_payments.find_by(year_month: params[:year_month], category: params[:category])
              registered = equipment_service_payment.blank? ? false : equipment_service_payment.registered
              serialized_equipment_services = @equipment_services.map do |equipment_service|
                EquipmentServiceSerializer.new(equipment_service, { year_month: params[:year_month], patient_id: params[:patient_id] }).as_json
              end

              present :patient, patient
              present :registered, registered
            else
              @equipment_services = EquipmentService.all.group_by(&:category)
              serialized_equipment_services = @equipment_services.map do |category, equipment_services|
                sorted_equipment_services = if params[:category].present? && params[:category] == category &&
                                    params[:sortKey].present? && params[:order].present?
                                    sorted = equipment_services.sort_by(&params[:sortKey].to_sym)
                                    sorted.reverse! if params[:order] != 'ascend'
                                    sorted
                                  else
                                    equipment_services.sort_by(&:position)
                                  end
                serialized_services = sorted_equipment_services.map do |equipment_service|
                  EquipmentServiceSerializer.new(equipment_service).as_json
                end

                { category => serialized_services }
              end
            end
            present :serialized_equipment_services, serialized_equipment_services
          end

          desc 'POST api/v1/admin/equipment_services'
          params do
            requires :category, type: String, message: I18n.t('equipment_service.error.validate.blank'),
                                values: EquipmentService.categories.keys
            requires :display_name, type: String, message: I18n.t('equipment_service.error.validate.blank')
            requires :service_name, type: String, message: I18n.t('equipment_service.error.validate.blank')
            optional :stock_quantity, type: String
            optional :unit_price, type: Integer
            optional :unit_price_setting, type: Boolean
          end
          post do
            equipment_service = EquipmentService.new(params_equipment_service)
            if equipment_service.save
              { success: I18n.t('equipment_service.success.added') }
            else
              error!(equipment_service.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/equipment_services/update_positions_and_stock'
          params do
            requires :equipment_services, type: Array do
              requires :category, type: String
              requires :records, type: Array do
                requires :id, type: Integer
                requires :position, type: Integer
                optional :change, type: Float
                optional :operators, type: String, values: %w[+ -]
              end
            end
          end
          put 'update_positions_and_stock' do
            ActiveRecord::Base.transaction do
              params[:equipment_services].each do |category_data|
                positions = category_data[:records].pluck(:position)
                if positions.length != positions.uniq.length
                  return error!({ 'messages': I18n.t('equipment_service.error.duplicate_positions') }, UNPROCESSABLE_ENTITY)
                end

                equipment_services = EquipmentService.where(category: category_data[:category])
                category_data[:records].each do |record_data|
                  equipment_service = equipment_services.find(record_data[:id])
                  equipment_service.position = record_data[:position]
                  operators = record_data[:operators]
                  change = record_data[:change].to_f
                  if change.present? && operators.present?
                    stock_quantity = equipment_service.stock_quantity.to_f
                    quantity_change = if operators == '+'
                                        stock_quantity + change
                                      else
                                        stock_quantity - change
                                      end

                    equipment_service.stock_quantity = quantity_change.round(1)
                    return error!({ 'messages': I18n.t('errors.messages.stock_quantity_invalid') }, UNPROCESSABLE_ENTITY) if equipment_service.stock_quantity.to_f < 0
                  end

                  equipment_service.save
                end
              end
              { success: I18n.t('equipment_service.success.updated') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/equipment_services/:id'
          params do
            requires :id, type: Integer, message: I18n.t('equipment_service.error.validate.blank')
            optional :category, type: String, values: EquipmentService.categories.keys
            optional :display_name, type: String
            optional :service_name, type: String
            optional :stock_quantity, type: String
            optional :unit_price, type: Integer
            optional :unit_price_setting, type: Boolean
          end
          put ':id' do
            equipment_service = EquipmentService.find(params[:id])
            if equipment_service.update(params_equipment_service)
              { success: I18n.t('equipment_service.success.updated') }
            else
              error!(equipment_service.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/equipment_services/:id'
          params do
            requires :id, type: Integer, message: I18n.t('equipment_service.error.validate.blank')
          end
          get ':id' do
            begin
              @equipment_service = EquipmentService.find(params[:id])
              present @equipment_service
            end
          end
        end
      end

      helpers do
        def params_equipment_service
          params.slice(:category, :display_name, :service_name, :stock_quantity, :unit_price, :unit_price_setting)
        end
      end
    end
  end
end
