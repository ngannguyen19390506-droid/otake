# == Schema Information
#
# Table name: branch_infos
#
#  id               :bigint           not null, primary key
#  branch_code      :string
#  branch_name      :string
#  branch_name_kana :string
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  bank_info_id     :integer
#
class BranchInfo < ApplicationRecord
  belongs_to :bank_info

  def self.ransackable_attributes(_auth_object = nil)
    %w[branch_name branch_name_kana branch_code]
  end

  def self.ransackable_associations(_auth_object = nil)
    %w[]
  end
end
