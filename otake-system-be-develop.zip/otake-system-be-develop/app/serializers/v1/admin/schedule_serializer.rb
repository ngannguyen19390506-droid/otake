module V1
  module Admin
    class ScheduleSerializer < ActiveModel::Serializer
      attributes :id,
                 :care_plan_id,
                 :care_plan_type,
                 :service_id,
                 :service_type_id,
                 :patient_id,
                 :schedule_date,
                 :start_time,
                 :end_time,
                 :date,
                 :shift_type,
                 :sort_index

      belongs_to :service, serializer: ServiceSerializer
      belongs_to :service_type, serializer: ServiceTypeSerializer
      belongs_to :care_plan, polymorphic: true, optional: true
      belongs_to :patient, serializer: PatientSerializer

      has_many :schedule_dates, as: :scheduleable, serializer: ScheduleDateSerializer
      has_many :schedule_routines, serializer: ScheduleRoutineSerializer

      def initialize(schedule, options = {})
        super(schedule, options)
        return {} if options[:time_range].blank?

        @schedule_date = options[:schedule_date]
        @time_range = options[:time_range].split('~').map(&:strip) # time_range = 08:00 ~ 09:00
      end

      def schedule_date
        return {} if @time_range.blank?

        start_time = @time_range[0]
        end_time = @time_range[1]
        schedule_date = object.schedule_dates.find_by(start_time: start_time, end_time: end_time, date: @schedule_date)
        return false if schedule_date.blank?

        ScheduleDateSerializer.new(schedule_date)
      end
    end
  end
end
