# == Schema Information
#
# Table name: schedules
#
#  id              :bigint           not null, primary key
#  care_plan_type  :string
#  date            :date
#  end_time        :string
#  frequency       :integer
#  shift_type      :integer
#  sort_index      :integer
#  start_time      :string
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  care_plan_id    :bigint
#  patient_id      :bigint
#  service_id      :bigint           not null
#  service_type_id :bigint           not null
#
# Indexes
#
#  index_schedules_on_care_plan        (care_plan_type,care_plan_id)
#  index_schedules_on_patient_id       (patient_id)
#  index_schedules_on_service_id       (service_id)
#  index_schedules_on_service_type_id  (service_type_id)
#
class Schedule < ApplicationRecord
  include ApiCommon

  belongs_to :service
  belongs_to :service_type
  belongs_to :care_plan, polymorphic: true, optional: true
  belongs_to :patient

  has_many :schedule_dates, as: :scheduleable, dependent: :destroy
  has_many :schedule_routines, dependent: :destroy

  validates :frequency, presence: true

  scope :nursing_plans, -> {where(care_plan_type: 'NursingCarePlan')}
  scope :disability_plans, -> {where(care_plan_type: 'DisabilityCarePlan')}

  enum frequency: { weekly: 0, other_week: 1, twice_week: 2 }
  enum shift_type: { early_shift: 0, late_shift: 1, night_shift: 2, morning_shift: 3, day_shift_1: 4,
                     day_shift_2: 5, day_shift_3: 6, day_shift_4: 7, day_shift_5: 8 }

  scope :for_week, ->(week_start_date, week_end_date) {
    joins(:schedule_dates)
      .where('schedule_dates.date BETWEEN :start_date AND :end_date', {
        start_date: week_start_date,
        end_date: week_end_date
      })
      .includes(:service, :service_type)
  }

  scope :for_date, ->(specific_date) {
    joins(:schedule_dates)
      .where('schedule_dates.date = :specific_date', {
        specific_date: specific_date
      })
      .includes(:service, :service_type)
  }

  after_create :set_sort_index

  def set_sort_index
    update(sort_index: id) if sort_index.blank?
  end

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_changes_without_timestamps(previous_changes)
      all_changes.each do |changed_attribute, (before_value, after_value)|
        if changed_attribute == 'service_id'
          before_value = Service.find(before_value)&.service_name
          after_value = Service.find(after_value)&.service_name
        elsif changed_attribute == 'service_type_id'
          before_value = ServiceType.find(before_value)&.detail
          after_value = ServiceType.find(after_value)&.detail
        end
        text_description = I18n.t("attribute_description.schedule.#{changed_attribute}")
        create_change_history_care_plan(user_admin_id, text_description, before_value, after_value)
      end
    rescue StandardError => e
      e
    end
  end

  def create_change_history_care_plan(user_admin_id, text_description, before_value, after_value)
    ChangeHistory.create!(
      user_admin_id: user_admin_id,
      changeable_id: care_plan_id,
      changeable_type: care_plan_type,
      changed_attribute: text_description,
      before_change: before_value,
      after_change: after_value,
      date: Time.zone.today
    )
  end
end
