class UpdateToNursingStaff < ActiveRecord::Migration[7.0]
  def change
    remove_column :nursing_staffs, :name
    remove_column :nursing_staffs, :family_name
    remove_column :nursing_staffs, :name_kana
    remove_column :nursing_staffs, :house_no
    remove_column :nursing_staffs, :age

    add_column :nursing_staffs, :my_number, :string
    add_column :nursing_staffs, :building_name, :string
  end
end
