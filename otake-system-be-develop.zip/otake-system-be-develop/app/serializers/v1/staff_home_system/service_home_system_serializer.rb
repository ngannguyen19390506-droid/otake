module V1
  module StaffHomeSystem
    class ServiceHomeSystemSerializer < ActiveModel::Serializer
      attributes :id,
                 :display_name,
                 :dropdown_values,
                 :position,
                 :selection_method,
                 :service_name,
                 :schedules

      def initialize(service, options = {})
        super(service, options)
        @patient = options[:patient]
        @date = options[:date]
      end

      def schedules
        return if @patient.blank? || @date.blank?

        schedule_at_homes = object.schedule_at_homes.includes(:care_plan_at_home)
                                  .where(care_plan_at_home: { patient: @patient.id, year_month: @date.strftime('%Y/%m') })
        return if schedule_at_homes.blank?

        ScheduleDateAtHome.where(schedule_homeable_id: schedule_at_homes.pluck(:id), date: @date)
      end
    end
  end
end
