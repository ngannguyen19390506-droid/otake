class CreateDocuments < ActiveRecord::Migration[7.0]
  def change
    create_table :documents do |t|
      t.json :files
      t.integer :receipt_id

      t.timestamps
    end

    remove_column :receipts, :files
  end
end
