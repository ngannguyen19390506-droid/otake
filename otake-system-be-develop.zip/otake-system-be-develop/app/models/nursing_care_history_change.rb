# == Schema Information
#
# Table name: nursing_care_history_changes
#
#  id                        :bigint           not null, primary key
#  blood_pressure            :string
#  cleaning                  :string
#  complexion                :integer
#  consultation_assistance   :boolean
#  defecation                :integer
#  diaper_check              :boolean
#  division                  :integer
#  dressing_assistance       :boolean
#  eating_assistance         :string
#  end_time                  :string
#  end_time_format           :string
#  environmental_arrangement :boolean
#  full_body_bath            :string
#  full_body_bath_procedure  :boolean
#  hydration                 :integer
#  is_staff_update           :boolean
#  maintain_posture          :boolean
#  note                      :text
#  oral_care                 :boolean
#  pad_confirmation          :boolean
#  physical_care             :integer
#  position_exchange         :boolean
#  record                    :boolean
#  start_time                :string
#  start_time_format         :string
#  sweating                  :integer
#  temperature               :string
#  toilet_assistance         :boolean
#  transfer_assistance       :boolean
#  updated_time              :string
#  urinal_cleaning           :boolean
#  urination                 :integer
#  washbasin                 :boolean
#  washing_hair              :boolean
#  watch_over                :boolean
#  created_at                :datetime         not null
#  updated_at                :datetime         not null
#  nurse_id                  :bigint           not null
#  nursing_care_history_id   :bigint           not null
#  patient_id                :bigint           not null
#  schedule_date_id          :bigint
#  service_id                :bigint
#  service_type_id           :bigint
#
# Indexes
#
#  index_nursing_care_history_changes_on_nursing_care_history_id  (nursing_care_history_id)
#  index_nursing_care_history_changes_on_patient_id               (patient_id)
#  index_nursing_care_history_changes_on_schedule_date_id         (schedule_date_id)
#  index_nursing_care_history_changes_on_service_id               (service_id)
#  index_nursing_care_history_changes_on_service_type_id          (service_type_id)
#
class NursingCareHistoryChange < ApplicationRecord
  include ApiCommon

  belongs_to :nursing_care_history
  belongs_to :nurse, class_name: 'NursingStaff', optional: true
  belongs_to :patient
  belongs_to :schedule_date
  belongs_to :service
  belongs_to :service_type

  enum division: { disability: 0, normal: 1 }
  enum physical_care: { body: 1, life: 2, severe_visit: 3 }
  enum complexion: { bad: 0, good: 1 }
  enum sweating: { no: 0, yes: 1 }

  def self.ransackable_associations(_auth_object = nil)
    %w[nurse]
  end
end
