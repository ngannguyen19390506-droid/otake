module V1
  module Staff
    class NursingCareHistoryApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :nursing_care_histories do
          desc 'GET /api/v1/staff/nursing_care_histories/calendar',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :date, type: String, desc: '2024/05/10'
          end
          get 'calendar' do
            date = params[:date]
            error!({ 'messages': I18n.t('patient.error.validate.blank') }, UNPROCESSABLE_ENTITY) if date.blank?

            data = get_patient_schedules(date)
            present :patient_schedules, data
          end

          # index nursing_care_histories
          desc 'GET /api/v1/staff/nursing_care_histories',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: String
            requires :date, type: Date
            optional :care_plan_type, type: String
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :no_care_history, type: Boolean
            optional :sortKey, type: String
            optional :order, type: String
            optional :is_print, type: Boolean
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @query = patient.schedule_dates.where(schedule_dates: { date: params[:date].to_date })
            if params[:care_plan_type].present?
              schedule_ids_by_care_plan_type = patient.schedules.where(care_plan_type: params[:care_plan_type]).pluck(:id)
              @query = @query.where(scheduleable_id: schedule_ids_by_care_plan_type)
            end

            if params[:no_care_history]
              @query = @query.joins(:nursing_care_history)
                             .where(nursing_care_histories: { complexion: nil, sweating: nil, defecation: nil,
                                                              urination: nil, hydration: nil, full_body_bath: nil })
            end

            sort_key = params[:sortKey]
            page = (params[:page].presence || 1).to_i
            @nursing_care_histories = @query.default_order
            if sort_key.present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if %w[date time].include?(sort_key)
                sort_key = 'start_time' if sort_key == 'time'
                @nursing_care_histories = @query.order(sort_key => sort_order)
              elsif sort_key == 'name'
                @nursing_care_histories = @query.left_outer_joins(nursing_care_history: :nurse)
                                                .order("nurse.name_kana #{sort_order} NULLS LAST")
              else
                @nursing_care_histories = @query.left_outer_joins(:nursing_care_history)
                                                .order("nursing_care_histories.#{sort_key} #{sort_order} NULLS LAST")
              end
            end

            @nursing_care_histories = @nursing_care_histories.page(page).per(params[:per]) unless params[:is_print]

            serialized_nursing_care_histories = @nursing_care_histories.map do |nursing_care_history|
              ScheduleDateSerializer.new(nursing_care_history, { params: { no_care_history: params[:no_care_history] } }).as_json
            end

            total_items = params[:is_print] ? @nursing_care_histories.count : @nursing_care_histories.total_count
            total_pages = params[:is_print] ? 1 : @nursing_care_histories.total_pages

            present :page, page
            present :total_items, total_items
            present :total_pages, total_pages
            present :serialized_nursing_care_histories, serialized_nursing_care_histories
          end

          # desc 'GET /api/v1/staff/nursing_care_histories/:id'
          # params do
          # end
          # get '/:id' do
          #   nursing_care_history = NursingCareHistory.find_by(id: params[:id])
          #   return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) unless nursing_care_history
          #   present nursing_care_history
          # end

          desc 'POST /api/v1/staff/nursing_care_histories'
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :patient_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :nurse_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :service_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :service_type_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :division, type: String, values: NursingCareHistory.divisions.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :defecation, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :complexion, type: String, values: NursingCareHistory.complexions.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :sweating, type: String, values: NursingCareHistory.sweatings.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :physical_care, type: String, values: NursingCareHistory.physical_cares.keys,
                     message: I18n.t('nursing_care_history.error.validate.blank')
            requires :urination, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            requires :hydration, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            optional :full_body_bath, type: String
            optional :environmental_arrangement, type: Boolean
            optional :consultation_assistance, type: Boolean
            optional :note, type: String
            optional :toilet_assistance, type: Boolean
            optional :diaper_check, type: Boolean
            optional :pad_confirmation, type: Boolean
            optional :urinal_cleaning, type: Boolean
            optional :maintain_posture, type: Boolean
            optional :eating_assistance, type: String
            optional :cleaning, type: String
            optional :full_body_bath_procedure, type: Boolean
            optional :washing_hair, type: Boolean
            optional :washbasin, type: Boolean
            optional :oral_care, type: Boolean
            optional :dressing_assistance, type: Boolean
            optional :position_exchange, type: Boolean
            optional :transfer_assistance, type: Boolean
            optional :watch_over, type: Boolean
            optional :start_time, type: String
            optional :end_time, type: String
            optional :start_time_format, type: String
            optional :end_time_format, type: String
            optional :record, type: Boolean
            optional :blood_pressure, type: String
            optional :temperature, type: String
            optional :updated_time, type: String
          end

          post do
            schedule_date = ScheduleDate.find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            nursing_staff = NursingStaff.find_by(id: params[:nurse_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_staff.blank?

            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            service = Service.find_by(id: params[:service_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service.blank?

            service_type = ServiceType.find_by(id: params[:service_type_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_type.blank?

            if schedule_date.nursing_care_history.present?
              return error!({ 'messages': I18n.t('errors.messages.already_exists') },
                            UNPROCESSABLE_ENTITY)
            end
            nursing_care_history = NursingCareHistory.new(params_nursing_care_history)
            if nursing_care_history.save
              { success: I18n.t('nursing_care_history.success.added') }
            else
              error!(nursing_care_history.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT /api/v1/staff/nursing_care_histories',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
            optional :nurse_id, type: Integer
            optional :service_id, type: Integer
            optional :service_type_id, type: Integer
            optional :division, type: String, values: NursingCareHistory.divisions.keys
            optional :defecation, type: Integer
            optional :complexion, type: String, values: NursingCareHistory.complexions.keys
            optional :sweating, type: String, values: NursingCareHistory.sweatings.keys
            optional :physical_care, type: String, values: NursingCareHistory.physical_cares.keys
            optional :urination, type: Integer
            optional :hydration, type: Integer
            optional :full_body_bath, type: String
            optional :environmental_arrangement, type: Boolean
            optional :consultation_assistance, type: Boolean
            optional :note, type: String
            optional :toilet_assistance, type: Boolean
            optional :diaper_check, type: Boolean
            optional :pad_confirmation, type: Boolean
            optional :urinal_cleaning, type: Boolean
            optional :maintain_posture, type: Boolean
            optional :eating_assistance, type: String
            optional :cleaning, type: String
            optional :full_body_bath_procedure, type: Boolean
            optional :washing_hair, type: Boolean
            optional :washbasin, type: Boolean
            optional :oral_care, type: Boolean
            optional :dressing_assistance, type: Boolean
            optional :position_exchange, type: Boolean
            optional :transfer_assistance, type: Boolean
            optional :watch_over, type: Boolean
            optional :start_time, type: String
            optional :end_time, type: String
            optional :start_time_format, type: String
            optional :end_time_format, type: String
            optional :record, type: Boolean
            optional :blood_pressure, type: String
            optional :temperature, type: String
            optional :updated_time, type: String
            optional :summary, type: String
          end

          put do
            schedule_date = ScheduleDate.find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            nursing_care_history = schedule_date.nursing_care_history
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_care_history.blank?

            params_start_time = params_nursing_care_history[:start_time_format]
            if params_start_time.present?
              source_start_time = nursing_care_history.start_time_format
              return error!({ 'messages': I18n.t('errors.messages.not_permission') }, UNPROCESSABLE_ENTITY) if source_start_time != params_start_time
            end

            params_end_time = params_nursing_care_history[:end_time_format]
            if params_end_time.present?
              source_end_time = nursing_care_history.end_time_format
              return error!({ 'messages': I18n.t('errors.messages.not_permission') }, UNPROCESSABLE_ENTITY) if source_end_time != params_end_time
            end

            history_params = params_nursing_care_history
            source_nursing_care = nursing_care_history.attributes.except('created_at', 'updated_at', 'id', 'updated_time')
            is_updated = source_nursing_care != history_params.except('updated_time')
            history_params.merge!({ is_staff_update: true }) if is_updated

            if nursing_care_history.update(history_params)
              if is_updated
                change_params = nursing_care_history.attributes.except("id", "created_at", "updated_at", "summary")
                change_params.merge!({ is_staff_update: true })
                nursing_care_history.nursing_care_history_changes.create(change_params)
              end
              schedule_date.update_columns(nurse_id: nursing_care_history.nurse_id)

              { success: I18n.t('nursing_care_history.success.updated') }
            else
              error!(nursing_care_history.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET /api/v1/staff/nursing_care_histories/schedule_date',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :schedule_date_id, type: Integer, message: I18n.t('nursing_care_history.error.validate.blank')
          end

          get '/schedule_date' do
            schedule_date = ScheduleDate.find_by(id: params[:schedule_date_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule_date.blank?

            @nursing_care_history = schedule_date.nursing_care_history
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @nursing_care_history.blank?

            present @nursing_care_history
          end
        end
      end

      helpers do
        def params_nursing_care_history
          params.slice(:schedule_date_id, :patient_id, :nurse_id, :service_id, :service_type_id, :division, :defecation,
                       :complexion, :sweating, :physical_care, :urination, :hydration, :full_body_bath, :environmental_arrangement,
                       :consultation_assistance, :note, :toilet_assistance, :diaper_check, :pad_confirmation, :urinal_cleaning,
                       :maintain_posture, :eating_assistance, :cleaning, :full_body_bath_procedure, :washing_hair, :washbasin,
                       :oral_care, :dressing_assistance, :position_exchange, :transfer_assistance, :watch_over, :start_time,
                       :end_time, :start_time_format, :end_time_format, :record, :blood_pressure, :temperature, :updated_time,
                       :summary)
        end
      end
    end
  end
end
