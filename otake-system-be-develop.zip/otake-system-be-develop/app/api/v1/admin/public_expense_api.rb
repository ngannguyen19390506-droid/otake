module V1
  module Admin
    class PublicExpenseApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :public_expenses do
          # index public expenses
          desc 'GET api/v1/admin/public_expenses'
          params do
            requires :patient_id, type: Integer, message: I18n.t('public_expense.error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @public_expenses = patient.public_expenses.default_order
            serialized_public_expenses = @public_expenses.map do |public_expense|
              PublicExpenseSerializer.new(public_expense).as_json
            end
            present :serialized_public_expenses, serialized_public_expenses
          end

          # Create PublicExpense
          desc 'POST api/v1/admin/public_expenses'
          params do
            requires :patient_id, type: Integer, message: I18n.t('public_expense.error.validate.blank')
            requires :start_date, type: Date, message: I18n.t('public_expense.error.validate.blank')
            requires :end_date, type: Date, message: I18n.t('public_expense.error.validate.blank')
            requires :system_name, type: String, message: I18n.t('public_expense.error.validate.blank')
            requires :cost_number, type: String, message: I18n.t('public_expense.error.validate.blank')
            requires :beneficiary_number, type: String, message: I18n.t('public_expense.error.validate.blank')
            optional :payment_amount, type: Integer
            requires :benefit_rate, type: Float, message: I18n.t('public_expense.error.validate.blank')
          end
          post do
            existing_expense = PublicExpense.where(
              patient_id: params_public_expense[:patient_id],
              start_date: params_public_expense[:start_date],
              end_date: params_public_expense[:end_date],
              system_name: params_public_expense[:system_name],
              cost_number: params_public_expense[:cost_number],
              beneficiary_number: params_public_expense[:beneficiary_number],
              payment_amount: params_public_expense[:payment_amount],
              benefit_rate: params_public_expense[:benefit_rate]&.round(2)
            )
            return error!({ message: I18n.t('errors.messages.already_exists') }, UNPROCESSABLE_ENTITY) if existing_expense.present?

            public_expense = PublicExpense.new(params_public_expense)
            if public_expense.save
              { success: I18n.t('public_expense.success.added') }
            else
              error!(public_expense.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Get PublicExpense detail
          desc 'GET api/v1/admin/public_expenses/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            @public_expense = PublicExpense.find(params[:id])
            present @public_expense
          end

          # # Update PublicExpense
          # desc 'PUT api/v1/admin/public_expenses/:id'
          # params do
          #   requires :id, type: Integer
          #   optional :patient_id, type: Integer
          #   optional :start_date, type: Date
          #   optional :end_date, type: Date
          #   optional :system_name, type: String
          #   optional :cost_number, type: String
          #   optional :beneficiary_number, type: String
          #   optional :payment_amount, type: Integer
          #   optional :benefit_rate, type: Float
          # end
          # put ':id' do
          #   public_expense = PublicExpense.find(params[:id])
          #   if public_expense.update(params_public_expense)
          #     { success: I18n.t('public_expense.success.updated') }
          #   else
          #     error!(public_expense.error_messages, UNPROCESSABLE_ENTITY)
          #   end
          # end
        end
      end

      helpers do
        def params_public_expense
          params_public_expense = params.slice(
            :patient_id, :start_date, :end_date, :system_name, :cost_number,
            :beneficiary_number, :payment_amount, :benefit_rate
          )
          params_public_expense[:start_date] = convert_date(params_public_expense[:start_date]) if params_public_expense[:start_date].present?
          params_public_expense[:end_date] = convert_date(params_public_expense[:end_date]) if params_public_expense[:end_date].present?
          params_public_expense
        end
      end
    end
  end
end
