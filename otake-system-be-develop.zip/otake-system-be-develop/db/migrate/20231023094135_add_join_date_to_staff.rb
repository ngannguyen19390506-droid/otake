class AddJoinDateToStaff < ActiveRecord::Migration[7.0]
  def change
    add_column :nursing_staffs, :join_date, :date
  end
end
