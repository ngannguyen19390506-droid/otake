class HealthCheckController < ApplicationController
  def check
    render plain: "ok"
  end
end