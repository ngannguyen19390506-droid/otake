# == Schema Information
#
# Table name: improvement_nursing_care_plans
#
#  id                       :bigint           not null, primary key
#  care_plan_type           :string
#  created_at               :datetime         not null
#  updated_at               :datetime         not null
#  care_plan_id             :bigint
#  treatment_improvement_id :bigint           not null
#
# Indexes
#
#  idx_incp_on_improvement_id                         (treatment_improvement_id)
#  index_improvement_nursing_care_plans_on_care_plan  (care_plan_type,care_plan_id)
#
# Foreign Keys
#
#  fk_rails_...  (treatment_improvement_id => treatment_improvements.id)
#
class ImprovementNursingCarePlan < ApplicationRecord
  include ApiCommon

  belongs_to :care_plan, polymorphic: true
  belongs_to :treatment_improvement

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_changes_without_timestamps(previous_changes)
      all_changes.each do |changed_attribute, (before_value, after_value)|
        text_description = '処遇改善加算'
        before_value = TreatmentImprovement.find(before_value).name
        after_value = TreatmentImprovement.find(after_value).name
        create_change_history_care_plan(user_admin_id, text_description, before_value, after_value)
      end
    rescue StandardError => e
      e
    end
  end

  def create_change_history_care_plan(user_admin_id, text_description, before_value, after_value)
    ChangeHistory.create!(
      user_admin_id: user_admin_id,
      changeable_id: care_plan_id,
      changeable_type: care_plan_type,
      changed_attribute: text_description,
      before_change: before_value,
      after_change: after_value,
      date: Time.zone.today
    )
  end
end
