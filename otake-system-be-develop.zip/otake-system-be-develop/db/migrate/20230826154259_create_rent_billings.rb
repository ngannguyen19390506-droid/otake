class CreateRentBillings < ActiveRecord::Migration[7.0]
  def change
    create_table :rent_billings do |t|
      t.integer :patient_id
      t.string :year_month
      t.bigint :rent_cost
      t.bigint :utility_cost
      t.bigint :food_cost
      t.bigint :living_cost
      t.bigint :refund_cost

      t.timestamps
    end
  end
end
