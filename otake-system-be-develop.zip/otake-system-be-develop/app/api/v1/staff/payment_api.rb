module V1
  module Staff
    class PaymentApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }
      namespace :staff do
        resources :payments do
          # Detail
          desc 'GET /api/v1/staff/payments'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @payment = patient.payment
            return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @payment.blank?

            present @payment
          end
        end
      end
    end
  end
end
