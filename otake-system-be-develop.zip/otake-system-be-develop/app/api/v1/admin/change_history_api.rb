module V1
  module Admin
    class ChangeHistoryApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :change_histories do
          desc 'GET api/v1/admin/change_histories'
          params do
            requires :changeable_type, type: String, values: %w(NursingStaff Patient EvalueOne EvalueTwo NursingCarePlan DisabilityCarePlan Payment)
            requires :changeable_id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
          end
          get do
            target_instance = params[:changeable_type].constantize.find(params[:changeable_id])
            @query = target_instance.change_histories
            if params[:sortKey].present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if params[:sortKey] == 'user_admin'
                @query = @query.joins(:user_admin).order("user_admins.user_name #{sort_order}")
              else
                @query = @query.order(params[:sortKey] => sort_order)
              end
            else
              @query = @query.default_order
            end
            page = params[:page].presence || 1
            @change_histories = @query.includes(:user_admin).page(page).per(params[:per])
            serialized_change_histories = @change_histories.map do |change_history|
              ChangeHistorySerializer.new(change_history).as_json
            end
            title = get_page_title(target_instance, params[:changeable_type])

            present :page, page.to_i
            present :title, title
            present :total_items, @change_histories.total_count
            present :total_pages, @change_histories.total_pages
            present :change_histories, serialized_change_histories
          end
        end
      end

      helpers do
        def get_page_title(target_instance, changeable_type)
          changeable_type_titles = {
            'EvalueOne' => 'アセスメントシート1',
            'EvalueTwo' => 'アセスメントシート2',
            'NursingCarePlan' => 'ケアマネプラン(介護)',
            'DisabilityCarePlan' => 'ケアマネプラン(障害)',
            'Payment' => '請求方法'
          }

          title = if changeable_type == 'NursingStaff' || changeable_type == 'Patient'
                    target_instance.family_name
                  else
                    "#{target_instance.patient.name_kana} #{changeable_type_titles[changeable_type]}"
                  end
          "#{title} 変更履歴一覧"
        end
      end
    end
  end
end
