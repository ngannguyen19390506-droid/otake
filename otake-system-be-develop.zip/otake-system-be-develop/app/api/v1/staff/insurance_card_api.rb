module V1
  module Staff
    class InsuranceCardApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :insurance_cards do
          # index
          desc 'GET /api/v1/staff/insurance_cards'
          params do
            requires :patient_id, type: Integer, message: I18n.t('insurance_card.error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @insurance_cards = patient.insurance_cards.default_order
            serialized_insurance_cards = @insurance_cards.map do |service|
              InsuranceCardSerializer.new(service, { use_conversion_methods: true }).as_json
            end
            present :serialized_insurance_cards, serialized_insurance_cards
          end

          # Detail Insurance Card
          desc 'GET api/v1/staff/insurance_cards/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              @insurance_card = InsuranceCard.find(params[:id])
              present @insurance_card
            end
          end
        end
      end
    end
  end
end
