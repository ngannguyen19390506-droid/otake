class UpdateServiceNursingCarePlanAndShiftManagement < ActiveRecord::Migration[7.0]
  def change
    # services
    remove_column :services, :service_content

    # nursing_care_plans
    remove_column :nursing_care_plans, :service_id
    add_column :nursing_care_plans, :remarks, :string

    # shift_managements
    remove_column :shift_managements, :is_present
    change_column :shift_managements, :shift_name, :string, null: true
  end
end
