class RemoveReferenceFromNotifications < ActiveRecord::Migration[7.0]
  def change
    remove_reference :notifications, :user_admin
    add_column :notifications, :sender_id, :integer
    add_column :notifications, :sender_type, :string
    add_index :notifications, [:sender_type, :sender_id]
  end
end
