module V1
  module Admin
    class NursingStaffSerializer < ActiveModel::Serializer
      attributes :id,
                 :last_name,
                 :first_name,
                 :cellphone_number,
                 :telephone_number,
                 :birth_date,
                 :sex,
                 :last_name,
                 :first_name,
                 :last_name_kana,
                 :first_name_kana,
                 :zipcode,
                 :district,
                 :city,
                 :street,
                 :nurse_code,
                 :my_number,
                 :building_name,
                 :family_name,
                 :name_kana,
                 :age,
                 :join_date,
                 :status,
                 :employment_type

      has_many :contact_relatives, serializer: ContactRelativeSerializer
      has_many :degrees, serializer: DegreeSerializer

      delegate :age, to: :object
    end
  end
end
