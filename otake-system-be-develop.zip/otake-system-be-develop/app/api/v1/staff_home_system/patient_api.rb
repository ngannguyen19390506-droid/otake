module V1
  module StaffHomeSystem
    class PatientApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :staff_home_system do
        resources :patients do
          # index
          desc 'GET api/v1/staff_home_system/patients'
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :fullname, type: String
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
            optional :schedule_date, type: Date
            optional :year_month, type: String # get list patient has daily heaths record by year month
          end
          get do
            if params[:year_month].present?
              start_month = params[:year_month].to_date.beginning_of_month
              end_month = start_month.end_of_month
            end

            if params[:schedule_date].present?
              patient_schedule_memos = Patient.using.includes(schedule_memo_at_homes: :schedule_date_at_homes).where(schedule_memo_at_homes: {schedule_date_at_homes: {date: params[:schedule_date]}})
              patient_schedule = Patient.using.includes(schedule_at_homes: :schedule_date_at_homes).where(schedule_at_homes: {schedule_date_at_homes: {date: params[:schedule_date]}})
              patients = (patient_schedule_memos.select(:id, :family_name, :name_kana) + patient_schedule.select(:id, :family_name, :name_kana)).uniq

              return present :data, patients
            elsif params[:year_month].present?
              patients = Patient.using.includes(care_plan_at_homes: :daily_healths, schedule_at_homes: :schedule_date_at_homes)
                                      .where(care_plan_at_homes: { year_month: params[:year_month]})
                                      .where(schedule_date_at_homes: {date: start_month..end_month})
                                      .select(:id, :family_name, :name_kana)
              return present :data, patients
            end

            @query = Patient.using
            sort_key = params[:sortKey]
            if params[:get_all]
              @query = @query.includes(care_plan_at_homes: :daily_healths, schedule_at_homes: :schedule_date_at_homes)
              @query = @query.where(schedule_date_at_homes: {date: start_month..end_month})
              return present :data, @query.default_order.select(:id, :family_name, :name_kana)
            end

            @q = @query.ransack(family_name_or_name_kana_cont: params[:fullname])
            page = (params[:page].presence || 1).to_i
            @patients = @q.result.default_order.page(page).per(params[:per]) if sort_key.blank?
            if sort_key.present?
              sort_key = 'name_kana' if sort_key == 'name'
              sort_key = 'district' if sort_key == 'residence'
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if sort_key == 'age'
                sort_key = 'birth_date'
                sort_order = sort_order == 'ASC' ? 'DESC' : 'ASC'
              end
              @patients = if sort_key == 'name_kana'
                            sorted = @q.result.sort_by(&:name_kana)
                            sorted.reverse! if sort_order != 'ASC'
                            sorted = Kaminari.paginate_array(sorted)
                            sorted
                          elsif %w(care_level insurance_number insurance_period responsible_policy_management).include?(sort_key)
                            sort_key = 'start_insurance' if sort_key == 'insurance_period'
                            @q.result.left_outer_joins(:insurance_cards)
                                      .select('patients.*, MAX(insurance_cards.id) AS max_insurance_card_id')
                                      .group('patients.id')
                                      .order("MAX(insurance_cards.#{sort_key}) #{sort_order} NULLS LAST")
                          else
                            @q.result.order(sort_key => sort_order)
                          end.page(page).per(params[:per])
            end
            serialized_patients = @patients.map do |patient|
              PatientSerializer.new(patient).as_json
            end
            present :page, page
            present :total_items, @patients.total_count
            present :total_pages, @patients.total_pages
            present :patients, serialized_patients
          end

          # patient detail
          desc 'GET api/v1/staff_home_system/patients/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              @patient = Patient.find_by(id: params[:id])
              return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @patient.blank?

              present @patient
            end
          end
        end
      end
    end
  end
end
