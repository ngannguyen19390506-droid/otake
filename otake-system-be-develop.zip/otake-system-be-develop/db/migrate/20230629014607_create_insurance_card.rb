class CreateInsuranceCard < ActiveRecord::Migration[7.0]
  def change
    create_table :insurance_cards do |t|
      t.references :patient,                       null: false, foreign_key: true
      t.string     :insurance,                     null: false
      t.integer    :insurance_number,              null: false
      t.date       :start_insurance,               null: false
      t.date       :end_insurance,                 null: false
      t.integer    :insurance_company_number,      null: false
      t.string     :certification_department,      null: false
      t.date       :release_date,                  null: false
      t.date       :certification_date,            null: false
      t.date       :start_validate,                null: false
      t.date       :end_validate,                  null: false
      t.string     :care_level,                    null: false
      t.string     :home_care_office,              null: false
      t.date       :care_application_start_date,   null: false
      t.string     :responsible_policy_management, null: false
      t.string     :comprehensive_support_center,  null: false
      t.date       :announcement_date,             null: false
      t.integer    :benefit_limit,                 null: false
      t.date       :start_date_apply_benefits,     null: false

      t.timestamps
    end
  end
end
