module V1
  module Staff
    class NotificationApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :notifications do
          desc 'GET api/v1/staff/notifications',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
            optional :search, type: String
            requires :notify_tab, type: Integer, desc: 'tab 重要事項 = 1, tab 申し送り事項 = 2'
            optional :start_at, type: String, desc: '2024/03/10'
            optional :end_at, type: String, desc: '2024/03/20'
            optional :notification_category_id, type: Integer
          end
          get do
            page = (params[:page].presence || 1).to_i
            objects = Notification.noti_by_admin.or(Notification.noti_by_staff)
            case params[:notify_tab]
            when 1
              objects = objects.where.not(patient_id: nil)
            when 2
              objects = objects.where.not(notification_category_id: nil)
            end
            query = Hash.new.tap do |q|
              q[:title_or_content_cont] = params[:search] if params[:search].present?
              q[:notification_category_id_eq] = params[:notification_category_id] if params[:notification_category_id].present?
              q[:created_at_gteq] = convert_date(params[:start_at]).beginning_of_day if params[:start_at].present?
              q[:created_at_lteq] = convert_date(params[:end_at]).end_of_day if params[:end_at].present?
            end

            objects = objects.ransack(query).result.by_created_at_desc
            importants = []
            if params[:notify_tab] == 1
              importants = objects.where('deployment_date >= ?', Time.current.to_date)
                                  .by_deployment_date_desc.limit(10)
              objects = objects.where('deployment_date < ?', Time.current.to_date)
            end

            objects = objects.page(page).per(params[:per])
            serialized_nofitications = objects.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            important_notifications = importants.map do |notification|
              NotificationSerializer.new(notification).as_json
            end

            present :page, page
            present :total_page, objects.total_pages
            present :total_items, objects.total_count
            present :notifications, serialized_nofitications
            present :importants, important_notifications
          end

          desc 'GET api/v1/staff/notifications/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              notification = Notification.find(params[:id])

              notification.notification_view_logs.find_or_create_by(viewer_id: current_staff.id, viewer_type: current_staff.class.name)
              present notification
            end
          end

          desc 'GET api/v1/staff/notifications/:reply_to/replies_by_parent'
          params do
            requires :reply_to, type: Integer
          end
          get ':reply_to/replies_by_parent' do
            begin
              objects = Notification.includes(:mention_notifications).where(reply_to: params[:reply_to])
              mention_ids = MentionNotification.where(mention_type: [nil, 'Patient'])
                                               .or(MentionNotification.where(m_id: current_staff.id, mention_type: 'NursingStaff'))
                                               .pluck(:notification_id)
              objects = objects.where(mention_notifications: { id: nil }).or(objects.where(id: mention_ids))
              serialized_nofitications = objects.map do |notification|
                NotificationSerializer.new(notification).as_json
              end

              present :notifications, serialized_nofitications
            end
          end

          desc 'POST api/v1/staff/notifications',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer
            requires :content, type: String, desc: 'content'
            requires :deployment_date, type: Date, desc: '2024/02/29'
          end
          post do
            begin
              deployment_date = params[:deployment_date].to_date
              if deployment_date < Time.current.to_date
                return error!(I18n.t('errors.messages.date_less_than_current_date'), UNPROCESSABLE_ENTITY)
              end

              params.merge!({ sender_id: current_staff.id, notify_type: "noti_by_staff",
                              poster: current_staff.name_kana || "Staff", sender_type: current_staff.class.name })
              notification = Notification.new(params)
              if notification.save
                { success: I18n.t('success.messages.added') }
              else
                error!(notification.error_messages, UNPROCESSABLE_ENTITY)
              end
            end
          end

          desc 'POST api/v1/staff/notifications/group',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :notification_category_id, type: Integer
            requires :content, type: String, desc: 'content'
            requires :target_person, type: String, desc: 'content'
            requires :discoverer, type: String, desc: 'content'
            requires :occurred_at, type: DateTime, desc: 'datetime'
            requires :occurrence_status, type: String, desc: 'content'
            requires :response_action, type: String, desc: 'content'
            requires :confirmer, type: String, desc: 'content'
            optional :file, type: File, desc: 'File (image, excel, pdf, max 10MB)'
          end
          post '/group' do
            begin
              validate_notification_group_file!(params[:file]) if params[:file].present?
              params.merge!({ sender_id: current_staff.id, notify_type: "noti_by_staff",
                              poster: current_staff.name_kana || "Admin", sender_type: current_staff.class.name })
              notification = Notification.new(params.except(:file))

              file = params[:file]
              notification.file.attach(io: file[:tempfile], filename: file[:filename], content_type: file[:type]) if params[:file].present?

              if notification.save
                { success: I18n.t('success.messages.added') }
              else
                error!(notification.error_messages, UNPROCESSABLE_ENTITY)
              end
            end
          end

          desc 'PUT api/v1/staff/notifications/:id'
          params do
            requires :id, type: Integer
            optional :title, type: String, desc: 'content'
            optional :content, type: String, desc: 'content'
            optional :reply_to, type: Integer, desc: 'parentID'
            optional :is_important, type: Boolean, desc: 'true/false'
            optional :is_deleted, type: Boolean, desc: 'true/false'
            optional :mentions, type: Array[Integer]
          end
          put ':id' do
            begin
              deleted_at = params[:is_deleted] ? Time.current : nil
              params.merge!(deleted_at: deleted_at)
              is_editable = params[:is_deleted] ? false : true
              params.merge!(deleted_at: deleted_at, is_editable: is_editable)
              notification = Notification.find_by(id: params[:id])
              return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if notification.blank?

              if params[:is_deleted].present?
                notifications = Notification.by_level(notification.level + 1, notification.id)
                if notifications.present?
                  notifications.update_all(is_editable: is_editable)
                  notifications.map do |noti|
                    render_notifications(noti.id, noti.level + 1, is_editable)
                  end
                end
              end

              mentions = params[:mentions]
              if notification.update(params.except('mentions'))
                notification.mention_notifications&.destroy_all
                if mentions.present?
                  mentions.each do |mention|
                    notification.mention_notifications.create(m_id: mention)
                  end
                end

                present notification
              else
                error!(notification.error_messages, UNPROCESSABLE_ENTITY)
              end
            end
          end
        end
      end
    end
  end
end
