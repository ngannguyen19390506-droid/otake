module V1
  module StaffHomeSystem
    class UserHomeSystemSerializer < ActiveModel::Serializer
      attributes :id, :user_name, :user_code, :user_type, :created_at
    end
  end
end
