module V1
  module Staff
    class ServiceTypeApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :service_types do
          desc 'GET /api/v1/staff/service_types'
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
          end
          get do
            @query = ServiceType.all
            return present :data, @query.default_order if params[:get_all] == true

            page = (params[:page].presence || 1).to_i
            @service_types = @query.default_order
            if params[:sortKey].present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              @service_types = @query.order(params[:sortKey] => sort_order)
            end
            @service_types = @service_types.page(page).per(params[:per])
            serialized_service_types = @service_types.map do |service_type|
              ServiceTypeSerializer.new(service_type).as_json
            end
            present :page, page
            present :total_items, @service_types.total_count
            present :total_pages, @service_types.total_pages
            present :serialized_service_types, serialized_service_types
          end
        end
      end
    end
  end
end
