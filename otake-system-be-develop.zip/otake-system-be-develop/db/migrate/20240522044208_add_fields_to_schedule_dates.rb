class AddFieldsToScheduleDates < ActiveRecord::Migration[7.0]
  def change
    add_column :schedule_dates, :start_time_format, :string
    add_column :schedule_dates, :end_time_format, :string
  end
end
