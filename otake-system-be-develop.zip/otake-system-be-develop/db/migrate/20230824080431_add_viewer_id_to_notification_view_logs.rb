class AddViewerIdToNotificationViewLogs < ActiveRecord::Migration[7.0]
  def change
    add_column :notification_view_logs, :viewer_id, :integer
    add_column :notification_view_logs, :viewer_type, :string
  end
end
