# == Schema Information
#
# Table name: insurance_cards
#
#  id                            :bigint           not null, primary key
#  announcement_date             :date
#  benefit_limit                 :float
#  care_application_start_date   :date
#  care_level                    :string
#  certification_date            :date
#  certification_department      :integer
#  city                          :string
#  comprehensive_support_center  :string
#  district                      :string
#  end_insurance                 :date
#  end_validate                  :date
#  home_care_office_input_first  :string
#  home_care_office_input_second :string
#  home_care_office_type         :integer
#  home_care_support_office_name :string
#  insurance_company_number      :string
#  insurance_name                :string
#  insurance_number              :string
#  release_date                  :date
#  responsible_policy_management :string
#  start_date_apply_benefits     :date
#  start_insurance               :date
#  start_validate                :date
#  street                        :string
#  zipcode                       :string
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#  patient_id                    :bigint           not null
#
# Indexes
#
#  index_insurance_cards_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class InsuranceCard < ApplicationRecord
  include ApiCommon
  belongs_to :patient

  validates :insurance_name, :start_insurance, :end_insurance,
            :start_validate, :end_validate, :care_level, :care_application_start_date,
            :benefit_limit, :start_date_apply_benefits, :home_care_office_type, presence: true

  validates :insurance_company_number, presence: true, numericality: { only_integer: true }
  validates :insurance_number, presence: true, if: -> { certification_department == 'certified' }
  validates :insurance_company_number, :insurance_number, length: { maximum: MAX_LENGTH_FIFTY }
  validates :responsible_policy_management, :announcement_date, :responsible_policy_management, presence: true, if: :own_office?
  # validates :zipcode, :city, :district, :street, presence: true, if: :other_office?

  enum certification_department: { pending: 0, certified: 1 }
  enum home_care_office_type: { own_office: 1, other_office: 2, self_created_or_not_declared: 3 }

  before_save :round_benefit_limit

  private

  def round_benefit_limit
    self.benefit_limit = benefit_limit.round(2) if benefit_limit.present?
  end
end
