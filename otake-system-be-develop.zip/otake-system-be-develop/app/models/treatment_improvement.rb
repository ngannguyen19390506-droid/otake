# == Schema Information
#
# Table name: treatment_improvements
#
#  id           :bigint           not null, primary key
#  name         :string           not null
#  patient_type :integer          not null
#  rate         :float
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#
# Indexes
#
#  index_treatment_improvements_on_name  (name) UNIQUE
#
class TreatmentImprovement < ApplicationRecord
  include ApiCommon

  validates :name, :patient_type, :rate, presence: true
  validates :name, uniqueness: true
  enum patient_type: { disability: 0, normal: 1 }

  has_many :improvement_nursing_care_plans
  has_many :nursing_care_plans, through: :improvement_nursing_care_plans
end
