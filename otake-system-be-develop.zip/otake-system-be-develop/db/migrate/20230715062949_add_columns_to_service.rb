class AddColumnsToService < ActiveRecord::Migration[7.0]
  def change
    add_column :services, :unit_price, :integer
    add_column :services, :patient_type, :integer
  end
end
