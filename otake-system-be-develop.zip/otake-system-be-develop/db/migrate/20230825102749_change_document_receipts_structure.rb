class ChangeDocumentReceiptsStructure < ActiveRecord::Migration[7.0]
  def change
    change_column(:document_receipts, :files, :text)
  end
end
