module V1
  module Staff
    class NursingCareHistorySerializer < ActiveModel::Serializer
      attributes :id,
                 :patient_id,
                 :nurse_id,
                 :division,
                 :defecation,
                 :full_body_bath,
                 :complexion,
                 :sweating,
                 :environmental_arrangement,
                 :consultation_assistance,
                 :note,
                 :toilet_assistance,
                 :diaper_check,
                 :pad_confirmation,
                 :urination,
                 :urinal_cleaning,
                 :maintain_posture,
                 :hydration,
                 :eating_assistance,
                 :cleaning,
                 :full_body_bath_procedure,
                 :washing_hair,
                 :washbasin,
                 :oral_care,
                 :dressing_assistance,
                 :position_exchange,
                 :transfer_assistance,
                 :watch_over,
                 :schedule_date_id,
                 :service_id,
                 :service_type_id,
                 :start_time,
                 :end_time,
                 :start_time_format,
                 :end_time_format,
                 :physical_care,
                 :record,
                 :updated_time,
                 :updated_time_format,
                 :blood_pressure,
                 :temperature,
                 :summary,
                 :schedule_service_type

      belongs_to :nurse, class_name: 'NursingStaff', serializer: NursingStaffSerializer
      belongs_to :patient, serializer: PatientSerializer
      belongs_to :schedule_date, serializer: ScheduleDateSerializer
      belongs_to :service, serializer: ServiceSerializer
      belongs_to :service_type, serializer: ServiceTypeSerializer

      def updated_time
        object.updated_time&.to_datetime&.strftime('%Y/%m/%d %H:%M')
      end
      def updated_time_format
        date = object.updated_time&.to_date
        updated_date = object.updated_time&.to_datetime&.strftime('%Y/%m/%d %H:%M')&.split(' ')
        updated_date.insert(1, "(#{I18n.t("day_name.#{date.wday}")})") if date.present?
        updated_date&.join(' ')
      end

      def schedule_service_type
        object&.schedule_date&.scheduleable&.service_type
      end
    end
  end
end
