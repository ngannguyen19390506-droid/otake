class CreateEvalueOne < ActiveRecord::Migration[7.0]
  def change
    create_table :evalue_ones do |t|
      t.references :patient,                null: false, foreign_key: true
      t.string     :average_blood_pressure, null: false
      t.string     :temp,                   null: false
      t.string     :heartbeat,              null: false
      t.string     :pre_history,            null: false
      t.string     :daily_life_challenges,  null: false
      t.string     :note,                   null: false
      t.string     :character,              null: false
      t.integer    :hobby,                  null: false, limit: 1
      t.string     :family_circumstances,   null: false
      t.string     :special_notes,          null: false

      t.timestamps
    end
  end
end
