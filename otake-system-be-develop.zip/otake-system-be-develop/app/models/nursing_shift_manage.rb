# == Schema Information
#
# Table name: nursing_shift_manages
#
#  id                 :bigint           not null, primary key
#  confirmed_by_admin :boolean          default(FALSE)
#  confirmed_by_staff :boolean          default(FALSE)
#  is_sent_for_staff  :boolean          default(FALSE)
#  status             :integer          default("initial")
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#  nurse_id           :bigint           not null
#  shift_id           :bigint           not null
#
# Indexes
#
#  index_nursing_shift_manages_on_nurse_id  (nurse_id)
#  index_nursing_shift_manages_on_shift_id  (shift_id)
#
# Foreign Keys
#
#  fk_rails_...  (nurse_id => nursing_staffs.id)
#  fk_rails_...  (shift_id => shift_managements.id)
#
class NursingShiftManage < ApplicationRecord
  include ApiCommon

  belongs_to :nurse, class_name: 'NursingStaff'
  belongs_to :shift, class_name: 'ShiftManagement'

  enum status: { initial: 0, draft: 1, sent: 2, approved: 3 }

  scope :available_working_nurses_on_date, ->(date, start_time, end_time) {
    joins(:shift)
      .where.not(status: 'initial')
      .where('shift_managements.shift_date = ?', date)
      .where('(shift_managements.start_time <= ? AND shift_managements.end_time >= ?)',
             start_time, end_time)
      .pluck(:nurse_id)
  }
end
