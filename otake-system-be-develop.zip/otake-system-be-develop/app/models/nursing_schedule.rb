# == Schema Information
#
# Table name: nursing_schedules
#
#  id         :bigint           not null, primary key
#  date       :date
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  nurse_id   :bigint
#
# Indexes
#
#  index_nursing_schedules_on_patient_id  (nurse_id)
#
class NursingSchedule < ApplicationRecord
  belongs_to :nurse, class_name: 'NursingStaff', foreign_key: :nurse_id
end
