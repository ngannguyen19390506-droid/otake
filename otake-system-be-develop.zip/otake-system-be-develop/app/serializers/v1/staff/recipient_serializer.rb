module V1
  module Staff
    class RecipientSerializer < ActiveModel::Serializer
      attributes :id, :business_code, :recipient_code, :service_content, :contract_allocation_amount,
                 :contract_date, :service_end_date, :applicable_start_date, :user_burden_percentage,
                 :monthly_cost_limit, :created_at, :updated_at

      belongs_to :patient
    end
  end
end