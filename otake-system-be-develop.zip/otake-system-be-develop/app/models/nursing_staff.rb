# == Schema Information
#
# Table name: nursing_staffs
#
#  id                 :bigint           not null, primary key
#  birth_date         :date             not null
#  building_name      :string
#  cellphone_number   :string
#  city               :string           not null
#  district           :string           not null
#  employment_type    :integer          default("undecided")
#  encrypted_password :string
#  family_name        :string
#  first_name         :string           not null
#  first_name_kana    :string           not null
#  join_date          :date
#  last_name          :string           not null
#  last_name_kana     :string           not null
#  my_number          :string
#  name_kana          :string
#  nurse_code         :string           not null
#  password           :string
#  sex                :integer          not null
#  status             :integer
#  street             :string           not null
#  telephone_number   :string           not null
#  zipcode            :string           not null
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#
require 'bcrypt'

class NursingStaff < ApplicationRecord
  include ApiCommon

  has_many :nursing_shift_manages, foreign_key: :nurse_id, dependent: :destroy
  has_many :shifts, through: :nursing_shift_manages
  has_many :messages, as: :sender, dependent: :destroy
  has_many :authentication_tokens, dependent: :destroy
  has_many :schedule_dates, foreign_key: :nurse_id
  has_many :schedules, through: :schedule_dates, source: :scheduleable, source_type: 'Schedule'
  has_many :change_histories, as: :changeable, dependent: :destroy
  has_many :contact_relatives, foreign_key: :nurse_id, dependent: :destroy
  has_many :patients, through: :schedules
  has_many :monthly_holidays, foreign_key: :nurse_id, dependent: :destroy
  has_many :holidays, through: :monthly_holidays
  has_many :degrees, foreign_key: :nurse_id, dependent: :destroy
  has_many :routines, foreign_key: :nurse_id, dependent: :destroy
  has_many :nursing_schedules, foreign_key: :nurse_id, dependent: :destroy
  has_many :shift_registrations, foreign_key: :nurse_id, dependent: :destroy

  has_one :nursing_care_history, foreign_key: :nurse_id, dependent: :destroy

  validates :telephone_number, :birth_date, :sex, :last_name, :first_name,
            :last_name_kana, :first_name_kana, :zipcode, :district, :city, :street,
            :nurse_code, presence: true
  validates :zipcode, format: { with: ZIP_CODE_REGEX }
  validates :telephone_number, length: { in: MIN_LENGTH_TEN..MAX_LENGTH_TWENTY }
  validates :cellphone_number, :my_number, length: { in: MIN_LENGTH_TEN..MAX_LENGTH_TWENTY }, allow_blank: true

  validates :last_name, :first_name,
            format: { with: NAME_REGEX, message: I18n.t('errors.messages.name_invalid') }
  validates :last_name_kana, :first_name_kana,
            format: { with: NAME_KATAKANA_REGEX, message: I18n.t('errors.messages.name_invalid') }
  # validate :validate_address_with_zipcode

  enum sex: { 女: 0, 男: 1 } # female: 0, male: 1
  enum status: { active: 1, on_leave: 2, resigned: 3 }
  enum employment_type: { full_time: 0, part_time_1: 1, part_time_2: 2, undecided: 3 }

  scope :by_family_name_asc, -> { order(family_name: :asc) }
  scope :by_family_name_desc, -> { order(family_name: :desc) }

  accepts_nested_attributes_for :contact_relatives
  accepts_nested_attributes_for :degrees

  def self.ransackable_attributes(_auth_object = nil)
    %w[family_name name_kana first_name_kana last_name_kana status building_name city district street]
  end

  ransacker :status, formatter: proc { |v| statuses[v] } do |parent|
    parent.table[:status]
  end

  def self.ransackable_associations(_auth_object = nil)
    %w[contact_relatives degree]
  end

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_tracked_changes
      all_changes.each do |changed_attribute, (before_value, after_value)|
        before_value = all_changes[:degrees] if changed_attribute == 'degrees'
        process_changes(changed_attribute, before_value, after_value, user_admin_id)
      end
    rescue StandardError => e
      e
    end
  end

  private

  def process_changes(changed_attribute, before_value, after_value, user_admin_id)
    if changed_attribute == 'contact_relatives'
      # before_value: self.contact_relatives.first, self.after_value: contact_relatives.second
      process_contact_relatives_changes(before_value, after_value, user_admin_id)
    elsif changed_attribute == 'degrees'
      # before_value: self.degrees
      process_degree_changes(before_value, user_admin_id)
    elsif changed_attribute != 'contact_relatives' && changed_attribute != 'degrees'
      if changed_attribute == 'status'
        before_value = attribute_description("status.#{before_value}")
        after_value = attribute_description("status.#{after_value}")
      end
      if changed_attribute == 'employment_type'
        before_value = attribute_description("employment_type.#{before_value}")
        after_value = attribute_description("employment_type.#{after_value}")
      end

      text_description = attribute_description(changed_attribute)
      create_change_history(user_admin_id, text_description, before_value, after_value)
    end
  end

  def process_degree_changes(change_values, user_admin_id)
    change_values.each do |value|
      next if value.blank?

      if value.keys.include?('id')
        # value: {"id"=>[nil, 132], "nurse_id"=>[nil, 103], "name"=>[nil, "degree 3333"], "expired_date"=>[nil, Sun, 23 Jul 2023]}
        degree_text_description = attribute_description("degree.title")
        before_degree_value = nil
        after_degree_value = ''
        after_degree_value += "資格名: #{value[:name][1]}" if value[:name].present?
        after_degree_value += '、' if value[:name].present? && value[:expired_date].present?
        after_degree_value += "取得年月日: #{value[:expired_date][1].strftime('%Y年%m月%d日')}" if value[:expired_date].present?

        if after_degree_value.present?
          after_degree_value = '追加されました。' + after_degree_value
          create_change_history(user_admin_id, degree_text_description, before_degree_value, after_degree_value)
        end
      else
        value.each do |attr, (before_degree_value, after_degree_value)|
          degree_text_description = attribute_description("degree.#{attr}")
          create_change_history(user_admin_id, degree_text_description, before_degree_value, after_degree_value)
        end
      end
    end
  end

  def extract_tracked_changes
    tracked_changes = previous_changes.reject do |attr, _|
      %w[encrypted_password first_name last_name first_name_kana last_name_kana created_at updated_at].include?(attr)
    end
    contact_relatives_changes = extract_contact_relatives_changes(contact_relatives)
    degrees_changes = extract_degrees_changes(degrees)
    tracked_changes.merge(contact_relatives: contact_relatives_changes, degrees: degrees_changes)
  end

  def extract_degrees_changes(degrees)
    degrees.map { |degree| extract_changes_without_timestamps(degree.previous_changes) }
  end

  def attribute_description(attribute_name)
    descriptions = {
      'family_name' => '氏名',
      'name_kana' => '氏名(カナ)',
      'sex' => '性別',
      'birth_date' => '生年月日',
      'zipcode' => '郵便番号',
      'district' => '都道府県',
      'city' => '市区町村',
      'street' => '町名・番地',
      'building_name' => 'ビル・マンション名',
      'telephone_number' => '携帯番号1',
      'cellphone_number' => '携帯番号2',
      'my_number' => 'マイナンバー',
      'join_date' => '入社日',
      'nurse_code' => 'スタッフID',
      'status' => '在籍状況',
      'status.active' => '在籍中',
      'status.on_leave' => '休職中',
      'status.resigned' => '退職済',
      'contact_relatives.first.name' => '緊急連絡先①の氏名',
      'contact_relatives.first.relationship' => '緊急連絡先①の続柄',
      'contact_relatives.first.address' => '緊急連絡先①の住所',
      'contact_relatives.first.telephone_number' => '緊急連絡先①の電話番号',
      'contact_relatives.first.cellphone_number' => '緊急連絡先①の携帯番号',
      'contact_relatives.first.id' => '緊急連絡先①のID',
      'contact_relatives.first.nurse_id' => '担当ID',
      'contact_relatives.second.name' => '緊急連絡先②の氏名',
      'contact_relatives.second.relationship' => '緊急連絡先②の続柄',
      'contact_relatives.second.address' => '緊急連絡先②の住所',
      'contact_relatives.second.telephone_number' => '緊急連絡先②の電話番号',
      'contact_relatives.second.cellphone_number' => '緊急連絡先②の携帯番号',
      'contact_relatives.second.id' => '緊急連絡先②のID',
      'contact_relatives.second.nurse_id' => '担当ID',
      'degree.name' => '保有資格の資格名',
      'degree.expired_date' => '保有資格の取得年月日',
      'degree.title' => '保有資格',
      'employment_type' => 'ステータス',
      'employment_type.full_time' => '社員',
      'employment_type.part_time_1' => 'パート1',
      'employment_type.part_time_2' => 'パート2',
      'employment_type.undecided' => '未定'
    }

    descriptions[attribute_name] || attribute_name
  end
end
