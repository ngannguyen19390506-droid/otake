class ChangeDocumentsName < ActiveRecord::Migration[7.0]
  def change
    rename_table :documents, :document_receipts
  end
end
