module V1
  module Staff
    class HolidaySerializer < ActiveModel::Serializer
      attributes :id,
                 :date

    end
  end
end
