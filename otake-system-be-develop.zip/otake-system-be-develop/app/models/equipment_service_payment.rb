# == Schema Information
#
# Table name: equipment_service_payments
#
#  id                       :bigint           not null, primary key
#  category                 :integer          not null
#  registered               :boolean          default(FALSE), not null
#  remaining_stock_quantity :integer
#  unit_price               :integer
#  year_month               :string           not null
#  created_at               :datetime         not null
#  updated_at               :datetime         not null
#  equipment_service_id     :bigint
#  patient_id               :bigint           not null
#
# Indexes
#
#  index_equipment_service_payments_on_equipment_service_id  (equipment_service_id)
#  index_equipment_service_payments_on_patient_id            (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (equipment_service_id => equipment_services.id)
#  fk_rails_...  (patient_id => patients.id)
#
class EquipmentServicePayment < ApplicationRecord
  include ApiCommon

  enum category: { equipment: 1, service: 2, potoro: 3 }

  has_many :equipment_service_usages, dependent: :destroy

  belongs_to :patient
  belongs_to :equipment_service, optional: true
  validates :year_month, :category, presence: true

  validates :year_month, format: { with: YEAR_MONTH, message: I18n.t('errors.messages.year_month_format_invalid') }

  scope :by_year_month, ->(year_month) { where(year_month: year_month) }
end
