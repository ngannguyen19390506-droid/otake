class RenameAndRemoveNotNullForPhone < ActiveRecord::Migration[7.0]
  def change
    # nursing_staffs
    rename_column :nursing_staffs, :mobile_phone, :telephone_number
    rename_column :nursing_staffs, :desk_phone, :cellphone_number
    change_column_null :nursing_staffs, :cellphone_number, true

    # patients
    rename_column :patients, :mobile_phone, :telephone_number
    rename_column :patients, :desk_phone, :cellphone_number

    # contact_relatives
    rename_column :contact_relatives, :mobile_phone, :telephone_number
    rename_column :contact_relatives, :desk_phone, :cellphone_number
  end
end
