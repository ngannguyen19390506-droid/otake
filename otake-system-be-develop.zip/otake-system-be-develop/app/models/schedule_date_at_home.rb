# == Schema Information
#
# Table name: schedule_date_at_homes
#
#  id                     :bigint           not null, primary key
#  date                   :date             not null
#  end_time               :string           not null
#  schedule_homeable_type :string
#  start_time             :string           not null
#  value                  :string
#  created_at             :datetime         not null
#  updated_at             :datetime         not null
#  schedule_homeable_id   :bigint
#
# Indexes
#
#  index_schedule_date_at_homes_on_schedule_homeable  (schedule_homeable_type,schedule_homeable_id)
#
class ScheduleDateAtHome < ApplicationRecord
  include ApiCommon

  belongs_to :schedule_homeable, polymorphic: true

  validates :end_time, :start_time, :date, presence: true
end
