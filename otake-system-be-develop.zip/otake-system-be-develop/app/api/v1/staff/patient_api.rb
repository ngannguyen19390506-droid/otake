module V1
  module Staff
    class PatientApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :patients do
          # index
          desc 'GET api/v1/staff/patients',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :fullname, type: String
            optional :status, type: Array[String]
            optional :sortKey, type: String
            optional :order, type: String
            optional :care_plan_date, type: Date
            optional :year_month_payment, type: String
            optional :get_all, type: Boolean
            optional :schedule_date, type: String # get patient has schedule date
          end
          get do
            return [] if params[:care_plan_date].present? && params[:care_plan_date] > Time.zone.today.end_of_month

            @query = Patient.includes(:contact_relatives, :hospital, :equipment_service_payments, :payment_histories, :patient_receipts)
            sort_key = params[:sortKey]
            if params[:status].present?
              # enum status: { using: 0, pause: 1, suspended: 2 }
              @query = @query.where(status: params[:status])
              if params[:care_plan_date].present?
                @query = @query.includes(:schedule_dates).where(schedule_dates: { date: params[:care_plan_date] })
              end
            end
            return present :data, @query.includes(:schedule_dates)
                                        .where(schedule_dates: { date: convert_date(params[:schedule_date]), nurse_id: nil }) if params[:get_all] && params[:schedule_date].present?
            return present :data, @query.default_order.select(:id, :family_name, :name_kana) if params[:get_all]

            @q = @query.ransack(family_name_or_name_kana_cont: params[:fullname])
            page = (params[:page].presence || 1).to_i
            @patients = @q.result.by_patient_code_asc.page(page).per(params[:per]) if sort_key.blank?
            if sort_key.present?
              sort_key = 'name_kana' if sort_key == 'name'
              sort_key = 'district' if sort_key == 'residence'
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if sort_key == 'age'
                sort_key = 'birth_date'
                sort_order = sort_order == 'ASC' ? 'DESC' : 'ASC'
              end
              @patients = if sort_key == 'name_kana'
                            sorted = @q.result.sort_by(&:name_kana)
                            sorted.reverse! if sort_order != 'ASC'
                            sorted = Kaminari.paginate_array(sorted)
                            sorted
                          elsif %w(payment_history_status payment_history_expected_date payment_history_actual_date).include?(sort_key) # payment_histories index
                            @q.result.order_by_payment_history(sort_key, sort_order, params[:year_month_payment])
                          elsif %w(care_level insurance_number insurance_period responsible_policy_management).include?(sort_key)
                            sort_key = 'start_insurance' if sort_key == 'insurance_period'
                            @q.result.left_outer_joins(:insurance_cards)
                              .select('patients.*, MAX(insurance_cards.id) AS max_insurance_card_id')
                              .group('patients.id')
                              .order("MAX(insurance_cards.#{sort_key}) #{sort_order} NULLS LAST")
                          else
                            @q.result.order(sort_key => sort_order)
                          end.page(page).per(params[:per])
            end
            serialized_patients = @patients.map do |patient|
              PatientSerializer.new(patient, { year_month_payment: params[:year_month_payment] }).as_json
            end
            present :page, page
            present :total_items, @patients.total_count
            present :total_pages, @patients.total_pages
            present :patients, serialized_patients
          end

          desc 'get api/v1/staff/patients/all'
          params do
            optional :fullname, type: String
          end
          get '/all' do
            @query = Patient.using
            @q = @query.ransack(family_name_or_name_kana_cont: params[:fullname])
            @patients = @q.result.default_order
            return [] if @patients.blank?

            serialized_patients = @patients.map do |patient|
              PatientSerializer.new(patient).as_json
            end
            present :patients, serialized_patients
          end

          desc 'get api/v1/staff/patients/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              @patient = Patient.find(params[:id])
              present @patient
            end
          end
        end
      end
    end
  end
end
