module V1
  module Staff
    class RoutineSerializer < ActiveModel::Serializer
      attributes :id,
                 :date

    end
  end
end
