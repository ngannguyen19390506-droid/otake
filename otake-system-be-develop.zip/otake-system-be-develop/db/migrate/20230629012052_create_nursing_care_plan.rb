class CreateNursingCarePlan < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_care_plans do |t|
      t.references :patient,                     null: false, foreign_key: true
      t.references :service,                     null: false, foreign_key: true
      t.string     :comprehensive_aid_policy,    null: false
      t.string     :individual_family_intention, null: false
      t.string     :aid_purpose,                 null: false
      t.date       :start_long_term,             null: false
      t.date       :end_long_term,               null: false
      t.string     :long_term_goal_one,          null: false
      t.string     :long_term_goal_two,          null: false
      t.string     :long_term_goal_three,        null: false
      t.string     :long_term_goal_four,         null: false
      t.date       :start_short_term,            null: false
      t.date       :end_short_term,              null: false
      t.string     :short_term_goal_one,         null: false
      t.string     :short_term_goal_two,         null: false
      t.string     :short_term_goal_three,       null: false
      t.string     :short_term_goal_four,        null: false

      t.timestamps
    end
  end
end
