# == Schema Information
#
# Table name: equipment_service_usages
#
#  id                           :bigint           not null, primary key
#  date                         :date             not null
#  quantity                     :float            not null
#  created_at                   :datetime         not null
#  updated_at                   :datetime         not null
#  equipment_service_payment_id :bigint           not null
#
# Indexes
#
#  index_equipment_service_usages_on_equipment_service_payment_id  (equipment_service_payment_id)
#
class EquipmentServiceUsage < ApplicationRecord
  include ApiCommon

  belongs_to :equipment_service_payment

  validates :date, :quantity, presence: true
end
