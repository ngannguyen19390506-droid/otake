module V1
  module Admin
    class NotificationSerializer < ActiveModel::Serializer
      attributes :id, :poster, :content, :created_at, :deployment_date,
                 :sender_id, :sender_type, :unread_count
      belongs_to :patient, foreign_key: :patient_id, optional: true
      belongs_to :notification_category, foreign_key: :notification_category_id, optional: true

      def created_at
        object.created_at.strftime('%Y/%m/%d %H:%M')
      end

      def deployment_date
        object.deployment_date&.strftime('%Y/%m/%d')
      end

      def view_count
        object.notification_view_logs.only_staffs.count
      end

      def unread_count
        uids = object.notification_view_logs
        NursingStaff.count + UserAdmin.count - uids.count
      end
    end
  end
end