class CreatePatientReceipts < ActiveRecord::Migration[7.0]
  def change
    create_table :patient_receipts do |t|
      t.integer :patient_id, null: false
      t.string :year_month, null: false
      t.boolean :registered, default: false, null: false

      t.timestamps
    end
  end
end
