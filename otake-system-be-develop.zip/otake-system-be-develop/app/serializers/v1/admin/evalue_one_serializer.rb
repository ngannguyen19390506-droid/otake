module V1
  module Admin
    class EvalueOneSerializer < ActiveModel::Serializer
      attributes :id,
                 :patient_id,
                 :daily_rhythm_of_life,
                 :life_history,
                 :daily_life_challenges,
                 :note,
                 :character,
                 :hobbies,
                 :family_circumstances,
                 :special_notes,
                 :family_interview,
                 :family_interview,
                 :personal_interview,
                 :created_date
    end
  end
end
