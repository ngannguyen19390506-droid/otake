module V1
  module Admin
    module CarePlans
      class CreateNursingCarePlan < CarePlanBaseOperation
        def call(params_nursing_care_plan, schedules, improvement_nursing_care_plans, current_user_id, patient)
          begin
            ActiveRecord::Base.transaction do
              long_terms = params_nursing_care_plan[:long_terms]
              short_terms = params_nursing_care_plan[:short_terms]
              nursing_care_plan = NursingCarePlan.new(params_nursing_care_plan.except(:long_terms, :short_terms, :is_clone))
              if nursing_care_plan.save
                care_plan_type = 'NursingCarePlan'
                patient_type = 'normal'

                if long_terms.present?
                  nursing_care_plan.nursing_care_plan_terms.long_term&.destroy_all
                  long_terms.each do |term|
                    nursing_care_plan.nursing_care_plan_terms.long_term.create(term_goal: term)
                  end
                end

                if short_terms.present?
                  nursing_care_plan.nursing_care_plan_terms.short_term&.destroy_all
                  short_terms.each do |term|
                    nursing_care_plan.nursing_care_plan_terms.short_term.create(term_goal: term)
                  end
                end

                # TODO: Update logic later
                schedules.each do |schedule_params|
                  service = Service.find_by(id: schedule_params[:service_id], patient_type: patient_type)
                  return Failure({ 'service_id': I18n.t('activerecord.errors.messages.not_found') }) if service.blank?

                  service_type = ServiceType.find_by(id: schedule_params[:service_type_id])
                  return Failure({ 'service_type_id': I18n.t('activerecord.errors.messages.not_found') }) if service_type.blank?
                  schedule = create_schedule(nursing_care_plan, schedule_params, care_plan_type)

                  create_schedule_routine(schedule&.id, schedule_params)
                end
                treatments_found = create_improvement_nursing_care_plans(nursing_care_plan.id, improvement_nursing_care_plans,
                                                                         care_plan_type, patient_type, nil)
                return Failure({ 'message': I18n.t('errors.messages.not_found') }) unless treatments_found

                Success(nursing_care_plan)
              else
                Failure(nursing_care_plan.error_messages)
              end
            end
          rescue StandardError => e
            Failure(e.message)
          end
        end
      end
    end
  end
end
