module V1
  module AdminHomeSystem
    class ScheduleDateAtHomeSerializer < ActiveModel::Serializer
      attributes :id,
                 :date,
                 :start_time,
                 :end_time
    end
  end
end
