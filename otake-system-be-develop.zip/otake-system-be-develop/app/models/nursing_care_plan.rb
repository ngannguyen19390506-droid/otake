# == Schema Information
#
# Table name: nursing_care_plans
#
#  id                          :bigint           not null, primary key
#  aid_purpose                 :text
#  comprehensive_aid_policy    :text
#  end_long_term               :date
#  end_short_term              :date
#  individual_family_intention :text
#  long_term_goal_four         :text
#  long_term_goal_one          :text
#  long_term_goal_three        :text
#  long_term_goal_two          :text
#  note                        :text
#  remarks                     :text
#  short_term_goal_four        :string
#  short_term_goal_one         :text
#  short_term_goal_three       :text
#  short_term_goal_two         :text
#  start_long_term             :date
#  start_short_term            :date
#  year_month                  :string
#  created_at                  :datetime         not null
#  updated_at                  :datetime         not null
#  patient_id                  :bigint           not null
#
# Indexes
#
#  index_nursing_care_plans_on_patient_id  (patient_id)
#
class NursingCarePlan < ApplicationRecord
  include ApiCommon
  belongs_to :patient

  has_many :nursing_care_plan_services, foreign_key: :nursing_care_id, dependent: :destroy
  has_many :services, through: :nursing_care_plan_services
  has_many :nursing_care_plan_service_types, foreign_key: :nursing_care_id, dependent: :destroy
  has_many :service_types, through: :nursing_care_plan_service_types
  has_many :schedules, as: :care_plan, dependent: :destroy
  has_many :schedule_dates, through: :schedules, source: :schedule_dates
  has_many :improvement_nursing_care_plans, as: :care_plan
  has_many :treatment_improvements, through: :improvement_nursing_care_plans
  has_many :change_histories, as: :changeable, dependent: :destroy
  has_many :nursing_care_plan_terms, dependent: :destroy

  validates :year_month, presence: true, format: { with: YEAR_MONTH, message: I18n.t('errors.messages.year_month_format_invalid') }

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_changes_without_timestamps(previous_changes)
      term_changes = all_changes.select do |changed_attribute, _|
        %w[start_long_term end_long_term start_short_term end_short_term].include?(changed_attribute)
      end

      other_changes = all_changes.except(*term_changes.keys)
      if term_changes.present?
        term_changes = process_term_changes(term_changes, user_admin_id, 'start_long_term', 'end_long_term')
        term_changes = process_term_changes(term_changes, user_admin_id, 'start_short_term', 'end_short_term')
        term_changes.each do |changed_attribute, (before_value, after_value)|
          text_description = I18n.t("attribute_description.nursing_care_plan.#{changed_attribute}")
          if changed_attribute == 'start_long_term'
            before_value = "#{before_value} ~ #{end_long_term}"
            after_value = "#{after_value} ~ #{end_long_term}"
          end

          if changed_attribute == 'end_long_term'
            before_value = "#{start_long_term} ~ #{before_value}"
            after_value = "#{start_long_term} ~ #{after_value}"
          end

          if changed_attribute == 'start_short_term'
            before_value = "#{before_value} ~ #{end_short_term}"
            after_value = "#{after_value} ~ #{end_short_term}"
          end

          if changed_attribute == 'end_short_term'
            before_value = "#{start_short_term} ~ #{before_value}"
            after_value = "#{start_short_term} ~ #{after_value}"
          end

          create_change_history(user_admin_id, text_description, before_value, after_value)
        end
      end

      other_changes.each do |changed_attribute, (before_value, after_value)|
        text_description = I18n.t("attribute_description.nursing_care_plan.#{changed_attribute}")

        create_change_history(user_admin_id, text_description, before_value, after_value)
      end
    rescue StandardError => e
      e
    end
  end

  def process_term_changes(term_changes, user_admin_id, start_key, end_key)
    if term_changes.keys.include?(start_key) && term_changes.keys.include?(end_key)
      before_value = "#{term_changes[start_key][0]} ~ #{term_changes[end_key][0]}"
      after_value = "#{term_changes[start_key][1]} ~ #{term_changes[end_key][1]}"
      text_description = I18n.t("attribute_description.nursing_care_plan.#{start_key}")
      create_change_history(user_admin_id, text_description, before_value, after_value)
      term_changes = term_changes.except(start_key, end_key)
    end

    term_changes
  end
end
