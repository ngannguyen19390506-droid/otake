module V1
  module Admin
    class ShiftManagementSerializer < ActiveModel::Serializer
      attributes :id,
                 :shift_name,
                 :shift_date,
                 :start_time,
                 :end_time

      has_many :patients, serializer: V1::Admin::PatientSerializer
      has_many :services, serializer: V1::Admin::ServiceSerializer
      has_many :service_types, serializer: V1::Admin::ServiceTypeSerializer
      has_many :nurses, serializer: V1::Admin::NursingStaffSerializer

      def services
        object.services
      end

      def service_types
        object.service_types
      end

      def patients
        object.patients
      end

      def nurses
        object.nurses
      end
    end
  end
end
