# == Schema Information
#
# Table name: nursing_care_plan_services
#
#  id              :bigint           not null, primary key
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  nursing_care_id :bigint           not null
#  service_id      :bigint           not null
#
# Indexes
#
#  index_nursing_care_plan_services_on_nursing_care_id  (nursing_care_id)
#  index_nursing_care_plan_services_on_service_id       (service_id)
#
# Foreign Keys
#
#  fk_rails_...  (nursing_care_id => nursing_care_plans.id)
#  fk_rails_...  (service_id => services.id)
#
class NursingCarePlanService < ApplicationRecord
  belongs_to :service
  belongs_to :nursing_care, class_name: 'NursingCarePlan'
end
