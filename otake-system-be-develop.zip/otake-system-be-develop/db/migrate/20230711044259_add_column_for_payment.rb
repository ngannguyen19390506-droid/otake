class AddColumnForPayment < ActiveRecord::Migration[7.0]
  def change
    add_column :payments, :ward, :string

    rename_column :payments, :state, :district
    rename_column :payments, :house_no, :building_name
    rename_column :payments, :payment_address, :payer
    rename_column :payments, :zipcode, :postal_code


    change_column :payments, :account_number_kana, :integer, null: true
    change_column :payments, :city, :string, null: true
    change_column :payments, :street, :string, null: true
    change_column :payments, :district, :string, null: true
    change_column :payments, :building_name, :string, null: true
    change_column :payments, :account_number, :string, null: false


    change_column :payments, :payment_method, :integer, default: 3
    change_column :payments, :account_type, :integer, default: 1
    change_column :payments, :payer, :string, default: 'other'


    remove_column :payments, :amount

  end
end
