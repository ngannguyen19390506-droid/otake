# == Schema Information
#
# Table name: monthly_holidays
#
#  id                 :bigint           not null, primary key
#  confirmed_by_admin :boolean          default(FALSE)
#  confirmed_by_staff :boolean          default(FALSE)
#  create_type        :integer
#  status             :integer          not null
#  year_month         :string           not null
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#  nurse_id           :bigint           not null
#
# Indexes
#
#  index_monthly_holidays_on_nurse_id  (nurse_id)
#
# Foreign Keys
#
#  fk_rails_...  (nurse_id => nursing_staffs.id)
#
class MonthlyHoliday < ApplicationRecord
  include ApiCommon

  has_many :holidays, dependent: :destroy

  belongs_to :nurse, class_name: 'NursingStaff'
  enum create_type: { staff: 1, admin: 2 }
  enum status: { initial: -1, draft: 0, sent: 1, approved: 2 }
end
