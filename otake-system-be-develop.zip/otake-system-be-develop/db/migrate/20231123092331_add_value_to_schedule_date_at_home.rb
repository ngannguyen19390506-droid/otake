class AddValueToScheduleDateAtHome < ActiveRecord::Migration[7.0]
  def change
    add_column :schedule_date_at_homes, :value, :string
  end
end
