module V1
  module Admin
    class ImprovementNursingCarePlanSerializer < ActiveModel::Serializer
      attributes :id, :treatment_improvement_id
    end
  end
end
