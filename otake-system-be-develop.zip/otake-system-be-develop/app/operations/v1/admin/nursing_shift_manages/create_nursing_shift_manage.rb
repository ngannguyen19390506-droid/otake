module V1
  module Admin
    module NursingShiftManages
      class CreateNursingShiftManage < ::ApplicationOperation
        def call(params)
          start_time, end_time, is_holiday, shift_registration_id = get_start_and_end_time(params)
          converted_dates = params[:dates].map { |date| convert_date(date) }
          return Failure({ message: I18n.t('errors.messages.invalid') }) if invalid_time_rage?(start_time, end_time)

          dup_date = dup_date(converted_dates)
          return Failure({ message: I18n.t('nursing_shift_manage.error.duplicate_date', date: dup_date) }) if dup_date.present?

          beginning_of_next_month = Date.current.next_month.at_beginning_of_month
          end_of_next_month = Date.current.next_month.end_of_month
          invalid_dates = converted_dates.select { |date| (beginning_of_next_month..end_of_next_month).exclude?(date)}
          if invalid_dates.present?
            return Failure({ message: I18n.t('errors.messages.invalid_dates') })
          end

          year_month = beginning_of_next_month.strftime('%Y/%m')
          holiday = find_holiday(params[:nurse_id], converted_dates, year_month)
          if holiday.present?
            return Failure({ message: I18n.t('nursing_shift_manage.error.duplicate_holiday',
                                          date: holiday.pluck(:date).uniq.join(','),
                                          start_time: start_time,
                                          end_time: end_time) })
          end

          dup_record = find_dup_record(params[:nurse_id], converted_dates, start_time, end_time)
          if dup_record.present?
            return Failure({ message: I18n.t('nursing_shift_manage.error.overlap_date',
                                          date: dup_record.pluck(:shift_date).uniq.join(','),
                                          start_time: start_time,
                                          end_time: end_time) })
          end
          staff = NursingStaff.find_by(id: params[:nurse_id])
          return Failure({ message: I18n.t('nursing_shift_manage.error.not_found_staff') }) if staff.blank?

          if is_holiday
            create_holidays(converted_dates, staff, start_time, end_time, year_month, shift_registration_id)
          else
            create_shift(converted_dates, params[:nurse_id], start_time, end_time, shift_registration_id)
          end
          Success(I18n.t('nursing_shift_manage.message.add.success'))
        rescue StandardError => e
          Failure(e.message)
        end

        private

        def dup_date(dates)
          dates.detect { |e| dates.count(e) > 1 }
        end

        def find_holiday(nurse_id, dates, year_month)
          staff = NursingStaff.find(nurse_id)
          monthly_holiday = staff.monthly_holidays.find_by(year_month: year_month)
          monthly_holiday&.holidays&.where(date: dates, create_type: 'admin')
        end

        # Cannot create a shift for nurse when overlap other shift
        def find_dup_record(nurse_id, dates, start_time, end_time)
          ShiftManagement.joins(:nursing_shift_manages).where(shift_date: dates)
                         .where('nursing_shift_manages.nurse_id = ?', nurse_id)
                         .where('(start_time >= :start_time AND start_time < :end_time)
                               OR (end_time > :start_time AND end_time <= :end_time)
                               OR (start_time < :start_time AND end_time > :end_time)',
                               { start_time: start_time, end_time: end_time })
        end

        def create_shift(dates, nurse_id, start_time, end_time, shift_registration_id)
          ActiveRecord::Base.transaction do
            dates.each do |date|
              sm = ShiftManagement.create!(start_time: start_time,
                                           end_time: end_time,
                                           shift_date: date,
                                           shift_registration_id: shift_registration_id)

              NursingShiftManage.create!(nurse_id: nurse_id, shift_id: sm.id)
            end
          end
        rescue StandardError => e
          e
        end

        def get_start_and_end_time(params)
          shift_registration = ShiftRegistration.find_by(id: params[:shift_registration_id])
          if shift_registration
            start_time = shift_registration.start_time
            end_time = shift_registration.end_time
            is_holiday = shift_registration.name == '希望休' || shift_registration.name == '休み'
            shift_registration_id = shift_registration.id
          else
            start_time = params[:start_time]
            end_time = params[:end_time]
            is_holiday = false
            shift_registration_id = nil
          end

          [start_time, end_time, is_holiday, shift_registration_id]
        end

        def create_holidays(dates, staff, start_time, end_time, year_month, shift_registration_id)
          ActiveRecord::Base.transaction do
            name = ShiftRegistration.find(shift_registration_id)&.name
            monthly_holiday = staff.monthly_holidays.find_or_create_by(year_month: year_month)
            dates.each do |date|
              monthly_holiday.holidays.create(date: date, create_type: 'admin', status: 'initial', name: name)
            end
          end
        rescue StandardError => e
          e
        end
      end
    end
  end
end
