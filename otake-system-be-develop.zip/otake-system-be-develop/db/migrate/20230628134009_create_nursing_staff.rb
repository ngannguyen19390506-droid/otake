class CreateNursingStaff < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_staffs do |t|
      t.string     :name,             null: false
      t.string     :desk_phone,       null: false
      t.string     :mobile_phone,     null: false
      t.string     :password,         null: false
      t.date       :birth_date,       null: false
      t.integer    :age,              null: false
      t.integer    :sex,              null: false, limit: 1
      t.string     :family_name,      null: false
      t.string     :last_name,        null: false
      t.string     :first_name,       null: false
      t.string     :name_kana,        null: false
      t.string     :last_name_kana,   null: false
      t.string     :first_name_kana,  null: false
      t.string     :zipcode,          null: false
      t.string     :state,            null: false
      t.string     :city,             null: false
      t.string     :street,           null: false
      t.string     :house_no,         null: false
      t.string     :nurse_code,       null: false

      t.timestamps
    end
  end
end
