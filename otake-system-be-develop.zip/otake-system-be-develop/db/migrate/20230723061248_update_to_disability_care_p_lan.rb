class UpdateToDisabilityCarePLan < ActiveRecord::Migration[7.0]
  def change
    # Change column types to text
    change_column :disability_care_plans, :comprehensive_aid_policy, :text, null: true
    change_column :disability_care_plans, :individual_family_intention, :text, null: true
    change_column :disability_care_plans, :aid_purpose, :text, null: true

    # Remove service_id column
    remove_column :disability_care_plans, :service_id

    # Add remarks column
    add_column :disability_care_plans, :remarks, :text

  end
end
