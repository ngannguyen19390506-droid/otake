# == Schema Information
#
# Table name: recipients
#
#  id                         :bigint           not null, primary key
#  applicable_start_date      :date
#  business_code              :text
#  contract_allocation_amount :text
#  contract_date              :date
#  monthly_cost_limit         :text
#  recipient_code             :text
#  service_content            :text
#  service_end_date           :date
#  user_burden_percentage     :text
#  created_at                 :datetime         not null
#  updated_at                 :datetime         not null
#  patient_id                 :integer
#
# Indexes
#
#  index_recipients_on_id  (id)
#
class Recipient < ApplicationRecord
  belongs_to :patient

  validates :recipient_code, :service_content, :contract_allocation_amount,
            :contract_date, :service_end_date, :applicable_start_date, :user_burden_percentage,
            :monthly_cost_limit, presence: true
end
