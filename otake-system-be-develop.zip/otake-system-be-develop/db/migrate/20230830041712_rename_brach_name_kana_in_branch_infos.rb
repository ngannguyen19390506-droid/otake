class RenameBrachNameKanaInBranchInfos < ActiveRecord::Migration[7.0]
  def change
    rename_column :branch_infos, :brach_name_kana, :branch_name_kana
  end
end
