module V1
  module AdminHomeSystem
    class ScheduleDateAtHomeApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resources :schedule_date_at_homes do
          desc 'GET /api/v1/admin_home_system/schedule_date_at_homes'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :date, type: Date, message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            serialized_service_home_systems = ServiceHomeSystem.order(:position).map do |service|
              ServiceHomeSystemSerializer.new(service, { patient: patient, date: params[:date] }).as_json
            end
            schedule_date_at_homes = patient.schedule_date_at_homes.where(date: params[:date], schedule_homeable_type: "ScheduleMemoAtHome")
            schedule_date_at_homes = schedule_date_at_homes.map{|schedule| schedule.attributes.merge!(value: schedule&.schedule_homeable&.content)}
            schedule_memos = [{ display_name: '申 し 送 り', selection_method: 'free_input', type: 'memo', schedules: schedule_date_at_homes }]
            present :data, schedule_memos.concat(serialized_service_home_systems) << { patient: patient }
          end

          put 'PUT /api/v1/admin_home_system/schedule_date_at_homes'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
            requires :value, type: String, message: I18n.t('error.validate.blank')
          end
          put do
            schedule = ScheduleDateAtHome.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule.blank?

            if schedule.schedule_homeable_type == 'ScheduleAtHome'
              service_home_system = schedule.schedule_homeable.service_home_system
              if service_home_system.selection_method == 'dropdown' && service_home_system.dropdown_values&.exclude?(params[:value]) ||
                service_home_system.selection_method == 'checkbox' && ['true', 'false'].exclude?(params[:value])
                return error!({ 'messages': I18n.t('errors.messages.value_invalid') }, UNPROCESSABLE_ENTITY)
              end
            end

            if schedule.update(value: params[:value])
              if schedule.schedule_homeable.class.to_s == 'ScheduleMemoAtHome'
                schedule.schedule_homeable.update(content: params[:value])
              end
              { success: I18n.t('success.messages.updated') }
            else
              error!(service_home_system.error_messages, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end
    end
  end
end
