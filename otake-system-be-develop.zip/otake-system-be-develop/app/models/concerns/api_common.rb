module ApiCommon
  extend ActiveSupport::Concern

  included do
    scope :default_order, -> { order(created_at: :desc) }
  end

  def generate_jwt(code, role)
    payload = {
      id: id,
      code: code,
      exp: 4.hours.from_now.to_i,
      role: role
    }
    access_token = JWT.encode(payload, ENV['SECRET_KEY_BASE'] || Rails.application.secrets.secret_key_base)
    authentication_token = authentication_tokens.create
    authentication_token.digest!(access_token)
    access_token
  end

  def password=(new_password)
    @password = new_password
    self.encrypted_password = BCrypt::Password.create(new_password)
  end

  def password_matches?(password)
    BCrypt::Password.new(encrypted_password) == password
  end

  def error_messages
    errors.messages.transform_values { |value| value.join(',') }
  end

  def password_valid?(password)
    errors.add(:password, I18n.t('patient.error.validate.blank')) if password.blank?
    # errors.add(:password, I18n.t('errors.messages.invalid_password')) unless password.match(PASSWORD_REGEX)
  end

  def update_family_name_and_name_kana(params_object)
    self.family_name = "#{params_object[:last_name]} #{params_object[:first_name]}"
    self.name_kana = "#{params_object[:last_name_kana]} #{params_object[:first_name_kana]}"
  end

  def age
    now = Time.now.utc.to_date
    birth_date = self.birth_date.to_date
    now.year - birth_date.year - (birth_date.to_date.change(year: now.year) > now ? 1 : 0)
  end

  def extract_contact_relatives_changes(contact_relatives)
    contact_relatives.map { |contact_relative| extract_changes_without_timestamps(contact_relative.previous_changes) }
  end

  def process_contact_relatives_changes(before_value, after_value, user_admin_id)
    process_contact_relative_changes(before_value, 'first', user_admin_id) if before_value.present?
    process_contact_relative_changes(after_value, 'second', user_admin_id) if after_value.present?
  end

  def process_contact_relative_changes(contact_changes, index, user_admin_id)
    contact_changes.each do |attr, (before_contact_value, after_contact_value)|
      contact_text_description = attribute_description("contact_relatives.#{index}.#{attr}")
      create_change_history(user_admin_id, contact_text_description, before_contact_value, after_contact_value)
    end
  end

  def extract_changes_without_timestamps(changes)
    changes.reject { |attr, _| %w[created_at updated_at bank_info_id branch_info_id frequency].include?(attr) }
  end

  def create_change_history(user_admin_id, text_description, before_value, after_value)
    ChangeHistory.create(
      user_admin_id: user_admin_id,
      changeable_id: id,
      changeable_type: self.class.name,
      changed_attribute: text_description,
      before_change: before_value,
      after_change: after_value,
      date: Time.zone.today
    )
  end

  def validate_address_with_zipcode
    code = zipcode.gsub('-', '')
    post_code = PostCode.find_by(code: code)
    if post_code.blank? || post_code.district_name != district || post_code.city_name != city || post_code.address_name != street
      errors.add(:message, I18n.t('activerecord.errors.messages.address_zipcode_mismatch'))
    end
  end
end
