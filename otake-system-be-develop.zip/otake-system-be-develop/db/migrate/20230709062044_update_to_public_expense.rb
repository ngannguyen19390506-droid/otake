class UpdateToPublicExpense < ActiveRecord::Migration[7.0]
  def change
    remove_column :public_expenses, :comprehensive_aid_policy
  end
end
