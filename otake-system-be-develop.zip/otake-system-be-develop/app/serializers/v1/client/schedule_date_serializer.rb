module V1
  module Client
    class ScheduleDateSerializer < ActiveModel::Serializer
      attributes :id, :date, :start_time, :end_time, :nurse_id
    end
  end
end
