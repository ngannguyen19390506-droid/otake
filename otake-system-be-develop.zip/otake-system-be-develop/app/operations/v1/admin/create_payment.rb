module V1
  module Admin
    class CreatePayment < ::ApplicationOperation
      def call(params)
        patient = Patient.find_by(id: params[:patient_id])
        return Failure({ 'message': I18n.t('payment.error.patient.not_found') }) if patient.blank?
        return Failure({ 'messages': I18n.t('errors.messages.already_exists') }) if patient.payment.present?

        payment = create_payment_info(params, patient)
        if payment.valid?
          Success(payment)
        else
          Failure(payment.errors.messages.transform_values { |value| value.join(',') })
        end
      end

      private

      def create_payment_info(params, patient)
        Payment.create({
                         patient_id: patient.id,
                         account_name_kana: params[:account_name_kana],
                         customer_number: params[:customer_number],
                         account_number: params[:account_number],
                         account_type: params[:account_type],
                         bank_name: params[:bank_name],
                         branch_name: params[:branch_name],
                         payment_method: params[:payment_method],
                         payer: params[:payer],
                         zipcode: params[:zipcode],
                         district: params[:district],
                         city: params[:city],
                         street: params[:street],
                         building_name: params[:building_name],
                         bank_info_id: params[:bank_info_id],
                         branch_info_id: params[:branch_info_id]
                       })
      end
    end
  end
end
