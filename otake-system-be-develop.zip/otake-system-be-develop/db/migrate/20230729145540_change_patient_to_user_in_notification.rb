class ChangePatientToUserInNotification < ActiveRecord::Migration[7.0]
  def change
    remove_foreign_key :notifications, column: :patient_id
    remove_reference   :notifications, :patient
    add_reference :notifications, :user, null: false, foreign_key: true
  end
end
