class CreatePaymentHistory < ActiveRecord::Migration[7.0]
  def change
    create_table :payment_histories do |t|
      t.references :patient,                null: false, foreign_key: true
      t.date       :expected_date, null: false
      t.date       :actual_date, null: false
      t.string     :year_month, null: false

      t.timestamps
    end
  end
end
