module V1
  module StaffHomeSystem
    class UserHomeSystemApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :staff_home_system do
        resources :user_home_system do
          desc 'GET api/v1/staff_home_system/user_home_system',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
          end
          get do
            page = (params[:page].presence || 1).to_i
            objects = UserHomeSystem.where.not(id: @current_user.id).by_created_at_desc.page(page).per(params[:per])
            serialized_objects = objects.map do |notification|
              UserHomeSystemSerializer.new(notification).as_json
            end

            present :objects, serialized_objects
          end
        end
      end
    end
  end
end
