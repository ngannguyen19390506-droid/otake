module V1
  module Staff
    class TreatmentImprovementSerializer < ActiveModel::Serializer
      attributes :id, :name, :rate
    end
  end
end
