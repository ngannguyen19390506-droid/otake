module V1
  module Admin
    class SessionApi < V1::AppApi
      namespace :admin do
        desc 'POST api/v1/admin/login'
        params do
          requires :user_code, type: String, message: I18n.t('login.validate.blank')
          requires :password, type: String, message: I18n.t('login.validate.blank')
        end
        post 'login' do
          begin
            return error!(I18n.t('login.validate.blank'), UNAUTHORIZED) if params[:user_code].blank? || params[:password].blank?

            user = UserAdmin.find_by(user_code: params[:user_code])
            return error!(I18n.t('login.code.invalid'), UNAUTHORIZED) if user.blank?

            if user&.password_matches?(params[:password])
              token = user.generate_jwt(user.user_code, :admin)
              { access_token: token, user_name: user.user_name }
            else
              error!({ errors: I18n.t('login.code.invalid') }, UNAUTHORIZED)
            end
          rescue StandardError => e
            error!({ errors: e.message }, UNAUTHORIZED)
          end
        end
      end
    end
  end
end
