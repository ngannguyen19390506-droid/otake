module V1
  module StaffHomeSystem
    class EquipmentHomeSystemSerializer < ActiveModel::Serializer
      attributes :id,
                 :unit_price,
                 :year_month,
                 :patient_id,
                 :equipment_service_id

      # belongs_to :equipment_service, serializer: EquipmentServiceSerializer
      has_many :equipment_usage_home_systems, serializer: EquipmentUsageHomeSystemSerializer
    end
  end
end
