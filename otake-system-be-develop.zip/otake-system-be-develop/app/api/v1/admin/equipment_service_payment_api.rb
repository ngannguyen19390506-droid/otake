module V1
  module Admin
    class EquipmentServicePaymentApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :equipment_service_payments do
          desc 'POST api/v1/admin/equipment_service_payments'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :registered, type: Boolean, message: I18n.t('error.validate.blank')
            requires :category, type: String, values: EquipmentServicePayment.categories.keys,
                     message: I18n.t('error.validate.blank')
            requires :equipment_service_payments, type: Array do
              requires :equipment_service_id, type: Integer, message: I18n.t('error.validate.blank')
              requires :equipment_service_usages, type: Array do
                requires :date, type: Date, message: I18n.t('error.validate.blank')
                requires :change, type: Float, message: I18n.t('error.validate.blank')
              end
              optional :unit_price, type: Integer
              optional :remaining_stock_quantity, type: Integer
            end
          end
          post do
            patient_id = params[:patient_id]
            year_month = params[:year_month]
            registered = params[:registered]
            category = params[:category]
            patient = Patient.find_by(id: patient_id)
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            existing_payment = patient.equipment_service_payments.find_by(year_month: year_month, category: category)
            if existing_payment&.registered
              return error!({ 'messages': I18n.t('errors.messages.already_registered') }, UNPROCESSABLE_ENTITY)
            end

            ActiveRecord::Base.transaction do
              if params[:equipment_service_payments].blank? && registered
                EquipmentServicePayment.create(
                  patient_id: patient_id,
                  year_month: year_month,
                  registered: registered,
                  category: category,
                )
              end
              equipment_service_payments = patient.equipment_service_payments.where(year_month: year_month, category: category)
              equipment_service_payments.update_all(registered: registered) if equipment_service_payments.present?
              params[:equipment_service_payments].each do |payment_data|
                equipment_service = EquipmentService.find_by(id: payment_data[:equipment_service_id])
                if equipment_service.category != category
                  return error!({ 'messages': I18n.t('errors.messages.invalid_category') }, UNPROCESSABLE_ENTITY)
                end
                stock_quantity_update = if equipment_service.stock_quantity != NOT_MANAGE
                                          (equipment_service.stock_quantity.to_f + payment_data[:equipment_service_usages].sum { |usage| usage[:quantity].to_f - usage[:change].to_f }).round(1)
                                        else
                                          NOT_MANAGE
                                        end
                if stock_quantity_update != NOT_MANAGE && stock_quantity_update < 0
                  return error!({ 'messages': I18n.t('errors.messages.invalid_stock_quantity') }, UNPROCESSABLE_ENTITY)
                end

                if equipment_service.update(stock_quantity: stock_quantity_update)
                  equipment_service_payment = equipment_service_payments.find_by(equipment_service_id: payment_data[:equipment_service_id])
                  if equipment_service_payment.present?
                    if equipment_service_payment.update!(remaining_stock_quantity: stock_quantity_update)
                      payment_data[:equipment_service_usages].each do |params_equipment_service_usage|
                        equipment_service_usage = equipment_service_payment.equipment_service_usages.find_by(date: params_equipment_service_usage[:date])
                        if equipment_service_usage.present?
                          equipment_service_usage.update!(quantity: params_equipment_service_usage[:change])
                        else
                          create_equipment_service_usage(equipment_service_payment, params_equipment_service_usage[:date], params_equipment_service_usage[:change])
                        end
                      end
                    else
                      error!(equipment_service_payment.error_messages, UNPROCESSABLE_ENTITY)
                    end
                  else
                    equipment_service_payment = EquipmentServicePayment.new(
                      patient_id: patient_id,
                      year_month: year_month,
                      registered: registered,
                      category: category,
                      equipment_service_id: payment_data[:equipment_service_id],
                      remaining_stock_quantity: stock_quantity_update,
                      unit_price: payment_data[:unit_price]
                    )
                    if equipment_service_payment.save
                      payment_data[:equipment_service_usages].each do |equipment_service_usage|

                        create_equipment_service_usage(equipment_service_payment, equipment_service_usage[:date], equipment_service_usage[:change])
                      end
                    else
                      error!(equipment_service_payment.error_messages, UNPROCESSABLE_ENTITY)
                    end
                  end
                else
                  error!({ message: equipment_service.error_messages.values.join(', ') }, UNPROCESSABLE_ENTITY)
                end
              end

              existing_payment.present? ? { success: I18n.t('success.messages.updated') } : { success: I18n.t('success.messages.added') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/equipment_service_payments',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :category, type: String, values: EquipmentServicePayment.categories.keys,
                     message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @equipment_service_payments = patient.equipment_service_payments.where(year_month: params[:year_month],
                                                                                   category: params[:category])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @equipment_service_payments.blank?

            serialized_equipment_service_payments = @equipment_service_payments.map do |equipment_service_payment|
              EquipmentServicePaymentSerializer.new(equipment_service_payment).as_json
            end

            present :serialized_equipment_service_payments, serialized_equipment_service_payments
          end

          desc 'POST api/v1/admin/equipment_service_payments/cancel-payment',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :category, type: String, values: EquipmentServicePayment.categories.keys,
                     message: I18n.t('error.validate.blank')
          end
          post '/cancel-payment' do
            EquipmentServicePayment.where(
              patient_id: params[:patient_id],
              year_month: params[:year_month],
              category: params[:category]
            )&.update_all(registered: false)

            { success: I18n.t('success.messages.updated') }
          end
        end
      end

      helpers do
        def create_equipment_service_usage(equipment_service_payment, date, quantity)
          equipment_service_payment.equipment_service_usages.create!(
            date: date,
            quantity: quantity
          )
        end
      end
    end
  end
end
