# == Schema Information
#
# Table name: care_plan_at_homes
#
#  id         :bigint           not null, primary key
#  year_month :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  patient_id :bigint           not null
#
# Indexes
#
#  index_care_plan_at_homes_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class CarePlanAtHome < ApplicationRecord
  include ApiCommon

  has_many :schedule_at_homes, dependent: :destroy
  has_many :schedule_memo_at_homes, dependent: :destroy
  has_many :service_home_systems, through: :schedule_at_homes
  has_many :schedule_date_at_homes, through: :schedule_at_homes
  has_many :schedule_date_at_homes, through: :schedule_memo_at_homes
  has_many :daily_healths, dependent: :destroy

  belongs_to :patient

  validates :year_month, format: { with: YEAR_MONTH, message: I18n.t('errors.messages.year_month_format_invalid') }
end
