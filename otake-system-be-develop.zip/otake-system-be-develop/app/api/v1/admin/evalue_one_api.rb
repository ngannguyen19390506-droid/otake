module V1
  module Admin
    class EvalueOneApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :evalue_ones do
          desc 'POST api/v1/admin/evalue_ones'
          params do
            requires :patient_id, type: Integer, message: I18n.t('evalue_one.error.validate.blank')
            optional :daily_life_challenges, type: String
            optional :daily_rhythm_of_life, type: String
            optional :life_history, type: String
            optional :daily_life_challenges, type: String
            optional :note, type: String
            optional :character, type: String
            optional :hobbies, type: String
            optional :family_circumstances, type: String
            optional :special_notes, type: String
            optional :current_illness_history, type: String
            optional :family_interview, type: String
            optional :personal_interview, type: String
            optional :created_date, type: String, desc: '2024/04/01'
          end
          post do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            created_date = convert_date(params[:created_date])
            params.merge!({ "created_date" => created_date }) if created_date.present?
            params.merge!({ "created_date" => Time.current.to_date }) if created_date.blank?

            evalue_one = EvalueOne.new(params)
            if evalue_one.save
              { success: I18n.t('evalue_one.success.added') }
            else
              error!(evalue_one.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Update EvalueOne
          desc 'PUT api/v1/admin/evalue_ones/:id'
          params do
            requires :id, type: Integer, message: I18n.t('evalue_one.error.validate.blank')
            optional :daily_rhythm_of_life, type: String
            optional :life_history, type: String
            optional :daily_life_challenges, type: String
            optional :note, type: String
            optional :character, type: String
            optional :hobbies, type: String
            optional :family_circumstances, type: String
            optional :special_notes, type: String
            optional :current_illness_history, type: String
            optional :family_interview, type: String
            optional :personal_interview, type: String
            optional :created_date, type: String, desc: '2024/04/01'
          end
          put '/:id' do
            evalue_one = EvalueOne.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_one.blank?

            created_date = convert_date(params[:created_date])
            params.merge!({ "created_date" => Time.current.to_date }) if created_date.blank?

            if evalue_one.update(params)
              { success: I18n.t('evalue_one.success.updated') }
            else
              error!(evalue_one.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/evalue_ones',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per_page, type: Integer, default: 10
            requires :patient_id, type: Integer, message: I18n.t('evalue_one.error.validate.blank')
          end
          get do
            page = (params[:page].presence || 1).to_i
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @evalue_ones = patient.evalue_ones.order(created_date: :desc).page(page).per(params[:per_page])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @evalue_ones.blank?
            present :page, page
            present :total_items, @evalue_ones.total_count
            present :total_pages, @evalue_ones.total_pages
            present :evalue_ones, @evalue_ones
          end

          desc 'GET api/v1/admin/evalue_ones/:id'
          params do
          end
          get '/:id' do
            evalue_one = EvalueOne.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_one.blank?

            present evalue_one
          end

          desc 'DELETE api/v1/admin/evalue_ones/:id'
          params do
          end
          delete '/:id' do
            evalue_one = EvalueOne.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if evalue_one.blank?

            evalue_one&.destroy
            { success: true }
          end
        end
      end
    end
  end
end
