# == Schema Information
#
# Table name: hospitals
#
#  id                  :bigint           not null, primary key
#  address             :string
#  clinical_department :string
#  name                :string
#  phone               :string
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  patient_id          :bigint           not null
#
# Indexes
#
#  index_hospitals_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class Hospital < ApplicationRecord
  include ApiCommon

  belongs_to :patient

  validates :phone, length: { in: MIN_LENGTH_TEN..MAX_LENGTH_TWENTY }, allow_blank: true
end
