class AddConfirmToMonthlyHoliday < ActiveRecord::Migration[7.0]
  def change
    add_column :monthly_holidays, :confirmed_by_admin, :boolean, default: false
    add_column :monthly_holidays, :confirmed_by_staff, :boolean, default: false
  end
end
