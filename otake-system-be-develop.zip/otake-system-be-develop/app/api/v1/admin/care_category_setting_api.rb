module V1
  module Admin
    class CareCategorySettingApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :care_category_settings do
          desc 'GET api/v1/admin/care_category_settings',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          get do
            objects = CareCategorySetting.all
            object_serialized = objects.map do |object|
              CareCategorySettingSerializer.new(object).as_json
            end

            present :data, object_serialized
          end

          desc 'POST api/v1/admin/care_category_settings',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :data, type: Array, desc: '[{id: 1, name: "要介護1", unit: 123, price: 456}, {}, ...]'
          end
          post do
            error!(I18n.t('login.validate.blank'), UNPROCESSABLE_ENTITY) if params[:data].blank?

            CareCategorySetting&.destroy_all
            params[:data].each do |attr|
              CareCategorySetting.create!(attr)
            end

            { success: I18n.t('evalue_two.success.updated') }
          end
        end
      end
    end
  end
end
