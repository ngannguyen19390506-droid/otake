class CarePlanAtHome < ActiveRecord::Migration[7.0]
  def change
    create_table :care_plan_at_homes do |t|
      t.references :patient, null: false, foreign_key: true
      t.string :year_month, null: false

      t.timestamps
    end

    create_table :schedule_at_homes do |t|
      t.references :care_plan_at_home, null: false, foreign_key: true
      t.references :service_home_system, null: false, foreign_key: true
      t.integer :supplement_options, null: false

      t.timestamps
    end

    create_table :schedule_memo_at_homes do |t|
      t.references :care_plan_at_home, null: false, foreign_key: true
      t.string :content, null: false

      t.timestamps
    end

    create_table :schedule_date_at_homes do |t|
      t.references :schedule_homeable, polymorphic: true, index: true
      t.date :date, null: false
      t.string :start_time, null: false
      t.string :end_time, null: false

      t.timestamps
    end
  end
end
