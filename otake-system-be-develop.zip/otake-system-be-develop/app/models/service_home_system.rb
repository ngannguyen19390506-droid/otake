# == Schema Information
#
# Table name: service_home_systems
#
#  id               :bigint           not null, primary key
#  display_name     :string           not null
#  dropdown_values  :json
#  position         :integer          not null
#  selection_method :integer          not null
#  service_name     :string           not null
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#
# Indexes
#
#  index_service_home_systems_on_display_name  (display_name) UNIQUE
#  index_service_home_systems_on_service_name  (service_name) UNIQUE
#
class ServiceHomeSystem < ApplicationRecord
  include ApiCommon

  enum selection_method: { checkbox: 1, dropdown: 2, free_input: 3 }

  validates :dropdown_values, presence: true, if: -> { selection_method == 'dropdown' }
  validates :display_name, :selection_method, :service_name, presence: true
  validates :service_name, :display_name, uniqueness: true

  before_create :set_default_position
  before_save :clear_dropdown_values_if_not_dropdown

  has_many :schedule_at_homes, dependent: :destroy
  has_many :care_plan_at_homes, through: :schedule_at_homes

  private

  def set_default_position
    highest_position = ServiceHomeSystem.maximum(:position) || 0

    self.position = highest_position + 1
  end

  def clear_dropdown_values_if_not_dropdown
    self.dropdown_values = nil if self.selection_method != 'dropdown'
  end
end
