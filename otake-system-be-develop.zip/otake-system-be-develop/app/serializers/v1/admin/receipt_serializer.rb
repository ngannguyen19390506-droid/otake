module V1
  module Admin
    class ReceiptSerializer < ActiveModel::Serializer
      attributes :id,
                 :price,
                 :memo,
                 :files

      # has_many :document_receipts, serializer: DocumentReceiptSerializer
      def files
        object.document_receipts.map do |doc_recipt|
          {
            id: doc_recipt.id,
            file_path: doc_recipt.file_url
          }
        end
      end
    end
  end
end
