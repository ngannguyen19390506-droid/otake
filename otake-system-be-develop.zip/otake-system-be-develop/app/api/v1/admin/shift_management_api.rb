module V1
  module Admin
    class ShiftManagementApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :shift_managements do
          desc 'GET /api/v1/admin/shift_managements',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :date, type: String, desc: '2024/05/10'
          end
          get do
            date = params[:date]
            error!({ 'messages': I18n.t('patient.error.validate.blank') }, UNPROCESSABLE_ENTITY) if date.blank?

            data = get_patient_schedules(date)
            present :patient_schedules, data
          end

          desc 'GET /api/v1/admin/shift_managements/shifts-list',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer
            requires :date, type: String, desc: '2024/03/17'
          end
          get 'shifts-list' do
            patient = Patient.find(params[:patient_id])
            date = params[:date].to_date
            schedule_dates = patient.schedule_dates.where(date: date)
            schedule_dates_objects = schedule_dates.map do |schedule|
              ScheduleDateSerializer.new(schedule).as_json
            end
            present :schedule_dates, schedule_dates_objects
          end

          desc 'GET /api/v1/admin/shift_managements/staffs-list',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :date, type: String, desc: '2024/03/17'
          end
          get 'staffs-list' do
            date = params[:date].to_date
            staffs = NursingStaff.active.includes(:nursing_schedules).where(nursing_schedules: { date: date })
            staff_objects = staffs.map do |staff|
              NursingStaffSerializer.new(staff).as_json
            end
            present :staffs, staff_objects
          end

          desc 'POST /api/v1/admin/shift_managements/assign-staff',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :schedule_date_id, type: Integer
            requires :nurse_id, type: Integer
          end
          post 'assign-staff' do
            schedule = ScheduleDate.find(params[:schedule_date_id])
            schedule.update(nurse_id: params[:nurse_id], status: 'sent')
            nurse_history = NursingCareHistory.find_by(schedule_date_id: schedule.id)
            nurse_history&.update_column('nurse_id', params[:nurse_id])
            { success: I18n.t('success.messages.added') }
          rescue StandardError => e
            error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
          end

          desc 'POST api/v1/admin/shift_managements/auto_holidays'
          params do
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
          end

          post '/auto_holidays' do
            check_nursing_shift_manage_confirmation
            year_month = params[:year_month]
            nursing_staffs = NursingStaff.includes(:degrees, :monthly_holidays, :holidays).active.default_order
            monthly_holidays = MonthlyHoliday.where(nurse_id: nursing_staffs.pluck(:id), year_month: year_month).group_by(&:nurse_id)
            start_month = year_month.to_date
            end_month = start_month.end_of_month
            start_time = '08:00'
            end_time = '17:00'
            shift_create_params = { start_time: start_time, end_time: end_time }
            shift_registration = ShiftRegistration.find_by(shift_create_params)

            data = []
            nursing_staffs.each_slice(7) do |staffs|
              staffs.each_with_index { |staff, idx|
                monthly_holiday = monthly_holidays[staff.id]&.first
                monthly_holiday = staff.monthly_holidays.create(year_month: year_month, status: 'initial', create_type: 'admin') if monthly_holiday.blank?
                holidays = staff.holidays.where(date: start_month..end_month).group_by(&:date)

                ic = idx + 1
                loop_number = idx.zero? ? 5 : 4
                holiday_dates = []
                loop_number.times do
                  date = "#{year_month}/#{ic}".to_date
                  ic += 7
                  next if date > end_month

                  holiday = holidays[date]
                  data << Holiday.new(monthly_holiday_id: monthly_holiday.id, date: date, create_type: 'admin') if holiday.blank?
                  holiday_dates << date
                end

                holiday_dates.concat(holidays.keys)
                options = {
                  start_month: start_month,
                  end_month: end_month,
                  staff_id: staff.id,
                  shift_registration_id: shift_registration&.id,
                  holiday_dates: holiday_dates.uniq
                }
                BulkCreateShiftJob.perform_later(options)
              }
            end

            Holiday.import(data) if data.present?

            { success: I18n.t('success.messages.added') }
          end

          desc 'POST api/v1/admin/shift_managements/auto_shifts'
          params do
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
          end

          post '/auto_shifts' do
            # Lấy 4 lịch lv (早番・遅番・夜勤入り・夜勤明け) và 1 lịch nghỉ (休み) từ MH42
            # .Staff A : cố định lịch 1,nghỉ ngày m1,m8,15,22,29
            # .Staff B : cố định lịch 2,nghỉ ngày m2,m9,16,23,30
            # .Staff C : cố định lịch 3,nghỉ ngày m3,m10,17,24,31
            # .Staff D : cố định lịch 4,nghỉ ngày m4,m11,18,25
            check_nursing_shift_manage_confirmation
            year_month = params[:year_month]
            next_year_month = Date.current.next_month
            if year_month != next_year_month.strftime('%Y/%m')
              return error!({ 'message': I18n.t('errors.messages.invalid_month'),
                              'details': "The specified month (#{year_month}) is not the next month (#{next_year_month})." }, UNPROCESSABLE_ENTITY)
            end

            nursing_staffs = NursingStaff.includes(:degrees, :monthly_holidays, :holidays).active.default_order
            start_month = next_year_month.beginning_of_month
            end_month = next_year_month.end_of_month
            groups_info = [
              { name: '早番', holidays: [1, 8, 15, 22, 29] }, # early_shift
              { name: '遅番', holidays: [2, 9, 16, 23, 30] }, # late_shift
              { name: '夜勤入り', holidays: [3, 10, 17, 24, 31] }, # night_shift
              { name: '夜勤明け', holidays: [4, 11, 18, 25] } # after_night_shift
            ]
            ActiveRecord::Base.transaction do
              grouped_staffs = nursing_staffs.in_groups(4, false)
              grouped_staffs.each_with_index do |group, index|
                group_info = groups_info[index]
                shifts_for_group = ShiftRegistration.find_by(name: group_info[:name])
                holidays_for_group = group_info[:holidays]
                group = NursingStaff.where(id: group.map(&:id))

                group.find_in_batches(batch_size: 100) do |batch|
                  batch.each do |staff|
                    monthly_holiday = staff.monthly_holidays.find_by(year_month: next_year_month.strftime('%Y/%m'))
                    holiday_dates = staff.holidays.admin.where(date: start_month..end_month).pluck(:date)
                    shift_dates = staff.shifts.where(shift_date: start_month..end_month).pluck(:shift_date)
                    unavailable_dates = (holiday_dates + shift_dates).uniq

                    (start_month..end_month).each do |date|
                      next if unavailable_dates.include?(date)

                      if holidays_for_group.include?(date.day)
                        monthly_holiday.holidays.create(date: date, create_type: 'admin', status: 'initial', name: '休み')
                      else
                        create_params = { shift_date: date, shift_registration_id: shifts_for_group.id,
                                          start_time: shifts_for_group.start_time, end_time: shifts_for_group.end_time, create_type: 'admin' }
                        shift_management = ShiftManagement.create(create_params)
                        staff.nursing_shift_manages.create(shift_id: shift_management.id)
                      end
                    end
                  end
                end
              end
              { success: I18n.t('success.messages.added') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'POST api/v1/admin/shift_managements/update_status'
          params do
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :status, type: String, desc: 'draft/cancel'
          end

          post '/update_status' do
            check_nursing_shift_manage_confirmation
            year_month = params[:year_month]
            next_year_month = Date.current.next_month.strftime('%Y/%m')
            if year_month != next_year_month
              return error!({ 'message': I18n.t('errors.messages.invalid_month'),
                              'details': "The specified month (#{year_month}) is not the next month (#{next_year_month})." }, UNPROCESSABLE_ENTITY)
            end

            start_month = year_month.to_date.beginning_of_month
            end_month = start_month.end_of_month
            holidays = Holiday.includes(monthly_holiday: :nurse).initial.admin.where(date: start_month..end_month)
            shifts_initial = ShiftManagement.includes(:nurses).admin.initial.where(shift_date: start_month..end_month)
            schedule_dates_with_previous_data = ScheduleDate.where(date: start_month..end_month).where.not(previous_data: nil)
            shifts_with_previous_data = ShiftManagement.where(shift_date: start_month..end_month).where.not(previous_data: nil)
            ActiveRecord::Base.transaction do
              case params[:status]
              when 'draft'
                holidays.each do |holiday|
                  # remove shifts on holiday
                  staff = holiday.monthly_holiday.nurse
                  staff.shifts.where(shift_date: holiday.date).destroy_all
                  # remove holiday if holiday is dup
                  staff.holidays.where(date: holiday.date).where.not(status: 'initial').destroy_all
                end
                holidays&.update_all(status: nil)
                shifts_initial.each do |shift|
                  # remove holidays on shift
                  staff = shift.nurses.first
                  staff.holidays.where(date: shift.shift_date).destroy_all
                  shift.nursing_shift_manages.update_all(status: 'draft')
                end
                shifts_initial&.update_all(status: 'draft', previous_data: nil)
                schedule_dates_with_previous_data.each do |schedule_date|
                  schedule_date.update(previous_data: nil)
                end
                shifts_with_previous_data.each do |shift|
                  shift.update(previous_data: nil)
                end
              when 'cancel'
                holidays&.destroy_all
                shifts_initial&.destroy_all
                schedule_dates_with_previous_data.each do |schedule_date|
                  schedule_date.update(schedule_date.previous_data)
                end
                shifts_with_previous_data.each do |shift|
                  shift.update(shift.previous_data)
                end
              end
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
            { success: I18n.t('success.messages.added') }
          end

          desc 'POST api/v1/admin/shift_managements/create_shifts'
          params do
            requires :staff_id, type: Integer
            optional :start_time, type: String
            optional :end_time, type: String
            requires :dates, type: Array
            optional :shift_registration_id, type: Integer
          end

          post '/create_shifts' do
            check_nursing_shift_manage_confirmation
            start_time = params[:start_time]
            end_time = params[:end_time]
            staff_id = params[:staff_id]
            staff = NursingStaff.find(staff_id)
            year_month = params[:dates].first.split('T').first.to_date
            next_month = Date.current.next_month
            next_month_start = next_month.beginning_of_month
            next_month_end = next_month_start.end_of_month
            dates = params[:dates]
            dates.each do |date|
              date_format = date.split('T').first.to_date
              params[:dates].delete(date) if date_format < next_month_start || date_format > next_month_end
            end

            shift_registration_id = params[:shift_registration_id]
            shift_registration = ShiftRegistration.find_by(id: shift_registration_id)
            start_time = shift_registration.present? ? shift_registration.start_time : start_time
            end_time = shift_registration.present? ? shift_registration.end_time : end_time
            shift_name = shift_registration.present? ? shift_registration.name : ''
            type = match_shift(shift_name)
            ActiveRecord::Base.transaction do
              if ['holiday', 'request_holiday'].include?(type)
                year_month = year_month.strftime('%Y/%m')
                monthly_holiday = staff.monthly_holidays.find_by(year_month: year_month)
                return error!({ 'messages': I18n.t('errors.messages.not_found'), staff_id: staff_id }, NOT_FOUND) if monthly_holiday.blank?

                params[:dates].each do |date|
                  name = shift_registration.name
                  date = date.split('T').first.to_date
                  staff.holidays.initial.where(date: date).destroy_all
                  monthly_holiday.holidays.create(date: date, create_type: 'admin', status: 'initial', name: name)
                  staff.shifts.includes(:nursing_shift_manages).where(shift_date: date).where(nursing_shift_manages: { status: 'initial' }).destroy_all
                end
              else
                params[:dates].each do |date|
                  date = date.split('T').first.to_date
                  sm = staff.shifts.find_by(shift_date: date)
                  if sm.present?
                    sm.previous_data = sm.attributes if sm.previous_data.blank?
                    sm.update(shift_registration_id: shift_registration_id, start_time: start_time, end_time: end_time)
                  else
                    create_params = { shift_date: date, shift_registration_id: shift_registration_id,
                                      start_time: start_time, end_time: end_time, create_type: 'admin' }
                    shift_management = ShiftManagement.create(create_params)
                    staff.nursing_shift_manages.create(shift_id: shift_management.id)
                  end
                  staff.holidays.initial.where(date: date).destroy_all
                end
              end

              staff.schedule_dates.where(date: params[:dates]).each do |schedule_date|
                available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(schedule_date.date, schedule_date.start_time, schedule_date.end_time)
                if available_nurse_ids.exclude?(staff.id)
                  schedule_date.previous_data = schedule_date.attributes if schedule_date.previous_data.blank?
                  schedule_date.update(nurse_id: nil)
                end
              end
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end

            { success: I18n.t('success.messages.added') }
          end

          desc 'GET /api/v1/admin/shift_managements/shifts',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String
          end
          get '/shifts' do
            year_month = params[:year_month]
            nursing_staffs = NursingStaff.includes(:degrees, :monthly_holidays, :holidays, :nursing_shift_manages, :shifts)
                                         .active
                                         .order(employment_type: :asc, nurse_code: :asc)
            start_month = year_month.to_date.beginning_of_month.beginning_of_day
            end_month = start_month.end_of_month.end_of_day
            query_conditions = { date_gteq: start_month, date_lteq: end_month }
            shift_registrations = ShiftRegistration.by_nurse_ids(nursing_staffs.pluck(:id).to_a.uniq)
                                                   .ransack(query_conditions)
                                                   .result(distinct: true)
                                                   .by_created_at_asc
                                                   .group_by(&:nurse_id)

            data = nursing_staffs.map { |nurse|
              shift_data = shift_registrations[nurse.id.to_s]
              nurse.attributes.slice("id", "family_name", "nurse_code", "employment_type").merge!({ shifts: shift_data })
            }

            shift = ShiftStatus.find_by(year_month: params[:year_month])
            shift_status = shift.present? && shift.shift_lock?
            { shift_lock: shift_status, data: data }
          end

          desc 'POST api/v1/admin/shift_managements',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :data, type: Array do
              requires :nurse_id, type: Integer
              requires :dates, type: Array, desc: '["2024/10/01", "2024/10/02",...]'
              requires :shift_type, type: String, values: ShiftRegistration.shift_types.keys
              optional :date_deleted, type: Array, desc: '["2024/10/01", "2024/10/02",...]'
              optional :note, type: String, desc: 'Note'
            end
          end
          post do
            params[:data].each do |data|
              staff = NursingStaff.find_by_id(data[:nurse_id])
              ShiftRegistration.where(nurse_id: data[:nurse_id], date: data[:date_deleted])&.destroy_all
              shift_registrations = ShiftRegistration.where(nurse_id: data[:nurse_id]).group_by(&:date)
              shift_type = data[:shift_type]
              note = data[:note]

              data[:dates].each do |date|
                date = date.to_date
                shift = shift_registrations[date]&.first
                shift.update!(shift_type: shift_type, note: note) && next if shift.present?

                staff.shift_registrations.create(shift_type: shift_type, date: date, note: note)
              end
            end
            { success: I18n.t('success.messages.updated') }
          end

          desc 'POST api/v1/admin/shift_managements/update-shift-status',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String, desc: '2024/11'
            requires :status, type: String, values: ShiftStatus.statuses.keys
          end
          post '/update-shift-status' do
            shift_status = ShiftStatus.find_by(year_month: params[:year_month])
            if shift_status.blank?
              shift_status = ShiftStatus.create(year_month: params[:year_month], status: params[:status])
            else
              shift_status.update(status: params[:status])
            end
            render shift_status
          end

          desc 'POST api/v1/admin/shift_managements/clear-schedule-date',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :schedule_date_ids, type: Array, desc: "[1, 2, 3,....]"
          end
          post '/clear-schedule-date' do
            params[:schedule_date_ids].each do |schedule_date_id|
              schedule_date = ScheduleDate.find_by(id: schedule_date_id)
              schedule_date.update_attribute('nurse_id', nil)
              schedule_date.nursing_care_history&.destroy
              create_schedule_history_skip_validates(schedule_date.id, schedule_date)
            end

            { success: I18n.t('success.messages.updated') }
          end
        end
      end

      helpers do
        def match_shift name
          case name
          when '早番'
            'early'
          when '遅番'
            'late'
          when '夜勤入り'
            'night'
          when '夜勤明け'
            'night'
          when '休み'
            'holiday'
          when '希望休'
            'request_holiday'
          end
        end

        def check_nursing_shift_manage_confirmation
          year_month = Date.current.next_month.strftime('%Y/%m')
          staffs_acitve = NursingStaff.active
          monthly_holidays = MonthlyHoliday.where(year_month: year_month)
          return error!(I18n.t('errors.messages.wait_for_staff_send_shift'), UNPROCESSABLE_ENTITY) if monthly_holidays.count < staffs_acitve.count

          confirmed_by_staff = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_staff: false)
          return error!(I18n.t('errors.messages.wait_for_staff_confirmation'), UNPROCESSABLE_ENTITY) if confirmed_by_staff.present?

          confirmed_by_staff_and_admin = MonthlyHoliday.where(year_month: year_month, status: 'approved')
          error!(I18n.t('errors.messages.shift_finalized'), UNPROCESSABLE_ENTITY) if confirmed_by_staff_and_admin.present?
        end

        def confirm_shift()
          year_month = Date.current.next_month.strftime('%Y/%m')
          confirmed_by_admin = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_admin: false)
          confirmed_by_staff = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_staff: false)
          staffs_acitve = NursingStaff.active
          monthly_holidays = MonthlyHoliday.where(year_month: year_month)
          return {} if monthly_holidays.count < staffs_acitve.count

          { confirmed_by_admin: confirmed_by_admin.blank?, confirmed_by_staff: confirmed_by_staff.blank?, status: monthly_holidays.last.status }
        end
      end
    end
  end
end
