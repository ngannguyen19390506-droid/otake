module V1
  module Admin
    class UsageBillingApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :usage_billings do
          desc 'GET api/v1/admin/usage_billings'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
            requires :invoice_type, type: String, message: I18n.t('error.validate.blank'), desc: 'nursing_care/ disability'
          end

          get do
            billing = UsageBilling.find_or_create_by(params_find_billing)
            if billing.additional.blank?
              invoice_type = params[:invoice_type]
              case invoice_type
              when 'nursing_care'
                additional = 11.05
              when 'disability'
                additional = 10.9
              end
              billing.update(additional: additional)
            end

            present billing
          end

          desc 'POST api/v1/admin/usage_billings'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :invoice_type, type: String, message: I18n.t('error.validate.blank'), desc: 'nursing_care/ disability'
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :subsidy_amount, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :exceeding_amount, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :other_charge, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :billing_amount, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :additional, type: Float, message: I18n.t('error.validate.blank'), default: 0
          end

          post do
            patient = Patient.find(params_patient[:patient_id])
            billing = patient.usage_billings.new(params)
            if billing.save
              { success: I18n.t('success.messages.updated') }
            else
              error!({ errors: billing.errors }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/usage_billings/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :subsidy_amount, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :exceeding_amount, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :other_charge, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :billing_amount, type: Float, message: I18n.t('error.validate.blank'), default: 0
            requires :additional, type: Float, message: I18n.t('error.validate.blank'), default: 0
          end

          put ':id' do
            billing = UsageBilling.find(params[:id])
            vls = %w(subsidy_amount exceeding_amount other_charge billing_amount additional)
            vls.map { |v|
              billing.assign_attributes({ v => params_billings[v] }) if params_billings[v].present?
            }
            if billing.save
              { success: I18n.t('success.messages.updated') }
            else
              error!({ errors: billing.errors }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/usage_billings/invoice_pdf'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
            requires :invoice_type, type: String, message: I18n.t('error.validate.blank'), desc: 'nursing_care/ disability'
          end

          get '/invoice_pdf' do
            patient = Patient.find_by(id: params[:patient_id])
            year_month = params[:year_month]
            current_date = Time.current.strftime('%Y/%m')
            patient_name = patient&.family_name
            invoice_type = params[:invoice_type]

            billing = UsageBilling.find_by(params_find_billing)
            subsidy_amount = billing&.subsidy_amount.to_f
            # exceeding_amount = billing&.exceeding_amount.to_f
            # other_charge = billing&.other_charge.to_f
            billing_amount = billing&.billing_amount.to_f

            system_profile = SystemManagementProfile.first

            case invoice_type
            when NURSING_CARE_TYPE
              patient_care_plan = patient.nursing_care_plans.find_by(year_month: year_month)
              additional_rate = system_profile&.rate_registration_nursing_care
              additional = additional_rate.to_f.zero? ? DEFAULT_NURSING_ADDITIONAL : additional_rate
            when DISABILITY_TYPE
              patient_care_plan = patient.disability_care_plans.find_by(year_month: year_month)
              additional_rate = system_profile&.rate_registration_disability
              additional = additional_rate.to_f.zero? ? DEFAULT_DISABILITY_ADDITIONAL : additional_rate
              patient_recipient = patient.recipients&.last
            end

            result = []
            treatment_data = []
            care_plan_sum = 0
            benefit_limit = 0
            payment_amount = 0
            public_expense = patient.public_expenses.by_created_at_asc&.last
            if patient_care_plan.present?
              schedule_date_ids = patient_care_plan.schedule_dates.pluck(:id)
              nursing_histories = preload_change_histories(schedule_date_ids)

              result = patient_care_plan.schedules.each_with_object(Hash.new { |h, k| h[k] = { quantity: 0, subtotal: 0 } }) do |schedule, acc|
                service = schedule.service
                service_name = service.service_name
                unit_price = service.unit_price
                quantity = schedule.schedule_dates.count { |date| nursing_histories[date.id].present? }

                # Accumulate totals for each service
                acc[service_name][:service_name] = service_name
                acc[service_name][:unit_price] = unit_price
                acc[service_name][:quantity] += quantity
                acc[service_name][:subtotal] += unit_price * quantity
              end.values

              care_plan_sum = result.pluck(:subtotal).sum
              insurance_cards = patient.insurance_cards.by_created_at_desc.first

              case invoice_type
              when NURSING_CARE_TYPE
                treatment_improvements = patient_care_plan.treatment_improvements.normal
                benefit_limit = insurance_cards&.benefit_limit.to_f
              when DISABILITY_TYPE
                treatment_improvements = patient_care_plan.treatment_improvements.disability
                benefit_limit = patient_recipient&.user_burden_percentage.to_f
              end

              treatment_improvements.each do |treat_improve|
                rate = treat_improve.rate.to_f
                treatment_data << { service_name: treat_improve.name, rate: rate,
                                    subtotal: convert_concurrency((care_plan_sum * rate) / 100) }
              end
            end

            treatment_sum = treatment_data.pluck(:subtotal).sum
            care_plan_treatment_sum = care_plan_sum + treatment_sum

            public_expense_rate = public_expense&.benefit_rate.to_f

            row_1 = care_plan_sum * additional
            care_benefit_amount = (row_1 * benefit_limit).to_d / 100

            if invoice_type == NURSING_CARE_TYPE
              payment_amount = ((row_1 - care_benefit_amount) * public_expense_rate).to_d / 100
              # payment_amount = payment_amount - public_expense&.payment_amount.to_i
            end

            if invoice_type == DISABILITY_TYPE
              cost_limit = patient_recipient&.monthly_cost_limit.to_i
              care_benefit_amount = care_benefit_amount > cost_limit ? cost_limit : care_benefit_amount
            end
            equipment_service_payments = patient.equipment_service_payments.where.not(equipment_service_id: nil)
                                                .where(year_month: year_month)

            equipment_service_usage_groupped = EquipmentServiceUsage.where(equipment_service_payment_id: equipment_service_payments.pluck(:id))
                                                                    .group_by { |f| f.equipment_service_payment_id }
            usage_fee = 0
            equipment_service_payments.each do |equipment_service|
              service_usages = equipment_service_usage_groupped[equipment_service.id]
              next if service_usages.blank?

              unit_price = equipment_service.unit_price.to_i
              total_usages = service_usages.pluck(:quantity).to_a.compact.sum
              usage_fee += (unit_price * total_usages)
            end

            other_charge = usage_fee + treatment_sum

            user_burden = row_1 - care_benefit_amount - payment_amount - subsidy_amount

            if payment_amount.zero?
              care_level = insurance_cards&.care_level
              care_category_setting_unit = CareCategorySetting.find_by(name: care_level)&.unit.to_i

              actual_difference_amount = if care_plan_sum > care_category_setting_unit
                                           ((care_plan_sum - care_category_setting_unit) * additional_rate.to_d).to_f
                                         else
                                           0
                                         end

              exceeding_amount = actual_difference_amount
            else
              exceeding_amount = 0
            end

            exceeding_amount = exceeding_amount + public_expense&.payment_amount.to_i

            row_9 = user_burden + exceeding_amount + other_charge - billing_amount

            total_service_usages = treatment_improvements&.by_created_at_desc&.first&.rate.to_d * care_plan_treatment_sum

            data = { date: year_month, patient_name: patient_name, current_date: current_date,
                     bill_detail: result, row_1: convert_concurrency(row_1), treatments: treatment_data,
                     row_7: convert_concurrency(care_benefit_amount), row_9: convert_concurrency(row_9),
                     public_expense: public_expense_rate, payment_amount: convert_concurrency(payment_amount),
                     insurance_card: benefit_limit, subsidy_amount: convert_concurrency(subsidy_amount),
                     exceeding_amount: convert_concurrency(exceeding_amount), user_burden: convert_concurrency(user_burden),
                     other_charge: convert_concurrency(other_charge), billing_amount: convert_concurrency(billing_amount),
                     additional: additional, total_treatments: treatment_sum, total_service_usages: total_service_usages.to_f }

            render data: data
          end
        end
      end

      helpers do
        def params_patient
          params.slice(:patient_id)
        end

        def params_find_billing
          params.slice(:patient_id, :year_month, :invoice_type)
        end

        def params_billings
          params.slice(:patient_id, :year_month, :invoice_type, :subsidy_amount, :exceeding_amount, :other_charge, :billing_amount, :additional)
        end

        def format_delimiter value
          "#{ActiveSupport::NumberHelper.number_to_delimited(value)}"
        end

        def format_delimiter_with_unit value
          "#{format_delimiter(value)}円"
        end

        def format_delimiter_with_yen value
          "￥ #{format_delimiter(value)}"
        end

        def calculate_care_plan_summary(patient_care_plan, nursing_histories)
          patient_care_plan.schedules
                           .map { |schedule| build_schedule_summary(schedule, nursing_histories) }
                           .group_by { |item| item[:service_name] }
                           .map { |service_name, items| aggregate_service_items(service_name, items) }
        end

        def build_schedule_summary(schedule, nursing_histories)
          service = schedule.service
          quantity = schedule.schedule_dates.count { |date| nursing_histories[date.id].present? }

          {
            service_name: service.service_name,
            unit_price: service.unit_price,
            quantity: quantity,
            subtotal: service.unit_price * quantity
          }
        end

        def aggregate_service_items(service_name, items)
          {
            service_name: service_name,
            unit_price: items.map { |item| item[:unit_price] }.max,
            quantity: items.sum { |item| item[:quantity] },
            subtotal: items.sum { |item| item[:subtotal] }
          }
        end

        def convert_concurrency concurrency
          concurrency.to_s.split('.').first.to_i
        end
      end
    end
  end
end