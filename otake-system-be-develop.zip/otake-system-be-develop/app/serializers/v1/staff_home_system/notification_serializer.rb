module V1
  module StaffHomeSystem
    class NotificationSerializer < ActiveModel::Serializer
      attributes :id, :poster, :content, :created_at, :deployment_date,
                 :sender_id, :sender_type, :unread_count
      belongs_to :patient, foreign_key: :patient_id, optional: true
      belongs_to :notification_category, foreign_key: :notification_category_id, optional: true
      belongs_to :user_home_system, foreign_key: :user_home_system_id, optional: true

      def created_at
        object.created_at.strftime('%Y/%m/%d %H:%M')
      end

      def deployment_date
        object.deployment_date&.strftime('%Y/%m/%d')
      end

      def unread_count
        uids = object.notification_view_logs
        UserHomeSystem.count - uids.count
      end
    end
  end
end