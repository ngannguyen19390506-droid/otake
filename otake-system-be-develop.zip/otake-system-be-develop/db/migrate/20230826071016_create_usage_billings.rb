class CreateUsageBillings < ActiveRecord::Migration[7.0]
  def change
    create_table :usage_billings do |t|
      t.integer :invoice_type
      t.float :subsidy_amount
      t.float :exceeding_amount
      t.float :other_charge
      t.float :billing_amount
      t.float :additional
      t.integer :patient_id
      t.string :year_month

      t.timestamps
    end
  end
end
