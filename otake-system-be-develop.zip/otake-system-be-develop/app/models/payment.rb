# == Schema Information
#
# Table name: payments
#
#  id                :bigint           not null, primary key
#  account_name_kana :string
#  account_number    :string
#  account_type      :integer
#  bank_name         :string
#  branch_name       :string
#  building_name     :string
#  city              :string
#  customer_number   :string
#  district          :string
#  payer             :string           default("other"), not null
#  payment_method    :integer          default("account_transfer"), not null
#  street            :string
#  zipcode           :string
#  created_at        :datetime         not null
#  updated_at        :datetime         not null
#  bank_info_id      :integer
#  branch_info_id    :integer
#  patient_id        :bigint           not null
#
# Indexes
#
#  index_payments_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class Payment < ApplicationRecord
  include ApiCommon

  has_many :change_histories, as: :changeable, dependent: :destroy

  belongs_to :patient

  validates :account_number, :bank_name, :branch_name, :account_name_kana, :customer_number, :account_type,
            :bank_info_id, :branch_info_id, presence: true, if: -> { payment_method == 'account_transfer' }
  validates :zipcode, :district, :city, :street, presence: true, if: -> { payer == 'other' }
  # validate :validate_address_with_zipcode, if: -> { payer == 'other' }

  enum payment_method: { collect_money: 1, transfer: 2, account_transfer: 3 }
  enum account_type: { ordinary_deposit: 1, current_account: 2, time_deposit: 3 }
  enum payer: { yourself: 'yourself', other: 'other' }

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_changes_without_timestamps(previous_changes)
      all_changes.each do |changed_attribute, (before_value, after_value)|
        text_description = I18n.t("attribute_description.payment.#{changed_attribute}")
        create_change_history(user_admin_id, text_description, before_value, after_value)
      end
    rescue StandardError => e
      e
    end
  end
end
