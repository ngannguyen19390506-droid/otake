# == Schema Information
#
# Table name: care_category_settings
#
#  id    :bigint           not null, primary key
#  name  :string           not null
#  price :string           not null
#  unit  :string           not null
#
# Indexes
#
#  index_care_category_settings_on_id  (id)
#
class CareCategorySetting < ApplicationRecord
end
