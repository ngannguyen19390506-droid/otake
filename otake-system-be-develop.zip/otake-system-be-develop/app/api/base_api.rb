class BaseApi < Grape::API
  mount V1::AppApi
  add_swagger_documentation(
    mount_path: '/link-api-docs',
    info: {
      title: 'Admin API',
      description: 'API documentation with Authorization header'
    },
    security_definitions: {
      Bearer: {
        type: 'apiKey',
        name: 'Authorization',
        in: 'header',
        description: 'Ex: Bearer [your_token]'
      }
    },
    security: [{ Bearer: [] }],
    hide_documentation_path: false,
    hide_format: true
  )
end
