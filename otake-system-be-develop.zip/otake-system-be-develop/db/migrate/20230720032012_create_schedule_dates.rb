class CreateScheduleDates < ActiveRecord::Migration[7.0]
  def change
    create_table :schedule_dates do |t|
      t.references :scheduleable, polymorphic: true, null: false
      t.date :date

      t.timestamps
    end
  end
end
