class AddEncryptedPasswordToNursingStaff < ActiveRecord::Migration[7.0]
  def change
    change_column :nursing_staffs, :password, :string, null: true
    add_column :nursing_staffs, :encrypted_password, :string
  end
end
