class RemoveReferencesOfRooms < ActiveRecord::Migration[7.0]
  def change
    remove_reference :rooms, :user_admin, index: true, foreign_key: true
    remove_reference :rooms, :nurse, index: true, foreign_key: { to_table: :nursing_staffs }
  end
end
