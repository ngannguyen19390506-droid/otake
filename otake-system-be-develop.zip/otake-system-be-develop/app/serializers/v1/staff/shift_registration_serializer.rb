module V1
  module Staff
    class ShiftRegistrationSerializer < ActiveModel::Serializer
      attributes :id,
                 :nurse_id,
                 :shift_type,
                 :date,
                 :note,
                 :created_at,
                 :updated_at

      belongs_to :nurse, class_name: 'NursingStaff'
    end
  end
end
