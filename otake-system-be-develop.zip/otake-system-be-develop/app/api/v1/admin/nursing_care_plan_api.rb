module V1
  module Admin
    class NursingCarePlanApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :nursing_care_plans do
          # Create NursingCarePlan
          desc 'POST api/v1/admin/nursing_care_plans',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('nursing_care_plan.error.validate.blank')
            requires :year_month, type: String, message: I18n.t('nursing_care_plan.error.validate.blank')
            optional :comprehensive_aid_policy, type: String
            optional :individual_family_intention, type: String
            optional :aid_purpose, type: String
            optional :remarks, type: String
            optional :start_long_term, type: String
            optional :end_long_term, type: String
            optional :long_terms, type: Array
            optional :start_short_term, type: String
            optional :end_short_term, type: String
            optional :short_terms, type: Array
            optional :note, type: String
            requires :schedules, type: Array do
              requires :sort_index, type: Integer
              requires :service_id, type: Integer, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
              requires :start_time, type: String, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
              requires :end_time, type: String, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
              requires :service_type_id, type: Integer, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
              requires :schedule_routines, type: Array[JSON], desc: 'Eg: [{value: 1, checked: true}, {value: 1, checked: false},...]'
              requires :frequency, type: String, values: Schedule.frequencies.keys, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
              requires :shift_type, type: String, values: Schedule.shift_types.keys, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
            end
            optional :improvement_nursing_care_plans, type: Array do
              optional :treatment_improvement_id, type: Integer
            end
            optional :is_clone, type: Boolean
          end

          post do
            ActiveRecord::Base.transaction do
              PAYLOAD_LOGGER.info "POST api/v1/admin/nursing_care_plans --- #{params}"
              year_month = params[:year_month]
              # if params[:schedules].all? do |schedule|
              #   schedule[:schedule_routines].pluck(:checked).uniq.exclude?(true)
              # end
              #   return error!({ 'routines': I18n.t('nursing_care_plan.schedule.error.validate.blank') },
              #                 BAD_REQUEST)
              # end

              patient = Patient.find_by(id: params[:patient_id])
              if patient.blank?
                PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - #{I18n.t('errors.messages.not_found')}")
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND)
              end

              nursing_care_plan = patient.nursing_care_plans.find_by(year_month: year_month)
              if nursing_care_plan.present?
                PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - year_month: #{year_month} - #{I18n.t('errors.messages.already_exists')}")
                return error!({ 'messages': I18n.t('errors.messages.already_exists') },
                              UNPROCESSABLE_ENTITY)
              end

              if params[:schedules].present?
                params[:schedules].map { |f|
                  f['end_time_format'] = ['00:00', '00:0', '0:00', '0:0'].include?(f['end_time_format']) ? '24:00' : f['end_time_format']
                }

                if params[:is_clone]
                  start_month = year_month.to_date.beginning_of_month
                  end_month = start_month.end_of_month
                  schedules = patient.schedules.nursing_plans
                  schedules.each do |schedule|
                    schedule.schedule_dates
                            .where(date: start_month..end_month)
                            .where(nurse_id: nil)&.destroy_all
                  end
                end

                overlap = overlap?(params[:schedules])
                if overlap
                  PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - #{I18n.t('errors.messages.time_overlap')}")
                  return error!({ 'messages': I18n.t('errors.messages.time_overlap') }, UNPROCESSABLE_ENTITY)
                end

                client_overlap?(params[:schedules], year_month)

                time_invalid = time_invalid?(params[:schedules])
                if time_invalid
                  PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - #{I18n.t('errors.messages.time_invalid')}")
                  return error!({ 'messages': I18n.t('errors.messages.time_invalid') }, UNPROCESSABLE_ENTITY)
                end
              end

              result = V1::Admin::CarePlans::CreateNursingCarePlan.call(
                params_nursing_care_plan,
                params[:schedules],
                params[:improvement_nursing_care_plans],
                current_user(UserAdmin, :user_code).id,
                patient
              )
              if result.success?
                # Create nursing schedule dates
                if params[:schedules].present?
                  next if params[:schedules].first.blank?

                  schedules = result.success.schedules
                  schedule_dates = groupped_dates(year_month)

                  schedules.each do |schedule|
                    before_change = ''
                    after_change = "予定表が追加されました。"
                    create_change_history(schedule, @current_user.id, '予定表', before_change, after_change)

                    schedule.schedule_dates.where(nurse_id: nil)&.destroy_all
                    working_days = schedule.schedule_routines.pluck(:regis_day)
                    frequency = schedule.frequency
                    days = working_days_options(year_month, working_days, frequency)

                    schedule_date_params = { start_time: schedule.start_time, end_time: schedule.end_time, shift_dates: [], shift_type: schedule.shift_type }

                    schedule_param = params[:schedules].find { |f| f['start_time'] == schedule.start_time && f['end_time'] == schedule.end_time }
                    if schedule_param.present?
                      start_time_format = schedule_param['start_time_format']
                      end_time_format = compare_end_time(schedule_param['end_time_format'])
                      schedule_date_params.merge!({ start_time_format: start_time_format, end_time_format: end_time_format })
                    end

                    days.each do |day|
                      date_format = year_month + "/#{day.to_s.rjust(2, '0')}"

                      if schedule_dates[date_format.to_date].present?
                        date_selected = schedule_dates[date_format.to_date].select { |f|
                          f_patient_id = f.scheduleable.patient_id
                          is_same_time = (f.start_time_format <= start_time_format && f.end_time_format >= end_time_format) ||
                            (f.start_time_format > start_time_format && f.start_time_format < end_time_format) ||
                            (f.end_time_format > start_time_format && f.end_time_format < end_time_format)

                          if f_patient_id == params[:patient_id].to_i
                            is_same_time
                          else
                            is_same_time && schedule_date_params[:shift_type] == f.shift_type
                          end
                        }
                        next if date_selected.present?
                      end

                      schedule_date_params[:shift_dates] << date_format
                    end

                    create_schedule_date(schedule.id, schedule_date_params, schedule)
                  end
                end
                { success: I18n.t('nursing_care_plan.success.added') }
              else
                error!(result.failure, UNPROCESSABLE_ENTITY)
              end
            end
          rescue StandardError => e
            PROCESS_LOGGER.error(e)
            error!(e.message, UNPROCESSABLE_ENTITY)
          end

          # Update NursingCarePlan
          desc 'PUT api/v1/admin/nursing_care_plans'
          params do
            requires :patient_id, type: Integer, message: I18n.t('nursing_care_plan.error.validate.blank')
            requires :year_month, type: String, message: I18n.t('nursing_care_plan.error.validate.blank')
            optional :comprehensive_aid_policy, type: String
            optional :individual_family_intention, type: String
            optional :aid_purpose, type: String
            optional :start_long_term, type: String
            optional :end_long_term, type: String
            optional :long_terms, type: Array
            optional :start_short_term, type: String
            optional :end_short_term, type: String
            optional :short_terms, type: Array
            optional :remarks, type: String
            optional :note, type: String
            optional :schedules, type: Array do
              optional :sort_index, type: Integer
              optional :id, type: Integer
              optional :service_id, type: Integer, desc: '10:00'
              optional :start_time, type: String, desc: '12:00'
              optional :end_time, type: String
              optional :service_type_id, type: Integer
              requires :schedule_routines, type: Array[JSON], desc: 'Eg: [{id: 1, value: 1, checked: true}, {id: 2, value: 1, checked: false},...]'
              requires :frequency, type: String, values: Schedule.frequencies.keys, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
              requires :shift_type, type: String, values: Schedule.shift_types.keys, message: I18n.t('nursing_care_plan.schedule.error.validate.blank')
            end
            optional :improvement_nursing_care_plans, type: Array do
              optional :id, type: Integer
              optional :treatment_improvement_id, type: Integer
            end
            optional :is_clone, type: Boolean
          end

          put do
            ActiveRecord::Base.transaction do
              PAYLOAD_LOGGER.info "PUT api/v1/admin/nursing_care_plans ---- #{params}"
              year_month = params[:year_month]
              patient = Patient.find_by(id: params[:patient_id])
              if patient.blank?
                PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - #{I18n.t('errors.messages.not_found')}")
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND)
              end

              nursing_care_plan = patient.nursing_care_plans.find_by(year_month: year_month)
              if nursing_care_plan.blank?
                PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - year_month: #{year_month} - #{I18n.t('errors.messages.not_found')}")
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND)
              end

              if params[:schedules].present?
                params[:schedules].map { |f|
                  f['end_time_format'] = ['00:00', '00:0', '0:00', '0:0'].include?(f['end_time_format']) ? '24:00' : f['end_time_format']
                }

                if params[:is_clone]
                  start_month = year_month.to_date.beginning_of_month
                  end_month = start_month.end_of_month
                  schedules = patient.schedules.nursing_plans
                  schedules.each do |schedule|
                    schedule.schedule_dates
                            .where(date: start_month..end_month)
                            .where(nurse_id: nil)&.destroy_all
                  end
                end

                overlap = overlap?(params[:schedules])
                if overlap
                  PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - #{I18n.t('errors.messages.time_overlap')}")
                  return error!({ 'messages': I18n.t('errors.messages.time_overlap') }, UNPROCESSABLE_ENTITY)
                end

                client_overlap?(params[:schedules], year_month)

                time_invalid = time_invalid?(params[:schedules])
                if time_invalid
                  PROCESS_LOGGER.error("patient_id: #{params[:patient_id]} - #{I18n.t('errors.messages.time_invalid')}")
                  return error!({ 'messages': I18n.t('errors.messages.time_invalid') }, UNPROCESSABLE_ENTITY)
                end
              end

              result = V1::Admin::CarePlans::UpdateNursingCarePlan.call(
                nursing_care_plan,
                params_nursing_care_plan,
                params[:schedules],
                params[:improvement_nursing_care_plans],
                current_user(UserAdmin, :user_code).id,
                patient
              )

              if result.success?
                if params[:schedules].present?
                  next if params[:schedules].first.blank?

                  schedules = result.success.schedules
                  schedule_date_ids = schedules.includes(:schedule_dates).pluck('schedule_dates.id')
                  ScheduleDate.where(id: schedule_date_ids).where(schedule_dates: { nurse_id: nil })&.destroy_all
                  schedule_dates = groupped_dates(year_month)

                  schedules.each do |schedule|
                    created_at = schedule.schedule_dates&.last&.created_at
                    schedule.schedule_dates.where.not(nurse_id: nil).each do |schedule_date|
                      schedule_date.nursing_care_history.update(service_id: schedule.service_id,
                                                                service_type_id: schedule.service_type_id)
                    end

                    working_days = schedule.schedule_routines.pluck(:regis_day)
                    frequency = schedule.frequency
                    days = working_days_options(year_month, working_days, frequency)

                    schedule_date_params = { start_time: schedule.start_time, end_time: schedule.end_time, shift_dates: [], shift_type: schedule.shift_type }

                    schedule_param = params[:schedules].find { |f| f['start_time'] == schedule.start_time && f['end_time'] == schedule.end_time }
                    if schedule_param.present?
                      start_time_format = schedule_param['start_time_format']
                      end_time_format = compare_end_time(schedule_param['end_time_format'])
                      schedule_date_params.merge!({ start_time_format: start_time_format, end_time_format: end_time_format })
                    end

                    days.each do |day|
                      date_format = year_month + "/#{day.to_s.rjust(2, '0')}"

                      if schedule_dates[date_format.to_date].present?
                        date_selected = schedule_dates[date_format.to_date].select { |f|
                          f_patient_id = f.scheduleable.patient_id
                          is_same_time = (f.start_time_format <= start_time_format && f.end_time_format >= end_time_format) ||
                            (f.start_time_format > start_time_format && f.start_time_format < end_time_format) ||
                            (f.end_time_format > start_time_format && f.end_time_format < end_time_format)

                          if f_patient_id == params[:patient_id].to_i
                            is_same_time
                          else
                            is_same_time && schedule_date_params[:shift_type] == f.shift_type
                          end
                        }
                        next if date_selected.present?
                      end

                      schedule_date_params[:shift_dates] << date_format
                    end

                    create_schedule_date(schedule.id, schedule_date_params, created_at)
                  end
                end

                { success: I18n.t('nursing_care_plan.success.added') }
              else
                PROCESS_LOGGER.error(result.failure)
                error!(result.failure, UNPROCESSABLE_ENTITY)
              end
            end
          rescue StandardError => e
            PROCESS_LOGGER.error(e)
            error!(e.message, UNPROCESSABLE_ENTITY)
          end

          # detail NursingCarePlan
          desc 'GET api/v1/admin/nursing_care_plans',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('nursing_care_plan.error.validate.blank')
            requires :year_month, type: String, message: I18n.t('nursing_care_plan.error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @nursing_care_plan = patient.nursing_care_plans.find_by(year_month: params[:year_month])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @nursing_care_plan.blank?

            present @nursing_care_plan
          end
        end
      end

      helpers do
        def params_nursing_care_plan
          params_nursing_care_plan = params.slice(
            :patient_id, :comprehensive_aid_policy, :individual_family_intention, :aid_purpose,
            :start_long_term, :end_long_term, :long_term_goal_one, :long_term_goal_two,
            :long_term_goal_three, :long_term_goal_four, :start_short_term, :end_short_term,
            :short_term_goal_one, :short_term_goal_two, :short_term_goal_three, :short_term_goal_four,
            :remarks, :year_month, :note, :sort_index
          )
          params_nursing_care_plan[:long_terms] = params[:long_terms] if params[:long_terms].present?
          params_nursing_care_plan[:short_terms] = params[:short_terms] if params[:short_terms].present?
          params_nursing_care_plan[:start_long_term] = convert_date(params[:start_long_term]) if params[:start_long_term].present?
          params_nursing_care_plan[:end_long_term] = convert_date(params[:end_long_term]) if params[:end_long_term].present?
          params_nursing_care_plan[:start_short_term] = convert_date(params[:start_short_term]) if params[:start_short_term].present?
          params_nursing_care_plan[:end_short_term] = convert_date(params[:end_short_term]) if params[:end_short_term].present?

          params_nursing_care_plan
        end
      end
    end
  end
end
