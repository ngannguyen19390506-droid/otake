module V1
  module Client
    class ServiceTypeSerializer < ActiveModel::Serializer
      attributes :id, :detail
    end
  end
end
