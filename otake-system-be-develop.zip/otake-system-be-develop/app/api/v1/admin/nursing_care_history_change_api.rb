module V1
  module Admin
    class NursingCareHistoryChangeApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :nursing_care_history_changes do
          desc 'GET /api/v1/admin/nursing_care_history_changes',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String, desc: '2024/06'
            optional :name, type: String
            optional :address, type: String
            optional :status, type: String, desc: 'active/ on_leave/ resigned'
            optional :sort_key, type: String
            optional :order, type: String
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
          end
          get do
            year_month = params[:year_month]
            error!({ 'messages': I18n.t('patient.error.validate.blank') }, UNPROCESSABLE_ENTITY) if year_month.blank?

            page = (params[:page].presence || 1).to_i
            year_month = year_month.to_date || Time.current
            start_month = year_month.beginning_of_month.beginning_of_day
            end_month = start_month.end_of_month.end_of_day

            nursing_care_histories = NursingCareHistory.includes(:nursing_care_history_changes).left_outer_joins(:nurse)
                                                       .where.not(nurse_id: nil)
                                                       .where(nursing_care_history_changes: { created_at: start_month..end_month })

            query = Hash.new.tap do |q|
              q[:nurse_family_name_cont] = params[:name] if params[:name].present?
              q[:nurse_building_name_or_nurse_city_or_nurse_district_or_nurse_street_cont] = params[:address] if params[:address].present?
              q[:nurse_status_eq] = params[:status] if params[:status].present?
            end

            nursing_care_histories = nursing_care_histories.ransack(query).result

            sort_key = params[:sort_key]
            if sort_key.present?
              sort_order = params[:order] == 'asc' ? 'ASC' : 'DESC'
              nursing_care_histories = nursing_care_histories
                                         .order("nurse.#{sort_key} #{sort_order} NULLS LAST")
            else
              nursing_care_histories = nursing_care_histories.order(updated_at: :desc)
            end

            history_data = []
            nursing_care_histories.each do |history|
              is_exist = history_data.find { |f| f.nurse_id == history.nurse_id }
              next if is_exist

              history_data << history
            end

            nursing_care_histories = Kaminari.paginate_array(history_data).page(page).per(params[:per])
            serialized_data = nursing_care_histories.map do |history|
              NursingCareHistorySerializer.new(history).as_json
            end

            if sort_key.present? && ['name_kana', 'family_name'].include?(sort_key)
              serialized_data = serialized_data.sort_by { |f| f[:nurse][sort_key.to_sym] }
              serialized_data = serialized_data.reverse if params[:order] != 'asc'
            end

            present :page, page
            present :total_items, nursing_care_histories.total_count
            present :total_pages, nursing_care_histories.total_pages
            present :serialized_nursing_care_histories, serialized_data
          end

          desc 'GET /api/v1/admin/nursing_care_history_changes/detail',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String, desc: '2024/06'
            requires :nurse_id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
          end
          get 'detail' do
            year_month = params[:year_month]
            error!({ 'messages': I18n.t('patient.error.validate.blank') }, UNPROCESSABLE_ENTITY) if year_month.blank?

            nurse_id = params[:nurse_id]
            page = (params[:page].presence || 1).to_i
            year_month = year_month.to_date || Time.current
            start_month = year_month.beginning_of_month.beginning_of_day
            end_month = start_month.end_of_month.end_of_day

            history_changes = NursingCareHistoryChange.where(nurse_id: nurse_id,
                                                             created_at: start_month..end_month)
                                                      .order(created_at: :desc)
            history_changes = history_changes.page(page).per(params[:per])

            serialized_data = history_changes.map do |history|
              NursingCareHistoryChangeSerializer.new(history).as_json
            end

            present :page, page
            present :total_items, history_changes.total_count
            present :total_pages, history_changes.total_pages
            present :serialized_nursing_care_histories, serialized_data
          end
        end
      end
    end
  end
end
