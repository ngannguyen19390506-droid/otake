module V1
  module AdminHomeSystem
    class CarePlanAtHomeSerializer < ActiveModel::Serializer
      attributes :id,
                 :year_month,
                 :patient_id

      def serializable_hash(adapter_options = nil, options = {}, adapter_instance = self.class.serialization_adapter_instance)
        hash = super
        hash[:schedule_at_homes] = format_schedule(object.schedule_at_homes)
        hash[:schedule_memo_at_homes] = format_schedule_memo(object.schedule_memo_at_homes)
        hash
      end

      private

      def format_schedule(schedules)
        schedules_with_dates = schedules.includes(:schedule_date_at_homes)

        schedules_with_dates.map do |schedule|
          schedule_date_at_homes = schedule.schedule_date_at_homes
          {
            id: schedule.id,
            service_home_system_id: schedule.service_home_system_id,
            start_time: schedule_date_at_homes.first&.start_time,
            end_time: schedule_date_at_homes.first&.end_time,
            supplement_options: schedule.supplement_options,
            schedule_date_at_homes: schedule_date_at_homes.pluck(:date).map { |date| date.strftime('%Y/%m/%d') }
          }
        end
      end

      def format_schedule_memo(schedules)
        schedules_with_dates = schedules.includes(:schedule_date_at_homes)

        schedules_with_dates.map do |schedule|
          schedule_date_at_homes = schedule.schedule_date_at_homes
          {
            id: schedule.id,
            content: schedule.content,
            start_time: schedule_date_at_homes.first&.start_time,
            end_time: schedule_date_at_homes.first&.end_time,
            schedule_date_at_homes: schedule_date_at_homes.pluck(:date).map { |date| date.strftime('%Y/%m/%d') }
          }
        end
      end
    end
  end
end
