module V1
  module StaffHomeSystem
    class ServiceHomeSystemApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :staff_home_system do
        resources :service_home_systems do
          desc 'GET /api/v1/staff_home_system/service_home_systems'
          params do
          end
          get do
            serialized_service_home_systems = ServiceHomeSystem.order(:position).map do |service|
              ServiceHomeSystemSerializer.new(service).as_json
            end
            present :data, serialized_service_home_systems
          end
        end
      end
    end
  end
end
