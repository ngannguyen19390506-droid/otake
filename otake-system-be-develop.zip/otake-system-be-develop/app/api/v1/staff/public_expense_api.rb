module V1
  module Staff
    class PublicExpenseApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :public_expenses do
          # index public expenses
          desc 'GET api/v1/staff/public_expenses'
          params do
            requires :patient_id, type: Integer, message: I18n.t('public_expense.error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @public_expenses = patient.public_expenses.default_order
            serialized_public_expenses = @public_expenses.map do |public_expense|
              PublicExpenseSerializer.new(public_expense).as_json
            end
            present :serialized_public_expenses, serialized_public_expenses
          end

          # Get PublicExpense detail
          desc 'GET api/v1/staff/public_expenses/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            @public_expense = PublicExpense.find(params[:id])
            present @public_expense
          end
        end
      end
    end
  end
end
