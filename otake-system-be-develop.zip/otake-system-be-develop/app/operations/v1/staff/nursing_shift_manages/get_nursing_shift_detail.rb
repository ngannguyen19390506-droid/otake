module V1
  module Staff
    module NursingShiftManages
      class GetNursingShiftDetail < ::ApplicationOperation
        def call(current_staff, params)
          next_month = params[:year_month].present? ? params[:year_month].to_date : Date.current.next_month
          year_month = next_month.strftime('%Y/%m')
          start_date = next_month.beginning_of_month
          end_date = next_month.end_of_month
          shifts = current_staff.nursing_shift_manages.includes(:shift)#.where(confirmed_by_admin: true, status: 'sent')
                                .where('shift_managements.shift_date BETWEEN :start_date AND :end_date', { start_date: start_date, end_date: end_date })
                                .order('shift_managements.shift_date asc')
          dates_working = current_staff.shifts.where(shift_date: start_date..end_date).pluck(:shift_date)
          staff_holidays_created_by_staff = current_staff.holidays.where(date: start_date..end_date, create_type: 'staff')
          has_initial, btn_adjustment_request_send = false, false
          monthly_holiday = current_staff.monthly_holidays.find_by(year_month: year_month)
          holidays = current_staff.holidays.where(date: start_date..end_date)
                                           .where.not(date: dates_working).map do |holiday|
                                             is_change = holiday.create_type == 'admin'
                                             {
                                               date: holiday.date,
                                               create_type: holiday.create_type,
                                               is_change: is_change
                                             }
                                           end
          shifts = shifts.map do |value|
                      shift = value.shift
                      is_changed = staff_holidays_created_by_staff.pluck(:date).include?(shift.shift_date)
                      revert_change = shift.previous_data.present? || value.status == 'initial'
                      btn_adjustment_request_send = true if revert_change
                      has_initial = true if (shift.previous_data.present? && shift.status == 'initial') || value.status == 'initial' && shift.status == 'initial'
                      {
                        id: value.id,
                        shift_date: shift.shift_date,
                        start_time: shift.start_time,
                        end_time: shift.end_time,
                        is_changed: is_changed,
                        revert_change: revert_change
                      }
          end
          confirmed_by_admin = monthly_holiday.present? ? monthly_holiday.confirmed_by_admin : false
          confirmed_by_staff = monthly_holiday.present? ? monthly_holiday.confirmed_by_staff : false
          data = {
            confirmed_by_admin: confirmed_by_admin,
            confirmed_by_staff: confirmed_by_staff,
            has_initial: has_initial,
            btn_adjustment_request_send: btn_adjustment_request_send,
            holidays: holidays,
            shifts: shifts
          }
          Success(data)
        end
      end
    end
  end
end
