module V1
  module Admin
    class ShiftStatusSerializer < ActiveModel::Serializer
      attributes :id, :year_month, :status
    end
  end
end
