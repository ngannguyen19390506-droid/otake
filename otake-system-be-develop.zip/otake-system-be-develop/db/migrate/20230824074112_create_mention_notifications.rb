class CreateMentionNotifications < ActiveRecord::Migration[7.0]
  def change
    create_table :mention_notifications do |t|
      t.string :name
      t.integer :m_id
      t.integer :notification_id

      t.timestamps
    end
  end
end
