module V1
  module Admin
    module NursingShiftManages
      class UpdateShift < ::ApplicationOperation
        def call(params)
          shifts = list_shift(params[:nurse_id], params[:current_shift_date], params[:action_update])
          ActiveRecord::Base.transaction do
            shifts.update_all('is_sent_for_staff = true') if params[:action_update] == 'send_shift'
            shifts.update_all('confirmed_by_admin = true') if params[:action_update] == 'confirm_shift'
          end
          Success(shifts)
        rescue StandardError => e
          Failure(e.message)
        end

        private

        def list_shift(nurse_id, current_shift_date, action_update)
          start_date = current_shift_date.to_date.beginning_of_month
          end_date = current_shift_date.to_date.end_of_month
          shifts = NursingShiftManage.joins(:shift).where(nurse_id: nurse_id)
                                     .where('shift_managements.shift_date BETWEEN :start_date AND :end_date',
                                            { start_date: start_date, end_date: end_date })

          return shifts.where(is_sent_for_staff: false) if action_update == 'send_shift'

          return shifts.where(is_sent_for_staff: true, confirmed_by_admin: true) if action_update == 'confirm_shift'
        end
      end
    end
  end
end
