# Otake System BE

# How to run this project

# Cp config/database.yml.example to config/database.yml
# Cp .env.example to .env

# How to build on staging environment
# Please build for env is staging, check at: config/environment/staging.rb
