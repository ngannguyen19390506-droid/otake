module V1
  module Admin
    class PaymentHistoryApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :payment_histories do
          # Create
          desc 'POST /api/v1/admin/payment_histories'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.')
            requires :year_month, type: String, message: I18n.t('error.validate.')
            requires :actual_date, type: String, message: I18n.t('error.validate.blank')
            requires :expected_date, type: String, message: I18n.t('error.validate.blank')
          end
          post do
            patient = Patient.includes(:equipment_service_payments, :patient_receipts).find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            equipment = patient.equipment_service_payments.find { |payment| payment.category == 'equipment' && payment.year_month == params[:year_month]}
            service = patient.equipment_service_payments.find { |payment| payment.category == 'service' && payment.year_month == params[:year_month]}
            potoro = patient.equipment_service_payments.find { |payment| payment.category == 'potoro' && payment.year_month == params[:year_month]}
            patient_receipt = patient.patient_receipts.find { |patient_receipt| patient_receipt.year_month == params[:year_month] }
            if (equipment.blank? || service.blank? || potoro.blank? || patient_receipt.blank?) ||
              !(equipment.registered && service.registered && potoro.registered && patient_receipt.registered)
              return error!({ 'messages': I18n.t('errors.messages.cannot_create_payment_history') }, UNPROCESSABLE_ENTITY)
            end

            payment_history = patient.payment_histories.find_by(year_month: params[:year_month])
            return error!({ 'messages': I18n.t('errors.messages.already_exists') }, UNPROCESSABLE_ENTITY) if payment_history.present?

            payment_history = PaymentHistory.new(params_payment_history)
            if payment_history.save
              { success: I18n.t('success.messages.added') }
            else
              error!(payment_history.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Update
          desc 'PUT /api/v1/admin/payment_histories/:id'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            optional :actual_date, type: String
            optional :expected_date, type: String
          end
          put do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            payment_history = patient.payment_histories.find_by(year_month: params[:year_month])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if payment_history.blank?

            if payment_history.update(params_payment_history)
              { success: I18n.t('success.messages.updated') }
            else
              error!(payment_history.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Detail
          desc 'GET /api/v1/admin/payment_histories/:id'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @payment_history = patient.payment_histories.find_by(year_month: params[:year_month])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @payment_history.blank?

            present @payment_history
          end
        end
      end

      helpers do
        def params_payment_history
          params_payment_history = params.slice(:actual_date, :expected_date, :year_month, :patient_id)
          params_payment_history[:actual_date] = convert_date(params_payment_history[:actual_date]) if params_payment_history[:actual_date].present?
          params_payment_history[:expected_date] = convert_date(params_payment_history[:expected_date]) if params_payment_history[:expected_date].present?
          params_payment_history
        end
      end
    end
  end
end
