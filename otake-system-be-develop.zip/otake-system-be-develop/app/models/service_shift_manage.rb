# == Schema Information
#
# Table name: service_shift_manages
#
#  id         :bigint           not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  service_id :bigint           not null
#  shift_id   :bigint           not null
#
# Indexes
#
#  index_service_shift_manages_on_service_id  (service_id)
#  index_service_shift_manages_on_shift_id    (shift_id)
#
# Foreign Keys
#
#  fk_rails_...  (service_id => services.id)
#  fk_rails_...  (shift_id => shift_managements.id)
#
class ServiceShiftManage < ApplicationRecord
  belongs_to :shift, class_name: 'ShiftManagement'
  belongs_to :service
end
