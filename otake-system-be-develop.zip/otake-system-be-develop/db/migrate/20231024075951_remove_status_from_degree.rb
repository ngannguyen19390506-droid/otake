class RemoveStatusFromDegree < ActiveRecord::Migration[7.0]
  def change
    remove_column :degrees, :status
  end
end
