module V1
  module Staff
    class PatientSerializer < ActiveModel::Serializer
      attributes :id,
                 :cellphone_number,
                 :telephone_number,
                 :birth_date,
                 :sex,
                 :last_name,
                 :first_name,
                 :last_name_kana,
                 :first_name_kana,
                 :zipcode,
                 :district,
                 :city,
                 :street,
                 :status,
                 :period_contract,
                 :current_illness_history,
                 :family_interview,
                 :personal_interview,
                 :patient_code,
                 :building_name,
                 :family_name,
                 :name_kana,
                 :equipent_payment,
                 :service_payment,
                 :potoro_payment,
                 :patient_receipt,
                 :can_implement_payment_history,
                 :payment_history,
                 :usage_billing_normal,
                 :usage_billing_disability,
                 :rent_billing,
                 :insurance_card,
                 :age,
                 :residence,
                 :hex_color,
                 :leave_date,
                 :home_care_support_office_name

      has_many :contact_relatives, serializer: ContactRelativeSerializer
      has_one :hospital, serializer: HospitalSerializer
      has_many :recipients, serializer: RecipientSerializer

      def initialize(patient, options = {})
        super(patient, options)
        @year_month_payment = options[:year_month_payment]
      end

      def equipent_payment
        payment_data('equipment')
      end

      def service_payment
        payment_data('service')
      end

      def potoro_payment
        payment_data('potoro')
      end

      def usage_billing_normal
        billing = object.usage_billings.nursing_care.find_by(year_month: @year_month_payment)
        billing_format_data(billing)
      end

      def usage_billing_disability
        billing = object.usage_billings.disability.find_by(year_month: @year_month_payment)
        billing_format_data(billing)
      end

      def rent_billing
        billing = object.rent_billings.find_by(year_month: @year_month_payment)
        billing_format_data(billing)
      end

      def payment_data(category)
        equipment_service_payment = object.equipment_service_payments.find { |payment| payment.category == category && payment.year_month == @year_month_payment }
        format_data(equipment_service_payment)
      end

      def can_implement_payment_history
        equipment = payment_data('equipment')
        service = payment_data('service')
        potoro = payment_data('potoro')
        patient_receipt = object.patient_receipts.find { |patient_receipt| patient_receipt.year_month == @year_month_payment }
        if (equipment.blank? || service.blank? || potoro.blank? || patient_receipt.blank?) ||
          !(equipment[:registered] && service[:registered] && potoro[:registered] && patient_receipt[:registered])
          return false
        end

        true
      end

      def payment_history
        payment_history = object.payment_histories.find { |payment_history| payment_history.year_month == @year_month_payment }
        return { status: '未入金', expected_date: "#{@year_month_payment}/20" } if payment_history.blank?

        PaymentHistorySerializer.new(payment_history).as_json
      end

      def patient_receipt
        patient_receipt = object.patient_receipts.find_by(year_month: @year_month_payment)
        format_data(patient_receipt)
      end

      def format_data(object)
        return nil if object.blank?

        {
          patient_id: object.patient_id,
          registered: object.registered,
          year_month: object.year_month
        }
      end

      def billing_format_data(object)
        return nil if object.blank?

        {
          patient_id: object.patient_id,
          year_month: object.year_month
        }
      end

      def insurance_card
        return nil if object.insurance_cards.blank?

        object.insurance_cards.default_order.first
      end

      def residence
        "#{object.district}市#{object.city}区"
      end
    end
  end
end
