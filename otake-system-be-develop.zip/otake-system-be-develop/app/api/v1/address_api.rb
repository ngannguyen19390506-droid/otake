module V1
  class AddressApi < V1::AppApi
    desc 'GET api/v1/districts'
    get :districts do
      districts = District.all

      serialized_districts = districts.map do |district|
        {
          id: district.id,
          name: district.name
        }
      end

      { districts: serialized_districts }
    end

    desc 'GET api/v1/cities'
    params do
      requires :district_name, type: String
    end
    get :cities do
      district = District.find_by(name: params[:district_name])
      return error!({ district_name: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if district.blank?

      cities = district.cities
      serialized_cities = cities.map do |city|
        {
          id: city.id,
          name: city.name
        }
      end

      { cities: serialized_cities }
    end

    desc 'GET api/v1/addresses'
    params do
      requires :district_name, type: String
      requires :city_name, type: String
    end
    get :addresses do
      district = District.find_by(name: params[:district_name])
      return error!({ district_name: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if district.blank?

      city = district.cities.find_by(name: params[:city_name])
      return error!({ city_name: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if city.blank?

      addresses = city.addresses
      serialized_addresses = addresses.map do |address|
        {
          id: address.id,
          name: address.name
        }
      end

      { addresses: serialized_addresses }
    end

    desc 'GET api/v1/post_code'
    params do
      requires :district_name, type: String
      requires :city_name, type: String
      requires :address_name, type: String
    end
    get :post_code do
      district = District.find_by(name: params[:district_name])
      return error!({ district_name: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if district.blank?

      city = district.cities.find_by(name: params[:city_name])
      return error!({ city_name: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if city.blank?

      address = city.addresses.find_by(name: params[:address_name])
      return error!({ address_name: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if address.blank?

      post_code = PostCode.find_by(address_id: address.id)
      return error!({ address_id: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if post_code.blank?

      formatted_post_code = post_code.code.gsub(/(\d{3})(\d{4})/, '\1-\2')
      { post_code: formatted_post_code }
    end

    desc 'GET api/v1/info_address_by_code'
    params do
      requires :code
    end
    get :info_address_by_code do
      code = params[:code].gsub('-', '')
      post_code = PostCode.find_by(code: code)
      return error!({ code: I18n.t('activerecord.errors.messages.not_found') }, NOT_FOUND) if post_code.blank?

      {
        info_address: post_code.as_json(
          except: [:created_at, :updated_at],
          include: {
            district: { only: [:id, :name] },
            city: { only: [:id, :name] },
            address: { only: [:id, :name] }
          }
        )
      }
    end
  end
end
