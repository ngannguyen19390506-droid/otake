module V1
  module AdminHomeSystem
    class MessageApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resource :rooms do
          desc 'GET api/v1/admin_home_system/rooms',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
            optional :search, type: String
            optional :unread, type: Boolean
          end
          get do
            page = (params[:page].presence || 1).to_i
            @query = Room.hs_admin_room_owner(@current_user.id).hs_only_unread(params[:unread], @current_user.id)
            if params[:search].present?
              user_ids = UserHomeSystem.ransack(user_name_cont: params[:search]).result.pluck(:id)
              @query = @query.where(source_id: user_ids, source_type: 'hs_admin')
                         .or(@query.where(target_id: user_ids, target_type: 'home_system_admin'))
                         .or(@query.where(source_id: user_ids, source_type: 'hs_staff'))
                         .or(@query.where(target_id: user_ids, target_type: 'home_system_staff'))
            end
            @rooms = @query.distinct.by_created_at_desc.page(page).per(params[:per])
            serialized_rooms = @rooms.map do |room|
              RoomSerializer.new(room, { params: { current_uid: @current_user.id } }).as_json
            end
            present :page, page
            present :total_page, @rooms.total_pages
            present :total_items, @rooms.total_count
            present :rooms, serialized_rooms
          end

          desc 'POST api/v1/admin_home_system/rooms',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :target_id, type: Integer
            requires :target_type, type: String, desc: 'home_system_admin / home_system_staff'
          end
          post do
            current_user_id = @current_user.id
            source_type = params[:target_type] == 'home_system_admin' ? 'hs_admin' : 'hs_staff'
            room = Room.where(source_id: current_user_id, source_type: 'hs_admin',
                              target_id: params[:target_id], target_type: params[:target_type])
                       .or(Room.where(target_id: current_user_id, target_type: 'home_system_admin',
                                      source_id: params[:target_id], source_type: source_type))
            return present room.first if room.present?

            conditions = { source_id: @current_user.id, source_type: 'hs_admin', target_id: params[:target_id], target_type: params[:target_type] }
            @room = Room.find_or_create_by(conditions)

            if @room.save
              present @room
            else
              error!(@room.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin_home_system/rooms/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
          end

          get ':id' do
            page = (params[:page].presence || 1).to_i
            @room = Room.find(params[:id])
            @messages = @room.messages.order(created_at: :desc).page(page).per(params[:per])
            serialized_messages = @messages.reverse.map do |message|
              MessageSerializer.new(message, { params: { current_uid: @current_user.id } }).as_json
            end
            present :page, page
            present :total_page, @messages.total_pages
            present :total_items, @messages.total_count
            present :messages, serialized_messages, instance_options: @current_user.id
          end

          desc 'Put api/v1/admin_home_system/rooms/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
          end

          put ':id' do
            room = Room.find(params[:id])
            receiver_type = @current_user.class.name.to_s
            room.messages.where(receiver_id: @current_user.id, read_at: nil, receiver_type: receiver_type)&.update_all(read_at: Time.current)
            { success: true }
          end

          route_param :id do
            resource :messages do
              desc 'POST api/v1/admin_home_system/rooms/:id/messages',
                   headers: {
                     'Authorization' => {
                       description: 'Ex: Bearer [your_token]',
                       required: true
                     }
                   }
              params do
                requires :id, type: Integer
                requires :content, type: String
              end
              post do
                @room = Room.find(params[:id])
                receiver_id = @room.target_id == @current_user.id ? @room.source_id : @room.target_id

                receiver_type = @current_user.class.name
                @message = @room.messages.new(content: params[:content], sender_id: @current_user.id,
                                              sender_type: @current_user.class.name,
                                              receiver_id: receiver_id, receiver_type: receiver_type)
                if @message.save
                  present @message
                else
                  error!(@message.error_messages, UNPROCESSABLE_ENTITY)
                end
              end
            end
          end
        end
      end
    end
  end
end
