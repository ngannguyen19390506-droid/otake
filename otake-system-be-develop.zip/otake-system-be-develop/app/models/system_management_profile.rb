# == Schema Information
#
# Table name: system_management_profiles
#
#  id                             :bigint           not null, primary key
#  building_name                  :string
#  business_number                :string
#  city                           :string           not null
#  day_payment                    :integer
#  district                       :string           not null
#  facility_name                  :string           not null
#  fax                            :string
#  grade_registration             :string
#  mobile_phone                   :string
#  rate_registration              :string
#  rate_registration_disability   :float
#  rate_registration_nursing_care :float
#  street                         :string           not null
#  zipcode                        :string           not null
#  created_at                     :datetime         not null
#  updated_at                     :datetime         not null
#
class SystemManagementProfile < ApplicationRecord
  include ApiCommon

  # validates :facility_name, :zipcode, :district, :city, :street, :mobile_phone, presence: true
  validates :rate_registration, numericality: true, if: -> { rate_registration.present? }
end
