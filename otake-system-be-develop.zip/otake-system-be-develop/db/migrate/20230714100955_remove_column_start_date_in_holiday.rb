class RemoveColumnStartDateInHoliday < ActiveRecord::Migration[7.0]
  def change
    remove_column :holidays, :start_date
  end
end
