class CreateRoom < ActiveRecord::Migration[7.0]
  def change
    create_table :rooms do |t|
      t.references :patient, null: false, foreign_key: true
      t.references :nurse,   null: false, foreign_key: { to_table: :nursing_staffs }
      t.string     :code,    null: false

      t.timestamps
    end
  end
end
