class CreateNursingHoliday < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_holidays do |t|
      t.references :nurse,   null: false, foreign_key: { to_table: :nursing_staffs }
      t.references :holiday, null: false, foreign_key: true

      t.timestamps
    end
  end
end

