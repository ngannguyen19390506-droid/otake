module V1
  module Staff
    class RoomSerializer < ActiveModel::Serializer
      attributes :id,
                 :target_id,
                 :source_id,
                 :lastest_send_at,
                 :is_unread,
                 :source_type,
                 :target_type,
                 :source,
                 :target,
                 :latest_msg

      def lastest_send_at
        if object&.messages&.count&.positive?
          object.messages.last.created_at.strftime('%Y/%m/%d %H:%M')
        else
          object.created_at.strftime('%Y/%m/%d %H:%M')
        end
      end

      def latest_msg
        object.messages.by_created_at_desc.first
      end

      def is_unread
        object.messages.where(read_at: nil, receiver_type: 'NursingStaff', receiver_id: current_uid).present?
      end

      def source
        source_id = object.source_id
        if object.admin?
          source = UserAdmin.find_by(id: source_id)
          source&.attributes&.except("encrypted_password").merge!({ family_name: source.user_name })
        else
          source = NursingStaff.find_by(id: source_id)
          source&.attributes&.except("encrypted_password")
        end
      end

      def target
        target_id = object.target_id
        if object.user_admin?
          target = UserAdmin.find_by(id: target_id)
          target&.attributes&.except("encrypted_password").merge!({ family_name: target.user_name })
        else
          target = NursingStaff.find_by(id: target_id)
          target&.attributes&.except("encrypted_password")
        end
      end

      def current_uid
        @instance_options[:params][:current_uid]
      end
    end
  end
end
