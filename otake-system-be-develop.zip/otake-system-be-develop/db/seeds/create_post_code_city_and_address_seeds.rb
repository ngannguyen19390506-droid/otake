puts "Start time import postcode: #{DateTime.now}"

require 'csv'
ActiveRecord::Base.transaction do
	csv_file_path = File.join(Rails.root, 'db', 'data', 'postcode.csv')
	CSV.foreach(csv_file_path) do |row|
		zipcode = row[2]
		district_name = row[6]
		city_name = row[7]
		address_name = row[8] == '以下に掲載がない場合' ? '未定義' : row[8]
		district = District.find_by(name: district_name)

		city = district.cities.find_by(name: city_name)
		city_id = city&.id
		if city.blank?
			city = City.create(district_id: district.id, name: city_name)
			city_id = city.id
		end

		address = city.addresses.find_by(name: address_name)
		address_id = address&.id
		if address.blank?
			address = Address.create(city_id: city.id, name: address_name)
			address_id = address.id
		end
		next if PostCode.find_by(code: zipcode).present?

		PostCode.create!(
			city_id: city_id,
			address_id: address_id,
			district_id: district.id,
			code:  zipcode
		)
		puts "Completed: #{row}"
	end
rescue StandardError => e
	e
end

puts "End time import postcode: #{DateTime.now}"
