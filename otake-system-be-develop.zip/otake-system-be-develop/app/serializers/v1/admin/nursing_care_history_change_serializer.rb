module V1
  module Admin
    class NursingCareHistoryChangeSerializer < ActiveModel::Serializer
      attributes :id,
                 :patient_id,
                 :nurse_id,
                 :division,
                 :defecation,
                 :full_body_bath,
                 :complexion,
                 :sweating,
                 :environmental_arrangement,
                 :consultation_assistance,
                 :note,
                 :toilet_assistance,
                 :diaper_check,
                 :pad_confirmation,
                 :urination,
                 :urinal_cleaning,
                 :maintain_posture,
                 :hydration,
                 :eating_assistance,
                 :cleaning,
                 :full_body_bath_procedure,
                 :washing_hair,
                 :washbasin,
                 :oral_care,
                 :dressing_assistance,
                 :position_exchange,
                 :transfer_assistance,
                 :watch_over,
                 :schedule_date_id,
                 :service_id,
                 :service_type_id,
                 :start_time,
                 :end_time,
                 :start_time_format,
                 :end_time_format,
                 :physical_care,
                 :record,
                 :created_at,
                 :updated_at,
                 :blood_pressure,
                 :temperature,
                 :updated_time

      belongs_to :nurse, class_name: 'NursingStaff', serializer: NursingStaffSerializer
      belongs_to :patient, serializer: PatientSerializer
      belongs_to :schedule_date, serializer: ScheduleDateSerializer
      belongs_to :service, serializer: ServiceSerializer
      belongs_to :service_type, serializer: ServiceTypeSerializer
    end
  end
end
