class CreateNursingCarePlanServiceType < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_care_plan_service_types do |t|
      t.references :nursing_care,    null: false, foreign_key: { to_table: :nursing_care_plans }
      t.references :service_type,    null: false, foreign_key: true

      t.timestamps
    end
  end
end
