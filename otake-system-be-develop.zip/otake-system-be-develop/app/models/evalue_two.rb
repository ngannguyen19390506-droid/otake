# == Schema Information
#
# Table name: evalue_twos
#
#  id                          :bigint           not null, primary key
#  allergy_opt                 :integer
#  allergy_txt                 :text
#  assistance_opt              :integer
#  assistance_txt              :text
#  attaching_and_detaching_opt :integer
#  attaching_and_detaching_txt :text
#  chew_opt                    :integer
#  chew_txt                    :text
#  convenience_opt             :integer
#  convenience_txt             :text
#  created_date                :date
#  delusion_opt                :integer
#  delusion_txt                :text
#  denture_opt                 :text
#  denture_txt                 :text
#  dosage_opt                  :integer
#  dosage_txt                  :text
#  excretion_form_opt          :text
#  excretion_form_txt          :text
#  expression_of_meaning_opt   :integer
#  expression_of_meaning_txt   :text
#  eyesight_opt                :integer
#  eyesight_txt                :text
#  glasses_opt                 :integer
#  glasses_txt                 :text
#  hair_washing_opt            :integer
#  hair_washing_txt            :text
#  head_opt                    :text
#  head_txt                    :text
#  hearing_opt                 :integer
#  hearing_txt                 :text
#  hip_joint_opt               :text
#  hip_joint_txt               :text
#  hobby_goods_opt             :text
#  hobby_goods_txt             :text
#  incontinence_opt            :integer
#  incontinence_txt            :text
#  language_opt                :integer
#  language_txt                :text
#  lower_limbs_opt             :text
#  lower_limbs_txt             :text
#  morphology_opt              :text
#  morphology_txt              :text
#  move_opt                    :integer
#  move_txt                    :text
#  plastic_surgery_opt         :integer
#  plastic_surgery_txt         :text
#  rejection_opt               :integer
#  rejection_txt               :text
#  seat_opt                    :integer
#  seat_txt                    :text
#  side_dish_opt               :text
#  side_dish_txt               :text
#  standing_position_opt       :integer
#  standing_position_txt       :text
#  staple_food_opt             :text
#  staple_food_txt             :text
#  swallowing_opt              :integer
#  swallowing_txt              :text
#  thoromi_opt                 :integer
#  thoromi_txt                 :text
#  tool_opt                    :text
#  tool_txt                    :text
#  treatment_opt               :integer
#  treatment_txt               :text
#  understand_opt              :integer
#  understand_txt              :text
#  understanding_opt           :integer
#  understanding_txt           :text
#  upper_limbs_opt             :text
#  upper_limbs_txt             :text
#  urge_to_urinate_opt         :integer
#  urge_to_urinate_txt         :text
#  violence_opt                :integer
#  violence_txt                :text
#  waist_opt                   :text
#  waist_txt                   :text
#  wander_opt                  :integer
#  wander_txt                  :text
#  wash_body_opt               :integer
#  wash_body_txt               :text
#  created_at                  :datetime         not null
#  updated_at                  :datetime         not null
#  patient_id                  :bigint           not null
#
# Indexes
#
#  index_evalue_twos_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class EvalueTwo < ApplicationRecord
  include ApiCommon

  belongs_to :patient

  # independence: 自立, supervision: 見守り, partial_assistance: 一部介助, full_assistance: 全介助
  enum thoromi_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum assistance_opt:  { independence: 0, supervision: 1, partial_assistance: 2, full_assistance: 3 }, _prefix: true
  enum allergy_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum eyesight_opt: { with_disability: 0, none: 1}, _prefix: true #障害あり:0 なし:1
  enum glasses_opt: { with_disability: 0, none: 1}, _prefix: true #障害あり:0 なし:1
  enum hearing_opt: { with_disability: 0, none: 1}, _prefix: true #障害あり:0 なし:1
  enum language_opt: { with_disability: 0, none: 1}, _prefix: true #障害あり:0 なし:1
  enum move_opt: { independence: 0, supervision: 1, partial_assistance: 2, full_assistance: 3 }, _prefix: true
  enum standing_position_opt: { independence: 0, supervision: 1, partial_assistance: 2, full_assistance: 3 }, _prefix: true
  enum seat_opt: { independence: 0, supervision: 1, partial_assistance: 2, full_assistance: 3 }, _prefix: true
  enum wash_body_opt: { independence: 0, partial_assistance: 1, full_assistance: 2 }, _prefix: true
  enum hair_washing_opt: { independence: 0, partial_assistance: 1, full_assistance: 2 }, _prefix: true
  enum attaching_and_detaching_opt: { independence: 0, partial_assistance: 1, full_assistance: 2 }, _prefix: true
  enum plastic_surgery_opt: { independence: 0, partial_assistance: 1, full_assistance: 2 }, _prefix: true
  enum urge_to_urinate_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum convenience_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum incontinence_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum chew_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum swallowing_opt: { normal: 0, difficult: 1}, _prefix: true #正常:0  困難:1
  enum understanding_opt: { mild: 0, moderate: 1, severe: 2, none: 3}, _prefix:true #軽度:0 中度:1 重度:2 なし:3
  enum expression_of_meaning_opt: { possible: 0, impossible: 1 }, _prefix: true #可能:0 不可能:1
  enum understand_opt: { possible: 0, impossible: 1 }, _prefix: true #可能:0 不可能:1
  enum wander_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum violence_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum delusion_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum rejection_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum treatment_opt: { can_be: 0, none: 1 }, _prefix: true #あり:0 なし:1
  enum dosage_opt: { independence: 0, supervision: 1, partial_assistance: 2, full_assistance: 3 }, _prefix: true
end
