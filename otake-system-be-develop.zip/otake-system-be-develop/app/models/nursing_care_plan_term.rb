# == Schema Information
#
# Table name: nursing_care_plan_terms
#
#  id                   :bigint           not null, primary key
#  plan_type            :integer
#  term_goal            :string
#  created_at           :datetime         not null
#  updated_at           :datetime         not null
#  nursing_care_plan_id :integer          not null
#
class NursingCarePlanTerm < ApplicationRecord
  belongs_to :nursing_care_plan

  enum plan_type: { short_term: 1, long_term: 2 }
end
