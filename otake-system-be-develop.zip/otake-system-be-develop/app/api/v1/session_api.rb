module V1
  class SessionApi < V1::AppApi
    desc 'POST api/v1/login'
    params do
      requires :email, type: String
      requires :password, type: String
    end
    post :login do
      begin
        user = User.find_by(email: params[:email])
        if user&.valid_password?(params[:password])
          token = user.generate_jwt
          { access_token: token }
        else
          error!(I18n.t('login.error.username_password.invalid'), UNAUTHORIZED)
        end
      rescue StandardError => e
        error!(e.message, UNAUTHORIZED)
      end
    end

    desc 'POST api/v1/reset_password'
    params do
      requires :email, type: String
    end
    post :reset_password do
      begin
        user = User.find_by(email: params[:email])
        if user
          ResetPasswordJob.perform_later(user)
          { processed: true }
        else
          error!(I18n.t('forgot_password.error.username.invalid'), NOT_FOUND)
        end
      rescue StandardError => e
        error!(e.message, INTERNAL_SERVER_ERROR)
      end
    end

    desc 'put api/v1/update_password'
    params do
      requires :password, type: String, message: I18n.t('change_password.error.password_blank')
      requires :token, type: String, message: I18n.t('change_password.error.token_blank')
    end
    put :update_password do
      begin
        token = Devise.token_generator.digest(User, :reset_password_token, params[:token])
        user = User.find_by(reset_password_token: token)
        if user.present?
          if (Time.current.to_i - user.reset_password_sent_at.to_i) < User::VALID_RESET_PW_TOKEN_TIME
            user.update(password: params[:password])
            { processed: true }
          else
            error!(I18n.t('change_password.error.token_expired'), NOT_FOUND)
          end
        else
          error!(I18n.t('change_password.error.token_invalid'), NOT_FOUND)
        end
      rescue StandardError => e
        error!(e.message, INTERNAL_SERVER_ERROR)
      end
    end

    desc 'DELETE api/v1/logout'
    delete :logout do
      authenticate!
      begin
        AuthenticationToken.authenticate(@token).destroy
        { processed: true }
      rescue StandardError => e
        error!(e.message, INTERNAL_SERVER_ERROR)
      end
    end

    desc 'GET api/v1/me',
         headers: {
           'Authorization' => {
             description: 'Ex: Bearer [your_token]',
             required: true
           }
         }
    get :me do
      begin
        token = request.headers['Authorization'].scan(/Bearer (.*)$/).flatten.last.to_s
        data = JWT.decode(token, ENV['SECRET_KEY_BASE'] || Rails.application.secrets.secret_key_base)
        return 'not found' if data.blank?

        user_code = data[0]['code']
        data_role = data[0]['role']
        user_info = case data_role
                    when 'admin'
                      role_cls = 'UserAdmin'
                      user = UserAdmin.find_by(user_code: user_code)
                      message = Message.where(receiver_id: user&.id, receiver_type: role_cls, read_at: nil)
                      notice_viewed = NotificationViewLog.where(viewer_id: user&.id, viewer_type: role_cls).pluck(:notification_id).uniq
                      notifications = Notification.noti_by_admin.or(Notification.noti_by_staff).where.not(id: notice_viewed)
                      { id: user&.id, name: user&.user_name, role: data_role, code: user_code, data_role_cls: role_cls,
                        is_notice_unread: notifications.present?, is_message_unread: message.present? }
                    when 'staff'
                      role_cls = 'NursingStaff'
                      staff = NursingStaff.find_by(nurse_code: user_code)
                      notice_viewed = NotificationViewLog.where(viewer_id: staff.id, viewer_type: role_cls).pluck(:notification_id).uniq
                      notifications = Notification.noti_by_admin.or(Notification.noti_by_staff).where.not(id: notice_viewed)
                      message = Message.where(receiver_id: staff.id, receiver_type: role_cls, read_at: nil)
                      { id: staff&.id, name: staff&.family_name, role: data_role, code: user_code, data_role_cls: role_cls,
                        is_notice_unread: notifications.present?, is_message_unread: message.present? }
                    when 'admin_home_system', 'staff_home_system'
                      role_cls = 'UserHomeSystem'
                      user = UserHomeSystem.find_by(user_code: user_code)
                      { id: user.id, name: user&.user_name, role: data_role, code: user_code, data_role_cls: role_cls }
                    else
                      client = Patient.find_by(patient_code: user_code)
                      { id: client&.id, name: client&.family_name, role: data_role, code: user_code, data_role_cls: 'Patient', is_notice_unread: false, is_message_unread: false }
                    end
        user_info
      rescue StandardError => e
        error!(e.message, UNAUTHORIZED)
      end
    end
  end
end
