module V1
  module Admin
    class BranchInfoSerializer < ActiveModel::Serializer
      attributes :id, :branch_name, :branch_name_kana, :branch_code, :branch_name_search

      def branch_name_search
        "#{object.branch_name}(#{object.branch_code})"
      end
    end
  end
end
