module V1
  module Admin
    class ScheduleApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :schedules do
          # post Schedule
          desc 'POST /api/v1/admin/schedules'
          params do
            requires :date, type: String, message: I18n.t('error.validate.blank')
            requires :time_range, type: String, message: I18n.t('error.validate.blank')
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :nurse_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :service_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :service_type_id, type: Integer, message: I18n.t('error.validate.blank')
          end

          post do
            check_nursing_shift_manage_confirmation
            beginning_of_next_month = Date.current.next_month.at_beginning_of_month
            end_of_next_month = Date.current.next_month.end_of_month
            converted_date = convert_date(params[:date])
            if (beginning_of_next_month..end_of_next_month).exclude?(converted_date.to_date)
              return error!({ message: I18n.t('errors.messages.invalid_dates') }, UNPROCESSABLE_ENTITY)
            end
            ActiveRecord::Base.transaction do
              time_range = params[:time_range].split('~').map(&:strip) # time_range = 08:00 ~ 09:00
              start_time = time_range[0]
              end_time = time_range[1]
              patient = Patient.find_by(id: params[:patient_id])
              return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

              service = Service.find_by(id: params[:service_id])
              return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service.blank?

              service_type = ServiceType.find_by(id: params[:service_type_id])
              return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_type.blank?

              nursing_staff = NursingStaff.find_by(id: params[:nurse_id])
              return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_staff.blank?

              working_nurse_ids = ScheduleDate.where(date: converted_date, start_time: start_time, end_time: end_time).pluck(:nurse_id)
              available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(converted_date, start_time, end_time)
              if working_nurse_ids.include?(params[:nurse_id]) || available_nurse_ids.exclude?(params[:nurse_id])
                return error!({ 'message': I18n.t('errors.messages.nurse_is_busy') },
                              UNPROCESSABLE_ENTITY)
              end
              schedule = patient.schedules.includes(:schedule_dates).where(schedule_dates: { date: converted_date, start_time: start_time, end_time: end_time })
                                                                    .find_by(service_id: params[:service_id], service_type_id: params[:service_type_id])
              return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule.blank?

              schedule_date = schedule.schedule_dates.find_by(date: converted_date, start_time: start_time, end_time: end_time)
              if schedule_date.update(nurse_id: params[:nurse_id])
                { success: I18n.t('success.messages.added') }
              else
                error!(schedule_date.error_messages, UNPROCESSABLE_ENTITY)
              end
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET /api/v1/admin/schedules/nursing_staffs'
          params do
            requires :date, type: String, message: I18n.t('error.validate.blank')
            requires :time_range, type: String, message: I18n.t('error.validate.blank')
            optional :schedule_date_id, type: Integer
          end
          get 'nursing_staffs' do
            time_range = params[:time_range].split('~').map(&:strip) # time_range = 08:00 ~ 09:00
            start_time = time_range[0]
            end_time = time_range[1]
            converted_date = convert_date(params[:date])
            working_nurse_ids = if params[:schedule_date_id].present?
                                  ScheduleDate.where.not(id: params[:schedule_date_id]).for_working_nurses_on_date(converted_date, start_time, end_time).pluck(:nurse_id)
                                else
                                  ScheduleDate.for_working_nurses_on_date(converted_date, start_time, end_time).pluck(:nurse_id)
                                end
            available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(converted_date, start_time, end_time)
            @nursing_staffs = NursingStaff.where(id: available_nurse_ids)
                                          .where.not(id: working_nurse_ids)
                                          .includes(:degrees, nursing_shift_manages: :shift)
                                          .active

            serialized_nursing_staffs = @nursing_staffs.map do |nursing_staff|
              NursingStaffSerializer.new(nursing_staff).as_json
            end
            present :nursing_staffs, serialized_nursing_staffs
          end

          # Get schedule detail
          desc 'GET api/v1/admin/schedules/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
            optional :schedule_date, type: Date
            optional :time_range, type: String
          end
          get ':id' do
            schedule = Schedule.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if schedule.blank?
            return present schedule if params[:schedule_date].blank? && params[:time_range].blank?

            schedule_serializer = ScheduleSerializer.new(schedule, { schedule_date: params[:schedule_date], time_range: params[:time_range] }).as_json
            present schedule_serializer
          end

          desc 'GET api/v1/admin/schedules'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :date, type: Date, message: I18n.t('error.validate.blank')
            optional :time_range, type: String
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            converted_date = convert_date(params[:date])
            schedule_dates = patient.schedule_dates.where(date: converted_date, nurse_id: nil)
            time_range = params[:time_range]&.split('~')&.map(&:strip) # time_range = 08:00 ~ 09:00
            if time_range.present?
              start_time = time_range[0]
              end_time = time_range[1]
              schedule_date = schedule_dates.find_by(start_time: start_time, end_time: end_time)
              return present schedule_date
            end

            present schedule_dates
          end

          desc 'PUT api/v1/admin/schedules'
          params do
            requires :button_type, type: String, values: %w[cancel draft sent approved], message: I18n.t('nursing_shift_manage.error.validate.blank')
            optional :schedule_dates, type: Array do
              optional :id, type: Integer
              optional :start_time, type: String
              optional :end_time, type: String
              optional :delete, type: Boolean
            end
          end
          put do
            check_nursing_shift_manage_confirmation
            next_month = Date.current.next_month
            year_month = next_month.strftime('%Y/%m')
            beginning_of_next_month = next_month.at_beginning_of_month
            end_of_next_month = next_month.end_of_month
            ActiveRecord::Base.transaction do
              if params[:schedule_dates].present? && params[:button_type] == 'draft'
                params[:schedule_dates].each do |parms_sd|
                  schedule_date = ScheduleDate.find(parms_sd[:id])
                  if (beginning_of_next_month..end_of_next_month).exclude?(schedule_date.date)
                    return error!({ message: I18n.t('errors.messages.invalid_dates') }, UNPROCESSABLE_ENTITY)
                  end

                  if parms_sd[:delete]
                    schedule_date.destroy
                    schedule_date.scheduleable.destroy if schedule_date.scheduleable.schedule_dates.blank?
                  else
                    next if schedule_date.start_time == parms_sd[:start_time] && schedule_date.end_time == parms_sd[:end_time]

                    schedule = schedule_date.scheduleable
                    if schedule_date.scheduleable.schedule_dates.count == 1
                      schedule = schedule.care_plan.schedules.includes(:schedule_dates)
                                         .where(service_id: schedule.service_id, service_type_id: schedule.service_type_id)
                                         .find_by(schedule_dates: { start_time: parms_sd[:start_time], end_time: parms_sd[:end_time] })

                      if schedule.present?
                        scheduleable_before_update = schedule_date.scheduleable
                        schedule_date.update(start_time: parms_sd[:start_time], end_time: parms_sd[:end_time], scheduleable_id: schedule.id)
                        scheduleable_before_update.destroy if scheduleable_before_update.schedule_dates.blank?
                      else
                        schedule_date.update(start_time: parms_sd[:start_time], end_time: parms_sd[:end_time])
                      end
                    else
                      schedule = schedule_date.scheduleable.dup
                      schedule.save
                      schedule_date_dup = schedule_date.dup
                      schedule_date_dup.update(scheduleable_id: schedule.id, start_time: parms_sd[:start_time], end_time: parms_sd[:end_time])
                      schedule_date.destroy
                      parms_sd[:id] = schedule_date_dup.id
                    end
                  end
                end
                params[:schedule_dates].each do |parms_sd|
                  next if parms_sd[:delete]

                  schedule_date = ScheduleDate.includes(:scheduleable).find(parms_sd[:id])
                  schedule = schedule_date.scheduleable
                  schedule_dates_by_time = schedule.patient.schedule_dates.where(date: schedule_date.date, start_time: parms_sd[:start_time]...parms_sd[:end_time])
                  return error!({ 'message': I18n.t('errors.messages.caregiving_time_slot_already_allocated') }, UNPROCESSABLE_ENTITY) if schedule_dates_by_time.count > 1

                  if schedule_date.nurse
                    working_nurse_ids = ScheduleDate.where.not(nurse_id: schedule_date.nurse_id).for_working_nurses_on_date(schedule_date.date, parms_sd[:start_time], parms_sd[:end_time]).pluck(:nurse_id)
                    available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(schedule_date.date, parms_sd[:start_time], parms_sd[:end_time])
                    nursing_staffs = NursingStaff.where(id: available_nurse_ids)
                                                 .where.not(id: working_nurse_ids)
                                                 .includes(:degrees, nursing_shift_manages: :shift)
                                                 .active

                    if nursing_staffs.include?(schedule_date.nurse)
                      schedule_date.update(start_time: parms_sd[:start_time], end_time: parms_sd[:end_time])
                    else
                      return error!({ 'message': I18n.t('errors.messages.nurse_is_busy') }, UNPROCESSABLE_ENTITY)
                    end
                  end
                end
              end

              if params[:button_type] == 'cancel'
                ScheduleDate.where(status: 'initial', date: beginning_of_next_month..end_of_next_month).where.not(previous_data: nil).each do |schedule_date|
                  schedule_date.update(schedule_date.previous_data)
                end
                ScheduleDate.where(status: 'initial', date: beginning_of_next_month..end_of_next_month).update_all(nurse_id: nil)
              elsif params[:button_type] == 'draft'
                ScheduleDate.where(status: 'initial', date: beginning_of_next_month..end_of_next_month).where.not(nurse: nil).update_all(status: 'draft', previous_data: nil)
              elsif params[:button_type] == 'sent'
                nursing_shifts = NursingShiftManage.includes(:shift)
                                                  .where(shift: { shift_date: beginning_of_next_month..end_of_next_month })
                                                  .where(status: 'draft')
                # Create notification
                staff_ids = nursing_shifts.pluck(:nurse_id).uniq
                create_noti(staff_ids, year_month, params[:button_type])

                nursing_shifts&.update_all(status: 'sent', confirmed_by_admin: true)
                ScheduleDate.where(status: 'draft', date: beginning_of_next_month..end_of_next_month)
                            .where.not(nurse: nil)&.update_all(status: 'sent', previous_data: nil)

                sent_shifts()
              else # approved
                ScheduleDate.where(date: beginning_of_next_month..end_of_next_month).update_all(status: 'sent')
                MonthlyHoliday.where(year_month: year_month).update_all(confirmed_by_admin: true, confirmed_by_staff: true, status: 'approved')
                nursing_shifts = NursingShiftManage.includes(:shift).where(shift: { shift_date: beginning_of_next_month..end_of_next_month })
                # Create notification
                staff_ids = nursing_shifts.pluck(:nurse_id).uniq
                create_noti(staff_ids, year_month, params[:button_type])

                nursing_shifts = nursing_shifts.update_all(status: 'approved', confirmed_by_admin: true, confirmed_by_staff: true)
              end

              { success: I18n.t('success.messages.updated') }
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end
        end

        helpers do
          def params_schedule_date
            params.slice(:date, :start_time, :end_time, :nurse_id)
          end

          def params_schedule
            params.slice(:patient_id, :service_id, :service_type_id).merge!(total_number_of_times: 1)
          end

          def check_nursing_shift_manage_confirmation
            year_month = Date.current.next_month.strftime('%Y/%m')
            staffs_acitve = NursingStaff.active
            monthly_holidays = MonthlyHoliday.where(year_month: year_month)
            return error!(I18n.t('errors.messages.wait_for_staff_send_shift'), UNPROCESSABLE_ENTITY) if monthly_holidays.count < staffs_acitve.count

            confirmed_by_staff = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_staff: false)
            return error!(I18n.t('errors.messages.wait_for_staff_confirmation'), UNPROCESSABLE_ENTITY) if confirmed_by_staff.present?

            confirmed_by_staff_and_admin = MonthlyHoliday.where(year_month: year_month, status: 'approved')
            error!(I18n.t('errors.messages.shift_finalized'), UNPROCESSABLE_ENTITY) if confirmed_by_staff_and_admin.present?
          end

          def noti_title year_month, button_type
            case button_type
            when 'sent'
              "タイトル：#{year_month}のシフトを送信しました。"
            when 'approved'
              "タイトル：#{year_month}のシフトを確定しました。"
            end
          end

          def noti_content year_month, button_type
            case button_type
            when 'sent'
              "<p>#{year_month}のシフトを送信しました。</p>
              <p>各自、シフトの確認をお願いします。</p>
              <p>リンク先URL #{ENV['FE_APP_URL']}/staff/month-shift-after</p>"
            when 'approved'
              "<p>#{year_month}のシフトを確定しました。</p>
              <p>リンク先URL #{ENV['FE_APP_URL']}/staff/visit-schedule</p>"
            end
          end

          def create_noti staff_ids = [], date = Date.today, button_type
            return if staff_ids.blank?

            year_month = date.to_date.strftime('%Y年%m月')
            notification = Notification.create!(title: noti_title(year_month, button_type), content: noti_content(year_month, button_type),
                                              poster: @current_user.user_name || 'Admin', is_important: true, notify_type: 2,
                                              sender_id: @current_user.id, sender_type: @current_user.class.name)
            staff_ids.each do |uid|
              notification.mention_notifications.create!(m_id: uid, mention_type: 'NursingStaff')
            end
          end
        end
      end
    end
  end
end
