# == Schema Information
#
# Table name: cities
#
#  id          :bigint           not null, primary key
#  name        :string           not null
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  district_id :bigint           not null
#
# Indexes
#
#  index_cities_on_district_id  (district_id)
#
# Foreign Keys
#
#  fk_rails_...  (district_id => districts.id)
#
class City < ApplicationRecord
  include ApiCommon

  has_many :addresses, dependent: :destroy
  belongs_to :district
end
