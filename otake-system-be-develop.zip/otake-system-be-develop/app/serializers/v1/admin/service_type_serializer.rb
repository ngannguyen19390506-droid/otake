module V1
  module Admin
    class ServiceTypeSerializer < ActiveModel::Serializer
      attributes :id, :detail
    end
  end
end
