# == Schema Information
#
# Table name: disability_care_plans
#
#  id                          :bigint           not null, primary key
#  aid_purpose                 :text
#  comprehensive_aid_policy    :text
#  end_long_term               :date
#  end_short_term              :date
#  individual_family_intention :text
#  note                        :text
#  remarks                     :text
#  start_long_term             :date
#  start_short_term            :date
#  year_month                  :string
#  created_at                  :datetime         not null
#  updated_at                  :datetime         not null
#  patient_id                  :bigint           not null
#
# Indexes
#
#  index_disability_care_plans_on_patient_id  (patient_id)
#
class DisabilityCarePlan < ApplicationRecord
  include ApiCommon

  belongs_to :patient

  has_many :schedules, as: :care_plan, dependent: :destroy
  has_many :improvement_nursing_care_plans, as: :care_plan
  has_many :treatment_improvements, through: :improvement_nursing_care_plans
  has_many :schedule_dates, through: :schedules, source: :schedule_dates
  has_many :disability_care_plan_terms, dependent: :destroy
  has_many :change_histories, as: :changeable, dependent: :destroy

  validates :year_month, presence: true, format: { with: YEAR_MONTH, message: I18n.t('errors.messages.year_month_format_invalid') }

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      all_changes = extract_changes_without_timestamps(previous_changes)
      all_changes.each do |changed_attribute, (before_value, after_value)|
        text_description = I18n.t("attribute_description.disability_care_plan.#{changed_attribute}")
        create_change_history(user_admin_id, text_description, before_value, after_value)
      end
    rescue StandardError => e
      e
    end
  end
end
