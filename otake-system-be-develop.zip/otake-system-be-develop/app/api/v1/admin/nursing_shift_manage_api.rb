module V1
  module Admin
    class NursingShiftManageApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :nursing_shift_manages do
          desc 'GET api/v1/admin/nursing_shift_manages/summary'
          params do
            requires :tab, type: String, values: %w[client staff], message: I18n.t('nursing_shift_manage.error.validate.blank')
            optional :month_date, type: String
            optional :week_start_date, type: Date
            optional :week_end_date, type: Date
            optional :specific_date, type: Date
          end
          get :summary do
            year_month = if params[:month_date].present?
                           Date.parse(params[:month_date]).strftime('%Y/%m')
                         elsif params[:week_start_date].present? && params[:week_end_date].present?
                           params[:week_start_date].strftime('%Y/%m')
                         elsif params[:specific_date]
                           params[:specific_date].strftime('%Y/%m')
                         end
            next_year_month = Date.current.next_month.strftime('%Y/%m')
            staffs_active = NursingStaff.active
            monthly_holidays = MonthlyHoliday.where(year_month: year_month)
            # if monthly_holidays.blank? || monthly_holidays.pluck(:status).exclude?('initial') && year_month < next_year_month ||
            # Re-add after staff page implement
            if monthly_holidays.blank? ||
              (monthly_holidays.pluck(:status).exclude?('initial') && year_month < next_year_month) ||
              (year_month == next_year_month && monthly_holidays.count < staffs_active.count)
              return { data: {} }
            end

            V1::Admin::NursingShiftManages::GetNursingShiftSummary.call(params)
          end

          desc 'GET api/v1/admin/nursing_shift_manages/'
          params do
            requires :start_date, type: DateTime, default: Date.current.beginning_of_month
            requires :end_date, type: DateTime, default: Date.current.end_of_month
          end
          get do
            if (params[:end_date] - params[:start_date]) > 31.days
              return error!(I18n.t('errors.messages.invalid'),
                            UNPROCESSABLE_ENTITY)
            end
            shifts = ShiftManagement.where(shift_date: [params[:start_date]..params[:end_date]])
            shifts = shifts.includes(:services, :nurses, :patients)
            serialized_shifts = shifts.map do |shift|
              ShiftManagementSerializer.new(shift).as_json
            end
            present :shift_managements, serialized_shifts
          end

          desc 'POST api/v1/admin/nursing_shift_manages'
          params do
            requires :nurse_id, type: Integer, message: I18n.t('nursing_shift_manage.error.validate.blank')
            optional :start_time, type: String
            optional :end_time, type: String
            requires :dates, type: Array[String], message: I18n.t('nursing_shift_manage.error.validate.blank')
            optional :shift_registration_id, type: Integer
          end
          post do
            check_nursing_shift_manage_confirmation
            result = V1::Admin::NursingShiftManages::CreateNursingShiftManage.call(params)
            if result.success?
              { success: I18n.t('nursing_shift_manage.message.success.added') }
            else
              error!(result.failure, 422)
            end
          end

          desc 'PUT api/v1/admin/nursing_shift_manages/update_shift'
          params do
            requires :button_type, type: String, values: %w[cancel draft sent approved], message: I18n.t('nursing_shift_manage.error.validate.blank')
            optional :schedule_dates, type: Array do
              optional :id, type: Integer
              optional :start_time, type: String
              optional :end_time, type: String
              optional :delete, type: Boolean
            end
            optional :shift_managements, type: Array do
              optional :id, type: String
              optional :nurse_id, type: Integer
              optional :start_time, type: String
              optional :end_time, type: String
              optional :delete, type: Boolean
            end
          end
          put 'update_shift' do
            check_nursing_shift_manage_confirmation
            next_month = Date.current.next_month
            year_month = next_month.strftime('%Y/%m')
            beginning_of_next_month = next_month.at_beginning_of_month
            end_of_next_month = next_month.end_of_month
            ActiveRecord::Base.transaction do
              if params[:schedule_dates].present? && params[:button_type] == 'draft'
                params[:schedule_dates].each do |parms_sd|
                  schedule_date = ScheduleDate.find(parms_sd[:id])
                  if (beginning_of_next_month..end_of_next_month).exclude?(schedule_date.date)
                    return error!({ message: I18n.t('errors.messages.invalid_dates') }, UNPROCESSABLE_ENTITY)
                  end

                  if parms_sd[:delete]
                    schedule_date.destroy
                    schedule_date.scheduleable.destroy if schedule_date.scheduleable.schedule_dates.blank?
                  else
                    next if schedule_date.start_time == parms_sd[:start_time] && schedule_date.end_time == parms_sd[:end_time]

                    schedule = schedule_date.scheduleable
                    if schedule_date.scheduleable.schedule_dates.count == 1
                      schedule = schedule.care_plan.schedules.includes(:schedule_dates)
                                         .where(service_id: schedule.service_id, service_type_id: schedule.service_type_id)
                                         .find_by(schedule_dates: { start_time: parms_sd[:start_time], end_time: parms_sd[:end_time] })

                      if schedule.present?
                        scheduleable_before_update = schedule_date.scheduleable
                        schedule_date.update(start_time: parms_sd[:start_time], end_time: parms_sd[:end_time], scheduleable_id: schedule.id)
                        scheduleable_before_update.destroy if scheduleable_before_update.schedule_dates.blank?
                      else
                        schedule_date.update(start_time: parms_sd[:start_time], end_time: parms_sd[:end_time])
                      end
                    else
                      schedule = schedule_date.scheduleable.dup
                      schedule.save
                      schedule_date_dup = schedule_date.dup
                      schedule_date_dup.update(scheduleable_id: schedule.id, start_time: parms_sd[:start_time], end_time: parms_sd[:end_time])
                      schedule_date.destroy
                      parms_sd[:id] = schedule_date_dup.id
                    end
                  end
                end
                params[:schedule_dates].each do |parms_sd|
                  next if parms_sd[:delete]

                  schedule_date = ScheduleDate.includes(:scheduleable).find(parms_sd[:id])
                  schedule = schedule_date.scheduleable
                  schedule_dates_by_time = schedule.patient.schedule_dates.where(date: schedule_date.date, start_time: parms_sd[:start_time]...parms_sd[:end_time])
                  return error!({ 'message': I18n.t('errors.messages.caregiving_time_slot_already_allocated') }, UNPROCESSABLE_ENTITY) if schedule_dates_by_time.count > 1

                  working_nurse_ids = ScheduleDate.where.not(nurse_id: schedule_date.nurse_id).for_working_nurses_on_date(schedule_date.date, parms_sd[:start_time], parms_sd[:end_time]).pluck(:nurse_id)
                  available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(schedule_date.date, parms_sd[:start_time], parms_sd[:end_time])
                  nursing_staffs = NursingStaff.where(id: available_nurse_ids)
                                               .where.not(id: working_nurse_ids)
                                               .includes(:degrees, nursing_shift_manages: :shift)
                                               .active

                  if nursing_staffs.include?(schedule_date.nurse)
                    schedule_date.update(start_time: parms_sd[:start_time], end_time: parms_sd[:end_time])
                  else
                    return error!({ 'message': I18n.t('errors.messages.nurse_is_busy') }, UNPROCESSABLE_ENTITY)
                  end
                end
              end
              if params[:shift_managements].present? && params[:button_type] == 'draft'
                params[:shift_managements].each do |parms_sm|
                  shift_management = ShiftManagement.find(parms_sm[:id])
                  if (beginning_of_next_month..end_of_next_month).exclude?(shift_management.shift_date)
                    return error!({ message: I18n.t('errors.messages.invalid_dates') }, UNPROCESSABLE_ENTITY)
                  end

                  staff = NursingStaff.find(parms_sm[:nurse_id])
                  if parms_sm[:delete]
                    shift_management.destroy
                    staff.schedule_dates.where(date: shift_management.shift_date).each do |schedule_date|
                      available_nurse_ids = NursingShiftManage.available_working_nurses_on_date(schedule_date.date, schedule_date.start_time, schedule_date.end_time)
                      schedule_date.update(nurse_id: nil) if available_nurse_ids.exclude?(staff.id)
                    end
                  else
                    shift_registration_id = ShiftRegistration.find_by(start_time: parms_sm[:start_time], end_time: parms_sm[:end_time])&.id
                    shift_management.update(start_time: parms_sm[:start_time], end_time: parms_sm[:end_time], shift_registration_id: shift_registration_id)
                    schedule_dates = staff.schedule_dates.where(date: shift_management.shift_date)
                    shifts = staff.shifts.select { |shift| shift.shift_date == shift_management.shift_date }
                    shifts.each do |shift|
                      overlapping_shift = shifts.find do |other_shift|
                        shift != other_shift &&
                          Time.parse(shift.start_time) <= Time.parse(other_shift.end_time) &&
                          Time.parse(shift.end_time) >= Time.parse(other_shift.start_time)
                      end
                      return error!({ 'message': I18n.t('errors.messages.shifts_overlap') }, UNPROCESSABLE_ENTITY) if overlapping_shift
                    end
                    schedule_dates.each do |schedule_date|
                      start_time_schedule = Time.parse(schedule_date.start_time)
                      end_time_schedule = Time.parse(schedule_date.end_time)
                      unless shifts.any? { |shift| start_time_schedule >= Time.parse(shift.start_time) && end_time_schedule <= Time.parse(shift.end_time) }
                        return error!({ 'message': I18n.t('errors.messages.no_available_shifts_for_schedule_date') }, UNPROCESSABLE_ENTITY)
                      end
                    end
                  end
                end
              end

              if params[:button_type] == 'cancel'
                ScheduleDate.where(status: 'initial', date: beginning_of_next_month..end_of_next_month).where.not(previous_data: nil).each do |schedule_date|
                  schedule_date.update(schedule_date.previous_data)
                end
                NursingShiftManage.includes(:shift).where(shift: { shift_date: beginning_of_next_month..end_of_next_month })
                                  .where(status: 'initial').destroy_all
                Holiday.where(date: beginning_of_next_month..end_of_next_month, status: 'initial').destroy_all
              elsif params[:button_type] == 'draft'
                NursingShiftManage.includes(:shift).where(shift: { shift_date: beginning_of_next_month..end_of_next_month })
                                  .where(status: 'initial').update_all(status: 'draft')
                ScheduleDate.where(status: 'initial', date: beginning_of_next_month..end_of_next_month).where.not(nurse: nil).update_all(status: 'draft', previous_data: nil)
                Holiday.where(date: beginning_of_next_month..end_of_next_month, status: 'initial').update_all(status: nil)
              elsif params[:button_type] == 'sent'
                nursing_shifts = NursingShiftManage.includes(:shift).where(shift: { shift_date: beginning_of_next_month..end_of_next_month })
                                                   .where(status: ['draft', 'initial'])
                staff_ids = nursing_shifts.pluck(:nurse_id).uniq
                holidays = Holiday.where(date: beginning_of_next_month..end_of_next_month, status: ['initial', 'draft'], create_type: 'admin')
                holidays&.update_all(status: 'sent')
                monthly_holidays = MonthlyHoliday.where(id: holidays.pluck(:monthly_holiday_id))
                monthly_holidays&.update_all(status: 'sent', confirmed_by_admin: true, confirmed_by_staff: false, create_type: 'admin')
                nursing_shifts.update_all(status: 'sent', confirmed_by_admin: true, confirmed_by_staff: false)
                shifts = ShiftManagement.where(id: nursing_shifts.pluck(:shift_id))
                shifts&.update_all(status: 'sent')
                ScheduleDate.where(status: 'draft', date: beginning_of_next_month..end_of_next_month).update_all(status: 'sent', previous_data: nil)
                # sent_shifts()
              else
                # approved
                ScheduleDate.where(date: beginning_of_next_month..end_of_next_month).update_all(status: 'sent')
                MonthlyHoliday.where(year_month: year_month).update_all(confirmed_by_admin: true, confirmed_by_staff: true, status: 'approved')
                nursing_shifts = NursingShiftManage.includes(:shift).where(shift: { shift_date: beginning_of_next_month..end_of_next_month })
                staff_ids = nursing_shifts.pluck(:nurse_id).uniq
                nursing_shifts.update_all(status: 'approved', confirmed_by_admin: true, confirmed_by_staff: true)
              end

              if ['sent', 'approved'].include?(params[:button_type])
                # Create noti
                create_noti(staff_ids, year_month, params[:button_type])
              end

              { success: I18n.t('success.messages.updated') }
            end
          rescue StandardError => e
            error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
          end
        end

        helpers do
          def check_nursing_shift_manage_confirmation
            year_month = Date.current.next_month.strftime('%Y/%m')
            staffs_acitve = NursingStaff.active
            monthly_holidays = MonthlyHoliday.where(year_month: year_month)
            return error!(I18n.t('errors.messages.wait_for_staff_send_shift'), UNPROCESSABLE_ENTITY) if monthly_holidays.count < staffs_acitve.count

            confirmed_by_staff = MonthlyHoliday.where(year_month: year_month).where(confirmed_by_staff: false)
            return error!(I18n.t('errors.messages.wait_for_staff_confirmation'), UNPROCESSABLE_ENTITY) if confirmed_by_staff.present?

            confirmed_by_staff_and_admin = MonthlyHoliday.where(year_month: year_month, status: 'approved')
            error!(I18n.t('errors.messages.shift_finalized'), UNPROCESSABLE_ENTITY) if confirmed_by_staff_and_admin.present?
          end

          def noti_title year_month, button_type
            case button_type
            when 'sent'
              "タイトル：#{year_month}のシフトを送信しました。"
            when 'approved'
              "タイトル：#{year_month}のシフトを確定しました。"
            end
          end

          def noti_content year_month, button_type
            case button_type
            when 'sent'
              "<p>#{year_month}のシフトを送信しました。</p>
              <p>各自、シフトの確認をお願いします。</p>
              <p>リンク先URL #{ENV['FE_APP_URL']}/staff/month-shift-after</p>"
            when 'approved'
              "<p>#{year_month}のシフトを確定しました。</p>
              <p>リンク先URL #{ENV['FE_APP_URL']}/staff/visit-schedule</p>"
            end
          end

          def create_noti staff_ids = [], date = Date.today, button_type
            return if staff_ids.blank?

            year_month = date.to_date.strftime('%Y年%m月')
            notification = Notification.create!(title: noti_title(year_month, button_type), content: noti_content(year_month, button_type),
                                                poster: @current_user.user_name || 'Admin', is_important: true, notify_type: 2,
                                                sender_id: @current_user.id, sender_type: @current_user.class.name)
            staff_ids.each do |uid|
              notification.mention_notifications.create!(m_id: uid, mention_type: 'NursingStaff')
            end
          end
        end
      end
    end
  end
end
