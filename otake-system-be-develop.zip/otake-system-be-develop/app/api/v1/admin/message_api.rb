module V1
  module Admin
    class MessageApi < V1::AppApi
      before {authenticate!(UserAdmin, :user_code)}

      namespace :admin do
        resource :rooms do
          desc 'POST api/v1/admin/rooms',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :target_id, type: Integer
          end
          post do
            current_user = current_user(UserAdmin, :user_code)
            current_user_id = current_user.id
            source_type = params[:target_type] == 'user_admin' ? 'admin' : 'staff'
            room = Room.where(source_id: current_user_id, source_type: 'admin',
                              target_id: params[:target_id], target_type: params[:target_type])
                       .or(Room.where(target_id: current_user_id, target_type: 'user_admin',
                                      source_id: params[:target_id], source_type: source_type))
            return present room.first if room.present?

            @room = Room.find_or_create_by(target_id: params[:target_id], source_id: current_user.id, source_type: 'admin', target_type: 'nursing_staff')

            if @room.save
              present @room
            else
              error!(@room.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/rooms',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
            optional :search, type: String
            optional :unread, type: Boolean
          end
          get do
            current_user = current_user(UserAdmin, :user_code)
            page = (params[:page].presence || 1).to_i
            @query = Room.admin_room_owner(current_user.id).only_unread(params[:unread], current_user.id)
            if params[:search].present?
              nurse_ids = NursingStaff.ransack(family_name_or_name_kana_cont: params[:search]).result.pluck(:id)
              @query = @query.where(target_id: nurse_ids, target_type: 'nursing_staff')
            end
            @rooms = @query.by_created_at_desc.page(page).per(params[:per])
            serialized_rooms = @rooms.map do |room|
              RoomSerializer.new(room, { params: { current_uid: @current_user.id } }).as_json
            end
            present :page, page
            present :total_page, @rooms.total_pages
            present :total_items, @rooms.total_count
            present :rooms, serialized_rooms
          end

          desc 'GET api/v1/admin/rooms/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
          end

          get ':id' do
            page = (params[:page].presence || 1).to_i
            @room = Room.find(params[:id])
            @messages = @room.messages.order(created_at: :desc).page(page).per(params[:per])
            @room.messages.where(receiver_id: @current_user.id, read_at: nil, receiver_type: @current_user.class.name)&.update_all(read_at: Time.current)
            serialized_messages = @messages.reverse.map do |message|
              MessageSerializer.new(message).as_json
            end
            present :page, page
            present :total_page, @messages.total_pages
            present :total_items, @messages.total_count
            present :messages, serialized_messages
          end

          desc 'Put api/v1/admin/rooms/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
          end

          put ':id' do
            current_user = current_user(UserAdmin, :user_code)
            room = Room.find(params[:id])
            receiver_type = current_user.class.name
            room.messages.where(receiver_id: current_user.id, read_at: nil, receiver_type: receiver_type)&.update_all(read_at: Time.current)
            { success: true }
          end

          route_param :id do
            resource :messages do
              desc 'POST api/v1/admin/rooms/:id/messages',
                   headers: {
                     'Authorization' => {
                       description: 'Ex: Bearer [your_token]',
                       required: true
                     }
                   }
              params do
                requires :id, type: Integer
                requires :content, type: String
              end
              post do
                current_user = current_user(UserAdmin, :user_code)
                @room = Room.find(params[:id])
                receiver_id = @room.source_type == 'admin' ? @room.target_id : @room.source_id
                receiver_type = 'NursingStaff'

                @message = @room.messages.new(content: params[:content], sender_id: current_user.id,
                                              sender_type: current_user.class.name,
                                              receiver_id: receiver_id, receiver_type: receiver_type)
                if @message.save
                  present @message
                else
                  error!(@message.error_messages, UNPROCESSABLE_ENTITY)
                end
              end
            end
          end
        end
      end
    end
  end
end
