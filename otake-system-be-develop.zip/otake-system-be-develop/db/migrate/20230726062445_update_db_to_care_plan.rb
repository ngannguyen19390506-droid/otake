class UpdateDbToCarePlan < ActiveRecord::Migration[7.0]
  def change
    # nursing_care_plans
    add_column :nursing_care_plans, :year_month, :string
    # disability_care_plans
    add_column :disability_care_plans, :year_month, :string
  end
end
