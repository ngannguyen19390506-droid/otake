module V1
  module Admin
    class BillingsApi < V1::AppApi
      namespace :admin do
        resources :billings do
          desc 'GET api/v1/admin/billings/billing_history_invoice_1',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
          end

          get '/billing_history_invoice_1' do
            patient = Patient.find_by(id: params[:patient_id])
            year_month = params[:year_month]
            current_date = Time.current.strftime('%Y/%m')
            patient_name = patient.family_name
            billing = RentBilling.find_by(params_find_billing)
            # Row 1 > 4
            rent_cost = billing&.rent_cost || RENT_COST
            utility_cost = billing&.utility_cost || UTILITY_COST
            food_cost = billing&.food_cost || FOOD_COST
            living_cost = billing&.living_cost || LIVING_COST
            # Row 5
            billing_subtotal = food_cost + living_cost + utility_cost + rent_cost

            #TODO: Pending until has define
            # Row 6
            sale_tax = 0

            # Row 7
            nursing_care_billings = UsageBilling.nursing_care.find_by(params_find_billing)
            subsidy_amount = nursing_care_billings&.subsidy_amount.to_f
            exceeding_amount = nursing_care_billings&.exceeding_amount.to_f
            other_charge = nursing_care_billings&.other_charge.to_f
            billing_amount = nursing_care_billings&.billing_amount.to_f
            nursing_care_service_fee = (subsidy_amount + exceeding_amount + other_charge + billing_amount).round(0)

            # Row 8
            disability_billings = UsageBilling.disability.find_by(params_find_billing)
            disability_subsidy_amount = disability_billings&.subsidy_amount.to_f
            disability_exceeding_amount = disability_billings&.exceeding_amount.to_f
            disability_other_charge = disability_billings&.other_charge.to_f
            disability_billing_amount = disability_billings&.billing_amount.to_f
            disability_service_fee = (disability_subsidy_amount + disability_exceeding_amount + disability_other_charge + disability_billing_amount).round(0)

            # Row 9
            patient_receipt = PatientReceipt.with_registered.find_by(params_find_billing)
            patient_receipt_total = patient_receipt&.receipts&.pluck(:price).to_a.compact.sum

            # Row 10
            service_payments = patient.equipment_service_payments.by_year_month(year_month)
            equipment_total = 0
            service_total = 0
            potoro_total = 0
            equipment_payments = service_payments.equipment.with_registered
            equipment_payments.each do |obj|
              unit_price = obj.unit_price.to_i
              service_usages = obj.equipment_service_usages&.pluck(:quantity).to_a.compact.sum
              next if unit_price.zero? || service_usages.zero?

              equipment_total += (unit_price * service_usages)
            end

            # Row 11
            service_payment_objects = service_payments.service.with_registered
            service_payment_objects.each do |obj|
              unit_price = obj.unit_price.to_i
              service_usages = obj.equipment_service_usages&.pluck(:quantity).to_a.compact.sum
              next if unit_price.zero? || service_usages.zero?

              service_total += (unit_price * service_usages)
            end

            # Row 12
            potoro_payments = service_payments.potoro.with_registered
            potoro_payments.each do |obj|
              unit_price = obj.unit_price.to_i
              service_usages = obj.equipment_service_usages&.pluck(:quantity).to_a.compact.sum
              next if unit_price.zero? || service_usages.zero?

              potoro_total += (unit_price * service_usages)
            end

            sub_total = nursing_care_service_fee + disability_service_fee + patient_receipt_total + equipment_total + service_total + potoro_total
            total = billing_subtotal + sale_tax + sub_total

            data = { patient_name: patient_name, year_month: year_month, current_date: current_date,
                     rent_cost: rent_cost, utility_cost: utility_cost, food_cost: food_cost, living_cost: living_cost,
                     billing_sumerize: billing_subtotal, sale_tax: sale_tax,
                     nursing_care_service_fee: nursing_care_service_fee, disability_service_fee: disability_service_fee,
                     patient_receipt_total: patient_receipt_total, equipment_total: equipment_total, service_total: service_total,
                     potoro_total: potoro_total, sub_total: sub_total, total: total }
            render data: data
          end

          desc 'GET api/v1/admin/billings/service_payments'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
          end

          get '/service_payments' do
            patient = Patient.find_by(id: params[:patient_id])
            year_month = params[:year_month]
            current_date = Time.current.strftime('%Y/%m')
            patient_name = patient.family_name
            equipments = []
            services_usage = []
            potoroes = []

            service_payments = patient.equipment_service_payments.by_year_month(year_month)
            service_ids = service_payments.pluck(:equipment_service_id).uniq
            services = EquipmentService.where(id: service_ids).pluck(:id, :service_name)
            equipment_total = 0
            service_total = 0
            potoro_total = 0

            # Equipment
            equipment_payments = service_payments.equipment.with_registered
            equipment_payments.each do |obj|
              unit_price = obj.unit_price.to_i
              equipment_service_usages = obj.equipment_service_usages.by_date_asc
              if equipment_service_usages.present?
                equipment_service_usages.each do |service|
                  service_name = services.find {|serv| serv[0] == service.equipment_service_payment.equipment_service_id}[1]
                  quantity = service.quantity
                  next if unit_price.zero? && quantity.zero?

                  sub_total = unit_price * quantity
                  equipment_total += sub_total
                  equipments << { date: service.date.strftime('%Y/%m/%d'), service_name: service_name, unit_price: unit_price,
                                  quantity: quantity, sub_total: sub_total }
                end
              end
            end

            # Service
            service_payment_objects = service_payments.service.with_registered
            service_payment_objects.each do |obj|
              unit_price = obj.unit_price.to_i
              equipment_service_usages = obj.equipment_service_usages.by_date_asc
              if equipment_service_usages.present?
                equipment_service_usages.each do |service|
                  service_name = services.find {|serv| serv[0] == service.equipment_service_payment.equipment_service_id}[1]
                  quantity = service.quantity
                  next if unit_price.zero? && quantity.zero?

                  sub_total = unit_price * quantity
                  service_total += sub_total
                  services_usage << { date: service.date.strftime('%Y/%m/%d'), service_name: service_name, unit_price: unit_price,
                                      quantity: quantity, sub_total: sub_total }
                end
              end
            end

            # Potoro
            potoro_payments = service_payments.potoro.with_registered
            potoro_payments.each do |obj|
              unit_price = obj.unit_price.to_i

              equipment_service_usages = obj.equipment_service_usages.by_date_asc
              if equipment_service_usages.present?
                equipment_service_usages.each do |service|
                  service_name = services.find {|serv| serv[0] == service.equipment_service_payment.equipment_service_id}[1]
                  quantity = service.quantity
                  next if unit_price.zero? && quantity.zero?

                  sub_total = unit_price * quantity
                  potoro_total += sub_total
                  potoroes << { date: service.date.strftime('%Y/%m/%d'), service_name: service_name, unit_price: unit_price,
                                quantity: quantity, sub_total: sub_total }
                end
              end
            end

            data = { year_month: year_month, current_date: current_date, patient_name: patient_name,
                     equipments: equipments, equipment_total: equipment_total,
                     services_usage: services_usage, service_total: service_total,
                     potoroes: potoroes, potoro_total: potoro_total }
            render data: data
          end

          desc 'GET api/v1/admin/billings/advanced_receipts'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
          end

          get '/advanced_receipts' do
            patient = Patient.find_by(id: params[:patient_id])
            year_month = params[:year_month]
            current_date = Time.current.strftime('%Y/%m')
            patient_name = patient.family_name
            patient_receipts = PatientReceipt.find_by(params_find_billing)
            billing_detail = []
            total = 0
            if patient_receipts.present?
              receipts = patient_receipts.receipts
              total = receipts&.pluck(:price).to_a.compact.sum
              receipts.map do |object|
                price = object.price
                file = object.document_receipts&.first&.file_url || ''
                memo = object.memo
                billing_detail << { price: price, file: file, memo: memo }
              end
            end

            data = { year_month: year_month, current_date: current_date, patient_name: patient_name, total: total, billing_detail: billing_detail }
            render data: data
          end
        end
      end

      helpers do
        def params_find_billing
          params.slice(:patient_id, :year_month)
        end

        def format_delimiter value
          "#{ActiveSupport::NumberHelper.number_to_delimited(value)}"
        end

        def format_delimiter_with_unit value
          "#{format_delimiter(value)}円"
        end

        def format_delimiter_with_yen value
          "￥ #{format_delimiter(value)}"
        end
      end
    end
  end
end
