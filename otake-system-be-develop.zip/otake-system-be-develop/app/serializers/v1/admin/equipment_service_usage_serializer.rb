module V1
  module Admin
    class EquipmentServiceUsageSerializer < ActiveModel::Serializer
      attributes :id,
                 :date,
                 :quantity,
                 :equipment_service_payment_id

      belongs_to :equipment_service_payment, serializer: EquipmentServicePaymentSerializer
    end
  end
end
