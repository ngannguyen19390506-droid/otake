# == Schema Information
#
# Table name: message_notifications
#
#  id                   :bigint           not null, primary key
#  content              :string           not null
#  read_at              :datetime
#  receiver_type        :string
#  sender_type          :string
#  created_at           :datetime         not null
#  updated_at           :datetime         not null
#  notification_id      :bigint
#  notification_room_id :integer          not null
#  receiver_id          :integer          not null
#  sender_id            :bigint           not null
#
# Indexes
#
#  index_message_notifications_on_sender_type_and_sender_id  (sender_type,sender_id)
#
class MessageNotification < ApplicationRecord
  belongs_to :notification_room
end
