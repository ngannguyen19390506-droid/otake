# == Schema Information
#
# Table name: daily_healths
#
#  id                      :bigint           not null, primary key
#  bathing                 :string
#  blood_pressure_first    :string
#  blood_pressure_fourth   :string
#  blood_pressure_second   :string
#  blood_pressure_third    :string
#  body_temperature_first  :string
#  body_temperature_second :string
#  date                    :date
#  oxygen_first            :string
#  oxygen_second           :string
#  pulse_first             :string
#  pulse_second            :string
#  wiping                  :string
#  created_at              :datetime         not null
#  updated_at              :datetime         not null
#  care_plan_at_home_id    :bigint           not null
#
# Indexes
#
#  index_daily_healths_on_care_plan_at_home_id  (care_plan_at_home_id)
#
# Foreign Keys
#
#  fk_rails_...  (care_plan_at_home_id => care_plan_at_homes.id)
#
class DailyHealth < ApplicationRecord
  include ApiCommon

  belongs_to :care_plan_at_home
end
