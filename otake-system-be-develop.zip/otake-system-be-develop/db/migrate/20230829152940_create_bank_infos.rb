class CreateBankInfos < ActiveRecord::Migration[7.0]
  def change
    create_table :bank_infos do |t|
      t.string :formal_name
      t.string :bank_name
      t.string :bank_name_kana
      t.string :branch_name
      t.string :branch_name_kana
      t.string :bank_code
      t.string :branch_code

      t.timestamps
    end
  end
end
