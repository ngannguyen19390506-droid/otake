# == Schema Information
#
# Table name: receipts
#
#  id                 :bigint           not null, primary key
#  memo               :text
#  price              :integer
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#  patient_receipt_id :integer
#
class Receipt < ApplicationRecord
  belongs_to :patient_receipt
  has_many :document_receipts, class_name: 'DocumentReceipt', dependent: :destroy
end
