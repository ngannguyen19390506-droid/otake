class UpdateToContactRelativeAndDegree < ActiveRecord::Migration[7.0]
  def change
    # contact_relatives
    change_column :contact_relatives, :name, :string, null: true
    change_column :contact_relatives, :relationship, :string, null: true
    change_column :contact_relatives, :desk_phone, :string, null: true
    change_column :contact_relatives, :address, :string, null: true

    # degree
    change_column :degrees, :name, :string, null: true
    change_column :degrees, :expired_date, :date, null: true
    change_column :degrees, :status, :integer, null: true
  end
end
