# == Schema Information
#
# Table name: user_home_systems
#
#  id                 :bigint           not null, primary key
#  encrypted_password :string           not null
#  user_code          :string           not null
#  user_name          :string
#  user_type          :integer          not null
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#
# Indexes
#
#  index_user_home_systems_on_user_code  (user_code) UNIQUE
#
class UserHomeSystem < ApplicationRecord
  include ApiCommon

  has_many :authentication_tokens, dependent: :destroy

  enum user_type: { admin: 0, staff: 1 }

  def generate_reset_password_token
    raw, hashed = Devise.token_generator.generate(UserAdmin, :reset_password_token)
    self.reset_password_token = hashed
    self.reset_password_sent_at = Time.current
    save
    raw
  end
end
