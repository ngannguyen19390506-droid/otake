module V1
  module Staff
    class ServiceTypeSerializer < ActiveModel::Serializer
      attributes :id, :detail
    end
  end
end
