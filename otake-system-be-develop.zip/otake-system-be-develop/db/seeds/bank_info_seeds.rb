puts "Start time import bank_info: #{DateTime.now}"
start_time = Time.current
require 'csv'
ActiveRecord::Base.transaction do
  csv_file_path = File.join(Rails.root, 'db', 'data', 'bank_info.csv')
  CSV.foreach(csv_file_path) do |row|
    formal_name = row[0]
    bank_name = row[1]
    bank_name_kana = row[2]
    branch_name = row[3]
    branch_name_kana = row[4]
    bank_code = row[5]
    branch_code = row[6]
    bank_info_params = { formal_name: formal_name, bank_name: bank_name, bank_name_kana: bank_name_kana, bank_code: bank_code }
    bank_info = BankInfo.find_by(bank_code: bank_code)
    if bank_info.blank?
      bank_info = BankInfo.create(bank_info_params)
    end
    branch_params = { branch_name: branch_name, branch_name_kana: branch_name_kana, branch_code: branch_code }
    bank_info.branch_infos.create(branch_params)
    puts "Completed: #{row}"
  end
rescue StandardError => e
  e
end

puts "End time import bank_info: #{DateTime.now}"
end_time = Time.current
puts "Runtime: #{(end_time - start_time) / 60} minutes"