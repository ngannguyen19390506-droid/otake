# == Schema Information
#
# Table name: rooms
#
#  id          :bigint           not null, primary key
#  code        :string
#  source_type :integer
#  target_type :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  source_id   :integer
#  target_id   :integer
#
class Room < ApplicationRecord
  include ApiCommon
  has_many :messages, dependent: :destroy

  enum source_type: { admin: 1, staff: 2, hs_admin: 3, hs_staff: 4 }
  enum target_type: { user_admin: 1, nursing_staff: 2, home_system_admin: 3, home_system_staff: 4 }

  scope :room_owner, ->(id) { where(source_id: id, source_type: 'staff').or(where(target_id: id, target_type: 'nursing_staff')) }
  scope :admin_room_owner, ->(id) { where(source_id: id, source_type: 'admin').or(where(target_id: id, target_type: 'user_admin')) }
  scope :only_unread, ->(unread, id) {
    joins(:messages).where(messages: { receiver_id: id, receiver_type: 'UserAdmin', read_at: nil }) if unread
  }
  scope :staff_only_unread, ->(unread, id) {
    joins(:messages).where(messages: { receiver_id: id, receiver_type: 'NursingStaff', read_at: nil }) if unread
  }

  # Home System
  scope :hs_staff_room_owner, ->(id) { where(source_id: id, source_type: 'hs_staff').or(where(target_id: id, target_type: 'home_system_staff')) }
  scope :hs_admin_room_owner, ->(id) { where(source_id: id, source_type: 'hs_admin').or(where(target_id: id, target_type: 'home_system_admin')) }
  scope :hs_only_unread, ->(unread, id) {
    joins(:messages).where(messages: { receiver_id: id, read_at: nil, receiver_type: 'UserHomeSystem' }) if unread
  }

  scope :hs_dashboard_unread, ->(id) {
    joins(:messages).where(messages: { receiver_id: id, read_at: nil, receiver_type: 'UserHomeSystem' })
  }

  delegate :first_name_kana, :last_name_kana, to: :nurse, prefix: true

  def self.ransackable_attributes(_auth_object = nil)
    %w[first_name_kana last_name_kana]
  end

  def self.ransackable_associations(_auth_object = nil)
    %w[nurse user_admin]
  end
end
