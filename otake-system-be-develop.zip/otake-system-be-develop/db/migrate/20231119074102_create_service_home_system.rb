class CreateServiceHomeSystem < ActiveRecord::Migration[7.0]
  def change
    create_table :service_home_systems do |t|
      t.string :service_name, null: false
      t.string :display_name, null: false
      t.integer :position, null: false
      t.integer :selection_method, null: false
      t.json :dropdown_values

      t.timestamps
    end

    add_index :service_home_systems, :service_name, unique: true
    add_index :service_home_systems, :display_name, unique: true
  end
end
