module V1
  module Staff
    class ShiftManagementApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }
      namespace :staff do
        resources :shift_managements do
          desc 'GET /api/v1/staff/shift_managements',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String
          end
          get do
            year_month = params[:year_month]
            nursing_staffs = NursingStaff.includes(:degrees, :monthly_holidays, :holidays,
                                                   :nursing_shift_manages, :shifts)
                                         .active
                                         .order(employment_type: :asc, nurse_code: :asc)
            start_month = year_month.to_date.beginning_of_month.beginning_of_day
            end_month = start_month.end_of_month.end_of_day
            query_conditions = { date_gteq: start_month, date_lteq: end_month }
            shift_registrations = ShiftRegistration.by_nurse_ids(nursing_staffs.pluck(:id).to_a.uniq)
                                                   .ransack(query_conditions)
                                                   .result(distinct: true)
                                                   .by_created_at_asc
                                                   .group_by(&:nurse_id)

            data = nursing_staffs.map { |nurse|
              shift_data = shift_registrations[nurse.id.to_s]
              nurse.attributes.slice("id", "family_name", "nurse_code", "employment_type").merge!({ shifts: shift_data })
            }

            shift = ShiftStatus.find_by(year_month: params[:year_month])
            shift_status = shift.present? && shift.shift_lock?

            { shift_lock: shift_status, data: data }
          end

          desc 'POST api/v1/staff/shift_managements',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :year_month, type: String, desc: '2024/12'
            requires :data, type: Array do
              requires :nurse_id, type: Integer
              requires :dates, type: Array, desc: '["2024/10/01", "2024/10/02",...]'
              requires :shift_type, type: String, values: ShiftRegistration.shift_types.keys
              optional :date_deleted, type: Array, desc: '["2024/10/01", "2024/10/02",...]'
              optional :note, type: String, desc: 'Note'
            end
          end
          post do
            if params[:year_month].present?
              year_month = params[:year_month].to_date.strftime("%Y/%m")
              shift_status = ShiftStatus.find_by(year_month: year_month)
              if shift_status.present? && shift_status.shift_lock?
                return error!({ 'messages': I18n.t('errors.messages.shift_lock') }, UNPROCESSABLE_ENTITY)
              end
            end

            params[:data].each do |data|
              staff = NursingStaff.find_by_id(data[:nurse_id])
              ShiftRegistration.where(nurse_id: data[:nurse_id], date: data[:date_deleted])&.destroy_all
              shift_registrations = ShiftRegistration.where(nurse_id: data[:nurse_id]).group_by(&:date)
              shift_type = data[:shift_type]
              note = data[:note]

              data[:dates].each do |date|
                date = date.to_date
                shift = shift_registrations[date]&.first
                shift.update!(shift_type: shift_type, note: note) && next if shift.present?

                staff.shift_registrations.create!(shift_type: shift_type, date: date, note: note)
              end
            end
            { success: I18n.t('success.messages.updated') }
          end

          desc 'GET /api/v1/staff/shift_managements/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
          end
          get '/:id' do
            shift_registration = ShiftRegistration.find(params[:id])

            present shift_registration
          end
        end
      end
    end
  end
end
