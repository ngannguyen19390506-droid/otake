Rails.application.routes.draw do
  devise_for :user_admins
  default_url_options :host => ENV['BASE_URL']
  mount BaseApi => '/api'
  mount GrapeSwaggerRails::Engine => '/swagger' unless Rails.env.production?

  get "healthcheck-be", to: "health#be"
  get "healthcheck-db", to: "health#db"
end
