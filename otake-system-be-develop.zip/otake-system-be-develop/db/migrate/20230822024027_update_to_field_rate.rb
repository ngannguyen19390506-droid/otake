class UpdateToFieldRate < ActiveRecord::Migration[7.0]
  def change
    change_column :insurance_cards, :benefit_limit, :float
    change_column :public_expenses, :benefit_rate, :float
  end
end
