class AddFields < ActiveRecord::Migration[7.0]
  def change
    add_column :notifications, :is_important, :boolean, default: false
    add_column :notifications, :is_deleted, :boolean, default: false
    add_column :notifications, :deleted_at, :datetime
    add_column :notifications, :reply_to, :integer
    add_column :notifications, :level, :integer
  end
end
