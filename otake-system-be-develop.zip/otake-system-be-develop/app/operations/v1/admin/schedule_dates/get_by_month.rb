module V1
  module Admin
    module ScheduleDates
      class GetByMonth < ::ApplicationOperation
        def call(date_from, date_to)
          schedule_dates = ScheduleDate.where(date: [date_from..date_to])
          # this form data => {"01/01/2023"=> [...], "02/02/2023" => [...]}
          schedule_dates_hash = schedule_dates.group_by{ |schedule_date| schedule_date.date }
          result_array = schedule_dates_hash.keys.map do |key|
            result = { date: key }
            schedule_dates_by_key = schedule_dates_hash[key]
            result[:number_of_patients] = number_of_patients(schedule_dates_by_key)
            result[:number_of_nurses] = number_of_nurses(schedule_dates_by_key)
            result[:status] = status_of_schedule_dates(schedule_dates_by_key)
            result[:total_hours] = total_hours(schedule_dates_by_key)
            result
          end
          Success(result_array)
        end

        private

        def status_of_schedule_dates(schedule_dates)
          number_of_patients = number_of_patients(schedule_dates)
          number_of_nurses = number_of_nurses(schedule_dates)
          if number_of_nurses < number_of_patients
            :initial
          else
            statuses = schedule_dates.map { |date| date.status }
            if statuses.include?('initial') || statuses.include?('requested_staff')
              :in_progress
            else
              :completed
            end
          end
        end

        def number_of_patients(schedule_dates)
          schedule_dates.length
        end

        def number_of_nurses(schedule_dates)
          schedule_dates.map { |schedule_date| schedule_date.nurse_id }.compact.count
        end

        def total_hours(schedule_dates)
          schedule_dates.map do |date|
            if date.start_time.nil?
              0
            else
              (date.end_time - date.start_time)
            end
          end.sum.to_f / 3600
        end
      end
    end
  end
end
