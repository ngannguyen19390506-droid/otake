module V1
  module Admin
    class ServiceTypeApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :service_types do
          # index service_types
          desc 'GET /api/v1/admin/service_types'
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
          end
          get do
            @query = ServiceType.all
            return present :data, @query.default_order if params[:get_all] == true

            page = (params[:page].presence || 1).to_i
            @service_types = @query.default_order
            if params[:sortKey].present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              @service_types = @query.order(params[:sortKey] => sort_order)
            end
            @service_types = @service_types.page(page).per(params[:per])
            serialized_service_types = @service_types.map do |service_type|
              ServiceTypeSerializer.new(service_type).as_json
            end
            present :page, page
            present :total_items, @service_types.total_count
            present :total_pages, @service_types.total_pages
            present :serialized_service_types, serialized_service_types
          end

          desc 'POST api/v1/admin/service_types'
          params do
            requires :detail, type: String, message: I18n.t('service_type.error.validate.blank')
          end
          post do
            service_type = ServiceType.new(params_service_type)
            if service_type.save
              { success: I18n.t('success.messages.added') }
            else
              error!(service_type.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/service_types/:id'
          params do
            requires :id, type: Integer
            optional :detail, type: String
          end
          put ':id' do
            service_type = ServiceType.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if service_type.blank?

            if service_type.update(params_service_type)
              { success: I18n.t('success.messages.updated') }
            else
              error!(service_type.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          # Get detail service type
          desc 'GET api/v1/admin/service_types/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            @service_type = ServiceType.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @service_type.blank?

            present @service_type
          end
        end
      end

      helpers do
        def params_service_type
          params.slice(:detail)
        end
      end
    end
  end
end
