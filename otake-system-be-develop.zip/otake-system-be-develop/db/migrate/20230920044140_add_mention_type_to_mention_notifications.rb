class AddMentionTypeToMentionNotifications < ActiveRecord::Migration[7.0]
  def change
    add_column :mention_notifications, :mention_type, :string
  end
end
