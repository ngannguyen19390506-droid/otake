SystemManagementProfile.create(
  facility_name: 'あっとほーむ まるくる',
  zipcode: '463-0036',
  district: '愛知県',
  city: '名古屋市守山区',
  street: '向台三丁目505番地',
  mobile_phone: '0527998443'
)
