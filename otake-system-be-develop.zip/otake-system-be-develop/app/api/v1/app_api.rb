module V1
  class AppApi < Grape::API
    version 'v1', using: :path
    format :json
    formatter :json, Grape::Formatter::ActiveModelSerializers

    rescue_from ActiveRecord::InvalidForeignKey do |e|
      error!(e.message, UNPROCESSABLE_ENTITY)
    end

    rescue_from ActiveRecord::RecordNotFound do |e|
      error!(e.message, NOT_FOUND)
    end

    rescue_from Grape::Exceptions::ValidationErrors do |e|
      error!({ errors: e.as_json.map(&:values).map { |k, v| [k.first, v.first] }.to_h }, BAD_REQUEST)
    end

    rescue_from ActiveModel::RangeError do |e|
      error!({ error: '入力した値が範囲外です。' }, UNPROCESSABLE_ENTITY)
    end

    namespace do
      namespace do
        # Admin
        mount V1::SessionApi
        mount V1::Admin::NursingStaffApi
        mount V1::Admin::PatientApi
        mount V1::Admin::NursingCarePlanApi
        mount V1::Admin::SessionApi
        mount V1::Admin::EvalueOneApi
        mount V1::Admin::EvalueTwoApi
        mount V1::Admin::PublicExpenseApi
        mount V1::Admin::InsuranceCardApi
        mount V1::Admin::PaymentApi
        mount V1::Admin::ShiftRegistrationApi
        mount V1::Admin::ServiceApi
        mount V1::Admin::TreatmentImprovementApi
        mount V1::Admin::NursingShiftManageApi
        mount V1::Admin::ServiceTypeApi
        mount V1::Admin::DisabilityCarePlanApi
        mount V1::Admin::ScheduleDateApi
        mount V1::Admin::ScheduleApi
        mount V1::Admin::SystemManagementProfileApi
        mount V1::Admin::NotificationApi
        mount V1::Admin::MessageApi
        mount V1::Admin::NursingCareHistoryApi
        mount V1::Admin::EquipmentServiceApi
        mount V1::Admin::ChangeHistoryApi
        mount V1::Admin::EquipmentServicePaymentApi
        mount V1::Admin::PaymentHistoryApi
        mount V1::Admin::ReceiptApi
        mount V1::Admin::UsageBillingApi
        mount V1::Admin::RentBillingApi
        mount V1::Admin::BankInfoApi
        mount V1::Admin::BillingsApi
        mount V1::Admin::ShiftManagementApi
        mount V1::Admin::DashboardApi
        mount V1::Admin::NursingCareHistoryChangeApi
        mount V1::Admin::RecipientApi
        mount V1::Admin::ExportPdfApi
        mount V1::Admin::CareCategorySettingApi

        # Staff
        mount V1::Staff::SessionApi
        mount V1::Staff::NursingCarePlanApi
        mount V1::Staff::MonthlyHolidayApi
        mount V1::Staff::PatientApi
        mount V1::Staff::EvalueOneApi
        mount V1::Staff::EvalueTwoApi
        mount V1::Staff::NursingShiftManageApi
        mount V1::Staff::DisabilityCarePlanApi
        mount V1::Staff::MessageApi
        mount V1::Staff::NursingStaffApi
        mount V1::Staff::NotificationApi
        mount V1::Staff::NursingCareHistoryApi
        mount V1::Staff::ServiceApi
        mount V1::Staff::ServiceTypeApi
        mount V1::Staff::ScheduleApi
        mount V1::Staff::RoutineApi
        mount V1::Staff::DashboardApi
        mount V1::Staff::InsuranceCardApi
        mount V1::Staff::TreatmentImprovementApi
        mount V1::Staff::PaymentApi
        mount V1::Staff::PublicExpenseApi
        mount V1::Staff::RecipientApi
        mount V1::Staff::ShiftManagementApi

        # Client
        mount V1::Client::SessionApi
        mount V1::Client::NursingCareHistoryApi
        mount V1::Client::ScheduleApi

        # Address
        mount V1::AddressApi

        # Notification Category
        mount V1::NotificationCategoryApi

        # Admin Home System
        mount V1::AdminHomeSystem::SessionApi
        mount V1::AdminHomeSystem::PatientApi
        mount V1::AdminHomeSystem::ServiceHomeSystemApi
        mount V1::AdminHomeSystem::CarePlanAtHomeApi
        mount V1::AdminHomeSystem::ScheduleDateAtHomeApi
        mount V1::AdminHomeSystem::DailyHealthApi
        mount V1::AdminHomeSystem::EquipmentServiceApi
        mount V1::AdminHomeSystem::EquipmentHomeSystemApi
        mount V1::AdminHomeSystem::NotificationApi
        mount V1::AdminHomeSystem::DashboardApi
        mount V1::AdminHomeSystem::MessageApi
        mount V1::AdminHomeSystem::StaffHomeSystemApi

        # Staff Home System
        mount V1::StaffHomeSystem::SessionApi
        mount V1::StaffHomeSystem::PatientApi
        mount V1::StaffHomeSystem::ServiceHomeSystemApi
        # mount V1::StaffHomeSystem::CarePlanAtHomeApi
        mount V1::StaffHomeSystem::ScheduleDateAtHomeApi
        mount V1::StaffHomeSystem::DailyHealthApi
        mount V1::StaffHomeSystem::EquipmentServiceApi
        mount V1::StaffHomeSystem::EquipmentHomeSystemApi
        mount V1::StaffHomeSystem::NotificationApi
        mount V1::StaffHomeSystem::DashboardApi
        mount V1::StaffHomeSystem::MessageApi
        mount V1::StaffHomeSystem::UserHomeSystemApi
      end
    end

    helpers do
      def token
        @token ||= request.headers['Authorization'].scan(/Bearer (.*)$/).flatten.last.to_s
        return nil if @token.blank? || @token.split('.').count < 2
        return nil if AuthenticationToken.authenticate(@token).blank?

        @token
      end

      def data
        JWT.decode(token, ENV['SECRET_KEY_BASE'] || Rails.application.secrets.secret_key_base)
      rescue StandardError
        nil
      end

      def current_user(model, code)
        return @current_user if @current_user
        return nil unless data

        # model: User, :user_code
        # model: NursingStaff, code: nurse_code
        @current_user = model.find_by(code => data.first['code'])
      end

      def current_staff
        @current_staff ||= current_user(NursingStaff, :nurse_code)
      end

      def authenticate!(model, code)
        error!(I18n.t('devise.failure.unauthenticated'), UNAUTHORIZED) unless current_user(model, code)
      end

      def generate_code(model, attribute)
        last_record = model.order(attribute => :desc).first
        return last_record ? format('%04d', last_record.send(attribute)[0..-5].to_i + 1) : '0001' if model == NursingStaff

        last_record ? format('%04d', last_record.send(attribute).to_i + 1) : '0001'
      end

      def render_notifications(id, level, editable)
        objects = Notification.by_level(level, id)
        objects.update_all(is_editable: editable)
        objects.map do |object|
          render_notifications(object.id, object.level + 1, editable)
        end
      end

      def convert_date(date)
        return date if date.nil?

        date.in_time_zone('Asia/Tokyo').strftime('%Y-%m-%d').to_date
      end

      def sent_shifts
        prepare_next_month_data
        cleanup_initial_records

        staffs = NursingStaff.includes(:holidays).active
        staffs.each do |staff|
          monthly_holiday = staff.monthly_holidays.find_by(year_month: @year_month_format)
          if monthly_holiday.present?
            monthly_holiday.update!(confirmed_by_admin: true, confirmed_by_staff: false, status: 'sent')
          else
            monthly_holiday = staff.monthly_holidays.create!(year_month: @year_month_format, confirmed_by_admin: true, confirmed_by_staff: false, status: 'sent')
          end
          (@beginning_of_next_month..@end_of_next_month).each do |date|
            shifts = staff.shifts.select { |shift| shift.shift_date == date }
            holiday = staff.holidays.select { |holiday| holiday.date == date }
            next if shifts.present? || holiday.present?

            monthly_holiday.holidays.create!(date: date, create_type: 'admin', name: '休み')
          end
        end
      end

      def prepare_next_month_data
        @next_month = Date.current.next_month
        @year_month_format = @next_month.strftime('%Y/%m')
        @beginning_of_next_month = @next_month.beginning_of_month
        @end_of_next_month = @next_month.end_of_month
      end

      def cleanup_initial_records
        Holiday.initial.where(date: @beginning_of_next_month..@end_of_next_month).destroy_all
        NursingShiftManage.initial.destroy_all
      end

      def current_client
        @current_client ||= current_user(Patient, :patient_code)
      end

      def working_days_options(year_month, working_days, option)
        result = []
        first_idx = 0
        is_first_week = false
        week_split = year_month.to_date.week_split
        week_split.each_with_index do |week_days, idx|
          week_days.each do |day|
            next if day.nil? || is_first_week

            day_convert = (year_month + "/#{day.to_s.rjust(2, '0')}").to_date
            if working_days.include?(day_convert.wday)
              is_first_week = true
              first_idx = idx
            end
          end
        end

        week_split.each_with_index do |week_days, idx|
          next if option == 'other_week' && [first_idx + 1, first_idx + 3].include?(idx)
          twice_week_options = [first_idx + 1, first_idx + 2, first_idx + 4, first_idx + 5]
          next if option == 'twice_week' && twice_week_options.include?(idx)

          week_days.each do |day|
            next if day.nil?

            day_convert = (year_month + "/#{day.to_s.rjust(2, '0')}").to_date
            result << day if working_days.include?(day_convert.wday)
          end
        end
        result
      end

      def create_schedule_date(schedule_id, schedule_params, created_at = nil)
        schedule_params[:shift_dates].each do |date|
          schedule_date = ScheduleDate.new(
            scheduleable_id: schedule_id,
            date: date,
            start_time: schedule_params[:start_time],
            end_time: schedule_params[:end_time],
            start_time_format: schedule_params[:start_time_format],
            end_time_format: schedule_params[:end_time_format],
            scheduleable_type: 'Schedule',
            shift_type: schedule_params[:shift_type]
          )

          schedule_date.created_at = created_at if created_at.present?

          if schedule_date.save
            create_schedule_history_skip_validates(schedule_date.id, schedule_date)
          end
        end
      end

      def create_schedule_history_skip_validates schedule_date_id, schedule_date
        schedule = schedule_date.scheduleable
        division = schedule.care_plan_type == 'NursingCarePlan' ? 'normal' : 'disability'
        updated_time = if schedule_date.end_time_format.present?
                         current_time = Time.current.strftime("%Y/%m/%d")
                         current_time + " " + (Time.parse(schedule_date.end_time_format) - 1.minute).strftime("%H:%M")
                       else
                         nil
                       end

        history = NursingCareHistory.new(schedule_date_id: schedule_date_id,
                                         patient_id: schedule.patient_id,
                                         service_id: schedule.service_id,
                                         service_type_id: schedule.service_type_id,
                                         start_time: schedule.start_time,
                                         end_time: schedule.end_time,
                                         start_time_format: schedule_date.start_time_format,
                                         end_time_format: schedule_date.end_time_format,
                                         updated_time: updated_time,
                                         division: division)
        history.save(validate: false)
      end

      def get_patient_calendar_data year_month, nurse_id = nil, current_date = nil
        start_month = year_month.to_date.beginning_of_month
        end_month = start_month.end_of_month
        res = []
        conditions = { date: start_month..end_month }
        conditions.merge!({ nurse_id: nurse_id }) if nurse_id.present?

        grouped_patients = Patient.joins(schedules: :schedule_dates)
                                  .where(schedule_dates: conditions)
                                  .select('patients.*, schedule_dates.date')
                                  .group_by { |patient| patient.date }
        (start_month..end_month).each do |date|
          res << { date: date, data: [] } unless res.any? { |h| h[:date] == date }
          patients = grouped_patients[date]
          next if patients.blank?

          if current_date.present?
            next if date > current_date.to_date
          end

          patients_data = []
          patients.each do |patient|
            status = NOT_ASSIGN
            assigned = patient.schedule_dates.where(date: date).map(&:nurse_id).uniq
            if assigned.exclude?(nil)
              status = ASSIGNED
            elsif assigned.count > 1 && assigned.include?(nil)
              status = NOT_ENOUGH_ASSIGN
            end

            patients_data << { patient_id: patient.id, patient_name: patient.family_name, status: status }
          end
          res.find { |r| r[:date] == date }[:data].concat(patients_data)
        end

        res
      end

      def get_patient_schedules schedule_date, nurse_id = nil
        schedule_date = schedule_date.to_date
        start_at = schedule_date.beginning_of_day
        end_at = schedule_date.end_of_day
        results = []

        conditions = { date: start_at..end_at }
        conditions.merge!({ nurse_id: nurse_id }) if nurse_id.present?
        patients = Patient.joins(schedules: [:schedule_dates, :service])
                          .where(schedule_dates: conditions)
                          .group_by { |patient| patient.id }
        patient_schedule_dates = ScheduleDate.where(conditions).order(created_at: :asc)
                                             .group_by { |schedule_date| schedule_date.shift_type }

        schedule_date_ids = patient_schedule_dates.values.flatten.pluck(:id).uniq
        nursing_histories = preload_change_histories(schedule_date_ids)

        Schedule.shift_types.keys.each do |key|
          schedules = []
          if patient_schedule_dates[key].present?
            patient_schedule_dates[key].each do |schedule|
              leave_date = schedule.scheduleable.patient.leave_date
              is_patient_invalid = leave_date.present? && schedule.date >= leave_date
              next if is_patient_invalid

              patient = patients[schedule.scheduleable.patient_id]&.first
              patient_name = patient.family_name
              service_name = schedule.scheduleable.service.service_name
              nursing_care_history = schedule.nursing_care_history
              label = "#{patient_name} | #{service_name}"
              is_history = nursing_histories[schedule.id].present?

              schedules << { patient_id: patient.id, patient_name: patient_name, label: label,
                             shift_type: schedule.shift_type,
                             nursing_care_history_id: nursing_care_history&.id,
                             service_name: service_name, is_history: is_history, created_at: schedule.created_at,
                             start_time_format: schedule.start_time_format,
                             end_time_format: schedule.end_time_format,
                             history_start_time_format: nursing_care_history&.start_time_format,
                             history_end_time_format: nursing_care_history&.end_time_format,
                             schedule_date_id: schedule.id, scheduleable: schedule.scheduleable.attributes.except('date', 'frequency'),
                             nursing_staff: schedule.nurse&.attributes&.slice('id', 'family_name') }
            end
          end
          schedules = schedules.sort_by { |f| f[:created_at] }
          results << { shift_type: key, schedules: schedules }
        end

        results
      end

      def preload_change_histories(schedule_date_ids)
        NursingCareHistory.where(schedule_date_id: schedule_date_ids).each_with_object({}) do |schedule, obj|
          next if schedule.sweating.blank? || schedule.complexion.blank?
          obj[schedule.schedule_date_id] = true
        end
      end

      def preload_nursing_change_histories(schedule_date_ids)
        nursing_care_histories = NursingCareHistory.where(schedule_date_id: schedule_date_ids)
        nursing_care_histories.where.not(sweating: nil)
                              .or(nursing_care_histories.where.not(complexion: nil))
                              .group_by { |f| f.schedule_date_id }
      end

      def get_staffs_working_time year_month
        res = []
        start_month = year_month.to_date.beginning_of_month
        end_month = start_month.end_of_month
        schedule_assigned = ScheduleDate.where.not(nurse_id: nil)
                                        .where(date: start_month..end_month)
                                        .select('schedule_dates.*')
                                        .group_by { |f| [f.nurse_id, f.date] }.to_h
        staffs = NursingStaff.active
        return [] if staffs.blank?
        staffs.each do |staff|
          staff_id = staff.id
          work_time = 0.0
          (start_month..end_month).each do |date|
            schedules = schedule_assigned[[staff_id, date]]
            next if schedules.blank?

            schedules.each do |schedule|
              work_time += time_difference_in_hours(schedule.start_time, schedule.end_time)
            end
          end

          work_time_convert = convert_hrs_to_text(work_time)
          res << { staff_id: staff_id, staff_name: staff.family_name, working_time: work_time_convert }
        end

        res
      end

      def time_difference_in_hours start_time, end_time
        time_start = Time.parse(convert_str_to_time(start_time.to_s))
        time_end = Time.parse(convert_str_to_time(end_time.to_s))
        time_end = time_end + 1.day if time_end.hour.zero?

        (time_end - time_start) / 60 / 60
      end

      def convert_hrs_to_text total_hrs
        total_minutes = (total_hrs * 60).to_i
        I18n.t('attribute_description.schedule.working_time_convert', hrs: total_minutes / 60, min: total_minutes % 60)
      end

      def client_overlap?(schedules, year_month)
        schedules.each do |schedule|
          frequency = schedule[:frequency]
          working_days = schedule[:schedule_routines].select { |f| f[:checked] }.pluck(:regis_day)
          days = working_days_options(year_month, working_days, frequency).map { |f| "#{year_month}/#{f.to_s.rjust(2, '0')}".to_date }

          # schedule_dates = ScheduleDate.joins(:nursing_care_history).where('nursing_care_histories.nurse_id IS NULL')
          #                              .where(date: days, shift_type: schedule[:shift_type])
          #                              .where.not(scheduleable_id: schedule[:id])
          #                              .pluck(:start_time_format, :end_time_format)
          schedule_dates = ScheduleDate.joins(:nursing_care_history)
                                       .where('nursing_care_histories.nurse_id IS NULL')
                                       .where(date: days).where.not(scheduleable_id: schedule[:id])
          start_time = schedule[:start_time_format]
          end_time = schedule[:end_time_format]
          client_schedule_dates = []
          schedule_dates.map { |f| client_schedule_dates << [f.start_time_format, f.end_time_format, f.scheduleable.patient_id, f.shift_type] }
          is_client_overlap = client_schedule_dates.find { |f|
            (start_time > f[0] && start_time < f[1] && f[2] == params[:patient_id].to_i) ||
              (start_time == f[0] && end_time < f[1] && f[2] == params[:patient_id].to_i) ||
              (start_time == f[0] && end_time > f[1] && f[2] == params[:patient_id].to_i) ||
              (end_time > f[0] && end_time < f[1] && f[2] == params[:patient_id].to_i) ||
              (end_time == f[1] && start_time >= f[0] && f[2] == params[:patient_id].to_i) ||
              (end_time == f[1] && start_time <= f[1] && f[2] == params[:patient_id].to_i)
          }
          return error!({ 'messages': I18n.t('errors.messages.time_overlap') }, UNPROCESSABLE_ENTITY) if is_client_overlap.present?

          is_overlap = client_schedule_dates.find { |f|
            (start_time > f[0] && start_time < f[1] && f[3] == schedule['shift_type']) ||
              (start_time == f[0] && end_time < f[1] && f[3] == schedule['shift_type']) ||
              (start_time == f[0] && end_time > f[1] && f[3] == schedule['shift_type']) ||
              (end_time > f[0] && end_time < f[1] && f[3] == schedule['shift_type']) ||
              (end_time == f[1] && start_time >= f[0] && f[3] == schedule['shift_type']) ||
              (end_time == f[1] && start_time <= f[1] && f[3] == schedule['shift_type'])
          }
          return error!({ 'messages': I18n.t('errors.messages.time_overlap') }, UNPROCESSABLE_ENTITY) if is_overlap.present?
        end
      end

      def overlap?(schedules)
        schedules.combination(2).any? do |first, second|
          first_start = first[:start_time_format]
          first_end = ['00:00', '00:0', '0:00', '0:0'].include?(first[:end_time_format]) ? '24:00' : first[:end_time_format]
          second_start = second[:start_time_format]
          second_end = ['00:00', '00:0', '0:00', '0:0'].include?(second[:end_time_format]) ? '24:00' : second[:end_time_format]

          first_routines = first[:schedule_routines].select { |f| f[:checked] }.pluck(:regis_day)
          second_routines = second[:schedule_routines].select { |f| f[:checked] }.pluck(:regis_day)
          common_routines = (first_routines & second_routines).any?

          # TODO: OLD LOGIC, TEMP COMMENT
          # first_shift = first[:shift_type]
          # second_shift = second[:shift_type]
          # is_has_shift = first_shift == second_shift

          # (first_start <= second_start && first_end >= second_end && common_routines && is_has_shift) ||
          #   (first_start > second_start && first_start < second_end && common_routines && is_has_shift) ||
          #   (first_end > second_start && first_end < second_end && common_routines && is_has_shift)

          (first_start <= second_start && first_end >= second_end && common_routines) ||
            (first_start > second_start && first_start < second_end && common_routines) ||
            (first_end > second_start && first_end < second_end && common_routines)
        end
      end

      def time_invalid?(schedules)
        schedules.any? do |schedule|
          next if schedule.blank?

          schedule = compare_object(schedule)
          start_time = convert_str_to_time(schedule[:start_time].to_s)
          end_time = convert_str_to_time(schedule[:end_time].to_s)
          start_time = start_time[3..4] if start_time.present?
          end_time = end_time[3..4] if end_time.present?

          invalid_min?(start_time) || invalid_min?(end_time)
        end
      end

      def invalid_min?(time)
        ['00', '30'].exclude?(time)
      end

      def compare_object(object)
        object.each_with_object({}) do |(key, value), obj|
          if value.is_a?(Array)
            obj[key.to_sym] = value.map { |hash| hash.transform_keys(&:to_sym) }
          else
            obj[key.to_sym] = value
          end
        end
      end

      def convert_str_to_time time
        return "" if time.blank? || !time.to_s.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/)
        time.in_time_zone("Asia/Tokyo").strftime("%H:%M")
      end

      def match_frequency_text frequency
        case frequency
        when 'weekly'
          '毎週'
        when 'other_week'
          '1週間おき'
        when 'twice_week'
          '2週間おき'
        end
      end

      def create_change_history(schedule, current_user_id, changed_attribute, before_change, after_change)
        ChangeHistory.create(
          user_admin_id: current_user_id,
          changeable_id: schedule.care_plan_id,
          changeable_type: schedule.care_plan.class.name,
          changed_attribute: changed_attribute,
          before_change: before_change,
          after_change: after_change,
          date: Time.zone.today
        )
      end

      def convert_search_params params
        case params[:search]
        when /回/, /cc/
          params[:search].to_i
        when /良/
          'good'
        when /不良/
          'bad'
        when /有/
          'yes'
        when /無/
          'no'
        end
      end

      def compare_end_time end_time
        ['00:00', '0:00', '0:0', '00:0'].include?(end_time) ? '24:00' : end_time
      end

      def groupped_dates year_month
        date = year_month.to_date
        start_month = date.beginning_of_month
        end_month = date.end_of_month
        ScheduleDate.where(date: start_month..end_month)
                    .where.not(schedule_dates: { nurse_id: nil })
                    .group_by { |f| f.date }.to_h
      end

      def validate_notification_group_file!(file_param)
        return if file_param.blank?

        tempfile, filename, content_type = extract_file_attrs(file_param)
        file_size = tempfile.respond_to?(:size) ? tempfile.size : 0
        error!(I18n.t('error.files.size_too_large'), UNPROCESSABLE_ENTITY) if file_size > MAX_FILE_SIZE

        return if content_type.present? && NotificationApi::ALLOWED_CONTENT_TYPES.include?(content_type.to_s.strip)

        ext = filename.to_s.split('.').last&.downcase
        allowed_extensions = %w[png jpg jpeg gif webp bmp xlsx xls pdf]
        return if allowed_extensions.include?(ext)

        error!(I18n.t('error.files.format_invalid_notification'), UNPROCESSABLE_ENTITY)
      end

      def extract_file_attrs(file_param)
        if file_param.is_a?(Hash)
          [file_param[:tempfile], file_param[:filename], file_param[:type]]
        else
          # Rack::Multipart::UploadedFile
          [file_param.tempfile, file_param.original_filename, file_param.content_type]
        end
      end

      def attach_notification_file(notification, file_param)
        return if file_param.blank?

        tempfile, filename, content_type = extract_file_attrs(file_param)
        notification.file.attach(io: tempfile, filename: filename || 'file', content_type: content_type)
      end
    end
  end
end
