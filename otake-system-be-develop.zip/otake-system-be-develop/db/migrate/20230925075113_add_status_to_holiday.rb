class AddStatusToHoliday < ActiveRecord::Migration[7.0]
  def change
    add_column :holidays, :status, :integer
  end
end
