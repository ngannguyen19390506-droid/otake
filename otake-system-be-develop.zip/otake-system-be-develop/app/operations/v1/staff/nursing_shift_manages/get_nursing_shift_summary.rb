module V1
  module Staff
    module NursingShiftManages
      class GetNursingShiftSummary < ::ApplicationOperation
        def call(params, current_staff)
          year_month = if params[:month_date].present?
                         Date.parse(params[:month_date]).strftime('%Y/%m')
                       elsif params[:week_start_date].present? && params[:week_end_date].present?
                         params[:week_start_date].strftime('%Y/%m')
                       elsif params[:specific_date]
                         params[:specific_date].strftime('%Y/%m')
                       end
          monthly_holidays = MonthlyHoliday.where(year_month: year_month, status: 'approved')
          return { data: {} } if monthly_holidays.blank?

          { data: handle_staff_tab(params, current_staff) }
        end

        private

        def handle_staff_tab(params, current_staff)
          if params[:month_date].present?
            get_nursing_shift_summary_by_month(params[:month_date], current_staff)
          elsif params[:week_start_date].present? && params[:week_end_date].present?
            get_staff_shift_summary_by_week(params[:week_start_date], params[:week_end_date], current_staff).values
          elsif params[:specific_date].present?
            get_staff_shift_summary_by_date(params[:specific_date], current_staff).values
          end
        end

        def get_nursing_shift_summary_by_month(month_date, current_staff)
          start_date = month_date.to_date.beginning_of_month
          end_date = month_date.to_date.end_of_month
          nurse_shifts = ScheduleDate.where(date: start_date..end_date, status: 'sent').pluck(:nurse_id, :date).select { |nurse_id, _| nurse_id.present? }
          shifts_with_nurses_per_day = nurse_shifts.reject { |nurse_id, _| nurse_id.nil? }
                                                   .group_by { |_, shift_date| shift_date }
                                                   .transform_values(&:count)

          shifts_summary = {}
          shifts_with_nurses_per_day.each do |date, count|
            has_color = nurse_shifts.any? { |nurse_id, shift_date| nurse_id == current_staff.id && shift_date == date }
            shifts_summary[date] = { count: count, has_color: has_color }
          end

          shifts_summary
        end

        def nurse_name(schedule_date)
          schedule_date.nurse&.family_name
        end

        def get_staff_shift_summary_by_week(week_start_date, week_end_date, current_staff)
          staffs = NursingStaff.includes(:schedule_dates, nursing_shift_manages: :shift)
                                       .where(nursing_shift_manages: { status: 'approved' }, shift: { shift_date: week_start_date..week_end_date })
                                       .sort_by { |staff| staff.id == current_staff.id ? 0 : 1 }
          shifts_by_nurse = {}
          staffs.each do |staff|
            schedule_dates = staff.schedule_dates.select do |schedule_date|
              (week_start_date..week_end_date).include?(schedule_date.date)
            end
            if schedule_dates.blank?
              shifts_by_nurse[staff.id] ||= staff.attributes.merge!({ shifts: {} }).slice('id', 'name_kana', 'family_name', :shifts)
              next
            end

            schedule_dates.each do |schedule_date|
              shifts_by_nurse[staff.id] ||= staff.attributes.merge!({ shifts: {} }).slice('id', 'name_kana', 'family_name', :shifts)
              shifts_by_nurse[staff.id][:shifts][schedule_date.date] ||= []
              shifts_by_nurse[staff.id][:shifts][schedule_date.date] << nursing_shift_data(schedule_date)
            end
          end

          shifts_by_nurse
        end

        def get_staff_shift_summary_by_date(specific_date, current_staff)
          staffs = NursingStaff.includes(:schedule_dates, :shifts, nursing_shift_manages: :shift)
                               .where(nursing_shift_manages: { status: 'approved' }, shift: { shift_date: specific_date })
                               .sort_by { |staff| staff.id == current_staff.id ? 0 : 1 }
          shifts_by_nurse = {}
          staffs.each do |staff|
            schedule_dates = staff.schedule_dates.select { |schedule_date| schedule_date.date == specific_date }
            shift_managements = staff.shifts.select { |shift| shift.shift_date == specific_date }

            shifts_by_nurse[staff.id] ||= staff.attributes.merge!({ shifts: {}, shift_managements: shift_managements })
                                                          .slice('id', 'name_kana', 'family_name', :shifts, :shift_managements)

            next if schedule_dates.blank?

            schedule_dates.each do |schedule_date|
              service_name = schedule_date.scheduleable.service_type.detail
              shifts_by_nurse[staff.id][:shifts] ||= {}
              shifts_by_nurse[staff.id][:shifts][service_name] ||= []
              shifts_by_nurse[staff.id][:shifts][service_name] << nursing_shift_data(schedule_date)
            end
          end

          shifts_by_nurse
        end

        def nursing_shift_data(schedule_date)
          time_range = "#{schedule_date.start_time} ~ #{schedule_date.end_time}"
          {
            patient_name: schedule_date.scheduleable.patient.family_name,
            time_range: time_range,
            service_name: schedule_date&.scheduleable&.service_type&.detail,
            schedule_date: schedule_date
          }
        end
      end
    end
  end
end
