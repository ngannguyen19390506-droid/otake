class CreateContactRelative < ActiveRecord::Migration[7.0]
  def change
    create_table :contact_relatives do |t|
      t.references :nurse,    null: false, foreign_key: { to_table: :nursing_staffs }
      t.string  :name,         null: false
      t.integer :relationship, null: false, limit: 1
      t.string  :desk_phone,   null: false
      t.string  :mobile_phone, null: false
      t.string  :address,      null: false

      t.timestamps
    end
  end
end
