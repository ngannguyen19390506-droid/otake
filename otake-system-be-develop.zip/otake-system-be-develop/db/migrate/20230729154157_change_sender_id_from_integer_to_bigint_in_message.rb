class ChangeSenderIdFromIntegerToBigintInMessage < ActiveRecord::Migration[7.0]
  def change
    change_column :messages, :sender_id, :bigint, null: false
  end
end
