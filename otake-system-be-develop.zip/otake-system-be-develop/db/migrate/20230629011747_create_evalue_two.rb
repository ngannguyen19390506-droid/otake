class CreateEvalueTwo < ActiveRecord::Migration[7.0]
  def change
    create_table :evalue_twos do |t|
      t.references :patient,              null: false, foreign_key: true
      t.integer    :staple_food,          null: false, limit: 1
      t.string     :side_meal,            null: false
      t.string     :toromi,               null: false
      t.string     :support,              null: false
      t.string     :eating_utensil,       null: false
      t.string     :luxury_goods,         null: false
      t.boolean    :is_allergic,          null: false
      t.string     :neck,                 null: false
      t.string     :upper_limb,           null: false
      t.string     :belt,                 null: false
      t.string     :hip_joint,            null: false
      t.string     :bottom,               null: false
      t.string     :sight,                null: false
      t.string     :glasses,              null: false
      t.string     :hearing,              null: false
      t.string     :language,             null: false
      t.string     :form_movement,        null: false
      t.string     :move,                 null: false
      t.string     :stand,                null: false
      t.string     :sit,                  null: false
      t.string     :wash_face,            null: false
      t.string     :head_washing,         null: false
      t.string     :removable,            null: false
      t.string     :grooming,             null: false
      t.string     :excretory_form,       null: false
      t.boolean    :is_urgent_urination,  null: false
      t.boolean    :is_benefit,           null: false
      t.boolean    :is_incontinence,      null: false
      t.boolean    :is_crushing_process,  null: false
      t.string     :swallow,              null: false
      t.string     :dentures,             null: false
      t.string     :recognition,          null: false
      t.string     :declaration_intent,   null: false
      t.string     :understanding,        null: false
      t.boolean    :is_wandering,         null: false
      t.boolean    :is_violence,          null: false
      t.boolean    :is_delusion,          null: false
      t.boolean    :is_denial,            null: false
      t.boolean    :is_treatment,         null: false
      t.string     :dosage,               null: false

      t.timestamps
    end
  end
end
