class AddPolymorphicToImprovementNursingCarePlan < ActiveRecord::Migration[7.0]
  def change
    remove_column :improvement_nursing_care_plans, :nursing_care_id
    add_reference :improvement_nursing_care_plans, :care_plan, polymorphic: true, index: true
  end
end
