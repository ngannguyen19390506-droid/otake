module V1
  module Admin
    class EquipmentServiceSerializer < ActiveModel::Serializer
      attributes :id,
                 :position,
                 :category,
                 :display_name,
                 :service_name,
                 :stock_quantity,
                 :unit_price,
                 :unit_price_setting

      has_many :equipment_service_payments

      def initialize(equipment_service, options = {})
        super(equipment_service, options)
        @year_month = options[:year_month]
        @patient_id = options[:patient_id]
      end

      def equipment_service_payments
        equipment_service_payment = object.equipment_service_payments.find do |payment|
          payment.patient_id == @patient_id && payment.year_month == @year_month
        end
        if equipment_service_payment.present?
          EquipmentServicePaymentSerializer.new(equipment_service_payment).as_json
        else
          nil
        end
      end
    end
  end
end
