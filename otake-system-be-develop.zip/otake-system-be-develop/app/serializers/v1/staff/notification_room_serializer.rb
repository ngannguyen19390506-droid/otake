module V1
  module Staff
    class NotificationRoomSerializer < ActiveModel::Serializer
      attributes :id, :receiver_id, :receiver_type, :sender_id, :sender_type, :created_at, :sender, :receiver
      has_many :message_notifications

      def created_at
        object.created_at.strftime('%Y/%m/%d %H:%M')
      end

      def receiver
        object.receiver_type.constantize.find_by_id(object.receiver_id)&.attributes&.except("encrypted_password")
      end

      def sender
        object.sender_type.constantize.find_by_id(object.sender_id)&.attributes&.except("encrypted_password")
      end
    end
  end
end