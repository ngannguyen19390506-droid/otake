module V1
  module Admin
    class PaymentApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :payments do
          desc 'POST api/v1/admin/payments'
          params do
            requires :patient_id, type: Integer, message: I18n.t('payment.error.validate.blank')
            requires :payment_method,
                     { type: String,
                       values: Payment.payment_methods.keys,
                       message: I18n.t('payment.error.validate.blank') }
            requires :payer, type: String, values: Payment.payers.keys, message: I18n.t('payment.error.validate.blank')
            optional :account_type, type: String, values: Payment.account_types.keys
            optional :bank_name, type: String
            optional :branch_name, type: String
            optional :account_number, type: String
            optional :account_name_kana, type: String
            optional :customer_number, type: String
            optional :zipcode, type: String
            optional :district, type: String
            optional :city, type: String
            optional :street, type: String
            optional :building_name, type: String
            optional :bank_info_id, type: Integer
            optional :branch_info_id, type: Integer
          end

          post do
            result = V1::Admin::CreatePayment.call(params_payment)
            if result.success?
              { success: I18n.t('success.messages.added') }
            else
              error!({ errors: result.failure }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/payments/:id'
          params do
            requires :patient_id, type: Integer
            optional :payment_method, type: String, values: Payment.payment_methods.keys
            optional :account_type, type: String, values: Payment.account_types.keys
            optional :payer, values: Payment.payers.keys, type: String
            optional :bank_name, type: String
            optional :branch_name, type: String
            optional :account_number, type: String
            optional :account_name_kana, type: String
            optional :customer_number, type: String
            optional :zipcode, type: String
            optional :district, type: String
            optional :city, type: String
            optional :street, type: String
            optional :building_name, type: String
            optional :bank_info_id, type: Integer
            optional :branch_info_id, type: Integer
          end

          put do
            patient = Patient.find_by(id: params_payment[:patient_id])
            return error!({ 'message': I18n.t('payment.error.patient.not_found') }, UNPROCESSABLE_ENTITY) if patient.blank?

            payment = patient.payment
            if payment.update(params_payment)
              if params_payment[:payment_method] != 'account_transfer'
                payment.update(
                  bank_name: nil,
                  branch_name: nil,
                  account_type: nil,
                  account_number: nil,
                  customer_number: nil,
                  account_name_kana: nil,
                  bank_info_id: nil,
                  branch_info_id: nil
                )
              end

              if params_payment[:payer] != 'other'
                payment.update(
                  zipcode: nil,
                  district: nil,
                  city: nil,
                  street: nil,
                  building_name: nil
                )
              end

              current_user_id = current_user(UserAdmin, :user_code).id
              payment.create_change_histories(current_user_id)
              { success: I18n.t('success.messages.updated') }
            else
              error!({ errors: payment.error_messages }, UNPROCESSABLE_ENTITY)
            end
          end

          # Detail
          desc 'GET /api/v1/admin/payments'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.find_by(id: params[:patient_id])
            return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @payment = patient.payment
            return error!({ 'message': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @payment.blank?

            present @payment
          end
        end
      end

      helpers do
        def params_payment
          params.slice(
            :payment_method, :patient_id, :bank_name, :branch_name,
            :account_type, :account_number, :account_name_kana, :customer_number, :payer,
            :zipcode, :district, :city, :street, :building_name, :bank_info_id, :branch_info_id
          )
        end
      end
    end
  end
end
