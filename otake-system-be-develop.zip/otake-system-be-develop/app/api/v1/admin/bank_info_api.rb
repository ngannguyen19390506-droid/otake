module V1
  module Admin
    class BankInfoApi < V1::AppApi
      namespace :admin do
        resources :bank_infos do
          # index
          desc 'GET api/v1/admin/bank_infos'
          params do
            optional :q, type: String
          end
          get do
            @query = BankInfo.all
            if params[:q].present?
              @query = @query.ransack('bank_name_or_bank_name_kana_or_bank_code_cont' => params[:q]).result
            end

            @bank_infos = @query
            serialized_infos = @bank_infos.map do |info|
              BankInfoSerializer.new(info).as_json
            end
            present :bank_infos, serialized_infos
          end

          desc 'GET api/v1/admin/branch_infos'
          params do
            optional :bank_info_id, type: Integer
            optional :q, type: String
          end
          get '/search-branchs' do
            @query = BranchInfo.all
            @query = @query.where(bank_info_id: params[:bank_info_id]) if params[:bank_info_id].present?
            if params[:q].present?
              @query = @query.ransack('branch_name_or_branch_name_kana_or_branch_code_cont' => params[:q]).result
            end

            @branch_infos = @query
            serialized_infos = @branch_infos.map do |info|
              BranchInfoSerializer.new(info).as_json
            end
            present :bank_infos, serialized_infos
          end
        end
      end
    end
  end
end
