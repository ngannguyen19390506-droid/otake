# == Schema Information
#
# Table name: schedule_at_homes
#
#  id                     :bigint           not null, primary key
#  supplement_options     :integer          not null
#  created_at             :datetime         not null
#  updated_at             :datetime         not null
#  care_plan_at_home_id   :bigint           not null
#  service_home_system_id :bigint           not null
#
# Indexes
#
#  index_schedule_at_homes_on_care_plan_at_home_id    (care_plan_at_home_id)
#  index_schedule_at_homes_on_service_home_system_id  (service_home_system_id)
#
# Foreign Keys
#
#  fk_rails_...  (care_plan_at_home_id => care_plan_at_homes.id)
#  fk_rails_...  (service_home_system_id => service_home_systems.id)
#
class ScheduleAtHome < ApplicationRecord
  include ApiCommon

  belongs_to :care_plan_at_home
  belongs_to :service_home_system

  has_many :schedule_date_at_homes, as: :schedule_homeable, dependent: :destroy

  enum supplement_options: { supplement_none: 1, day_shift: 2, night_shift: 3, bathing: 4 }
end
