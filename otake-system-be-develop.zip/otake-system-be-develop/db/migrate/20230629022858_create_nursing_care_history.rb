class CreateNursingCareHistory < ActiveRecord::Migration[7.0]
  def change
    create_table :nursing_care_histories do |t|
      t.references :patient,                   null: false, foreign_key: true
      t.references :nurse,                     null: false, foreign_key: { to_table: :nursing_staffs }
      t.string     :division,                  null: false
      t.string     :temperature,               null: false
      t.string     :blood_pressure,            null: false
      t.string     :defecation,                null: false
      t.string     :moisture,                  null: false
      t.string     :full_body_bath,            null: false
      t.string     :manager,                   null: false
      t.string     :complexion,                null: false
      t.string     :sweating,                  null: false
      t.string     :environmental_arrangement, null: false
      t.string     :consultation_assistance,   null: false
      t.string     :note,                      null: false
      t.string     :toilet_assistance,         null: false
      t.string     :diaper_check,              null: false
      t.string     :pad_confirmation,          null: false
      t.integer    :urination,                 null: false
      t.string     :defecation_type,           null: false
      t.string     :urinal_cleaning,           null: false
      t.string     :maintain_posture,          null: false
      t.integer    :hydration,                 null: false
      t.string     :eating_assistance,         null: false
      t.string     :cleaning,                  null: false
      t.string     :full_body_bath_procedure,  null: false
      t.string     :washing_hair,              null: false
      t.string     :washbasin,                 null: false
      t.string     :oral_care,                 null: false
      t.string     :dressing_assistance,       null: false
      t.string     :position_exchange,         null: false
      t.string     :transfer_assistance,       null: false
      t.string     :watch_over,                null: false

      t.timestamps
    end
  end
end
