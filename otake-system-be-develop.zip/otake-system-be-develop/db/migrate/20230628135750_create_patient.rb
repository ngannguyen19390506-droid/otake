class CreatePatient < ActiveRecord::Migration[7.0]
  def change
    create_table :patients do |t|
      t.references :hospital,                null: false, foreign_key: true
      t.references :name_relative,           null: false, foreign_key: { to_table: :contact_relatives }
      t.string     :name,                    null: false
      t.string     :desk_phone,              null: false
      t.string     :mobile_phone,            null: false
      t.string     :password,                null: false
      t.date       :birth_date,              null: false
      t.integer    :age,                     null: false
      t.integer    :sex,                     null: false, limit: 1
      t.string     :family_name,             null: false
      t.string     :last_name,               null: false
      t.string     :first_name,              null: false
      t.string     :name_kana,               null: false
      t.string     :last_name_kana,          null: false
      t.string     :first_name_kana,         null: false
      t.string     :zipcode,                 null: false
      t.string     :state,                   null: false
      t.string     :city,                    null: false
      t.string     :street,                  null: false
      t.string     :house_no,                null: false
      t.integer    :status,                  null: false, limit: 1
      t.date       :period_contract,         null: false
      t.string     :current_illness_history, null: false
      t.string     :family_interview,        null: false
      t.string     :personal_interview,      null: false
      t.string     :patient_code,            null: false

      t.timestamps
    end
  end
end

