module V1
  module Staff
    class NursingStaffApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }

      namespace :staff do
        resources :nursing_staffs do
          desc 'GET api/v1/admin/nursing_staffs',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :name, type: String
            optional :is_send_message, type: Boolean
          end
          get do
            @nursing_staffs = NursingStaff.ransack(family_name_or_name_kana_cont: params[:name]).result.by_nurse_code_asc
            @nursing_staffs = @nursing_staffs.where.not(id: current_staff.id) if params[:is_send_message]

            serialized_nursing_staffs = @nursing_staffs.map do |nursing_staff|
              NursingStaffSerializer.new(nursing_staff).as_json
            end

            admins = UserAdmin.all
            user_admins = admins.ransack(user_name_cont: params[:name]).result

            serialized_user_admins = user_admins.map do |user_admin|
              UserAdminSerializer.new(user_admin).as_json
            end
            present :nursing_staffs, serialized_nursing_staffs
            present :user_admins, serialized_user_admins
          end
        end
      end
    end
  end
end
