class UpdateToServices < ActiveRecord::Migration[7.0]
  def change
    remove_column :service_types, :service_id
    rename_column :service_types, :type_name, :detail

    add_index :service_types, :detail, unique: true
    add_index :services, :service_name, unique: true
    add_index :treatment_improvements, :name, unique: true
    add_column :treatment_improvements, :rate, :float
  end
end
