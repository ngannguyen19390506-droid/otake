if UserAdmin.first.blank?
  UserAdmin.create(
    user_code: '0001',
    user_name: 'Admin 0001',
    password: 'Zxcv@1234'
  )
end

if NotificationCategory.count.zero?
  categories = ['従業員申し送り（件ごと）一覧', 'お客様申し送り（1日単位でまとめ）ツリー', 'レクリエーション', '事故報告', 'ヒアリハット']
  categories.each do |cat|
    NotificationCategory.create(name: cat)
  end
end

if CareCategorySetting.count.zero?
  data = [{ name: '要介護度1', unit: 16765, price: 167650 },
          { name: '要介護度2', unit: 19705, price: 197050 },
          { name: '要介護度3', unit: 27048, price: 270480 },
          { name: '要介護度4', unit: 30938, price: 309380 },
          { name: '要介護度5', unit: 36217, price: 362170 }]
  data.each do |attr|
    CareCategorySetting.create(attr)
  end
end