class CreateTreatmentImprovement < ActiveRecord::Migration[7.0]
  def change
    create_table :treatment_improvements do |t|
      t.string :name, null: false
      t.integer :patient_type, null: false

      t.timestamps
    end
  end
end
