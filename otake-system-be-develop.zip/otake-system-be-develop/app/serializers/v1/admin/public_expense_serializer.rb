module V1
  module Admin
    class PublicExpenseSerializer < ActiveModel::Serializer
      attributes :id,
                 :beneficiary_number,
                 :benefit_rate,
                 :cost_number,
                 :end_date,
                 :payment_amount,
                 :start_date,
                 :system_name
    end
  end
end
