module V1
  module AdminHomeSystem
    class CarePlanAtHomeApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resources :care_plan_at_homes do
          desc 'POST api/v1/admin_home_system/care_plan_at_homes'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :schedule_at_homes, type: Array do
              requires :service_home_system_id, type: Integer, message: I18n.t('error.validate.blank')
              requires :start_time, type: String, message: I18n.t('error.validate.blank')
              requires :end_time, type: String, message: I18n.t('error.validate.blank')
              requires :supplement_options, type: String, values: ScheduleAtHome.supplement_options.keys, message: I18n.t('error.validate.blank')
              requires :schedule_date_at_homes, type: Array[String], message: I18n.t('error.validate.blank')
            end

            requires :schedule_memo_at_homes, type: Array do
              requires :content, type: String, message: I18n.t('error.validate.blank')
              requires :start_time, type: String, message: I18n.t('error.validate.blank')
              requires :end_time, type: String, message: I18n.t('error.validate.blank')
              requires :schedule_date_at_homes, type: Array[String], message: I18n.t('error.validate.blank')
            end
          end

          post do
            begin
              ActiveRecord::Base.transaction do
                patient = Patient.find_by(id: params[:patient_id])
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

                care_plan_at_home = patient.care_plan_at_homes.find_by(year_month: params[:year_month])
                if care_plan_at_home.present?
                  return error!({ 'messages': I18n.t('errors.messages.already_exists') },
                                UNPROCESSABLE_ENTITY)
                end

                care_plan_at_home = patient.care_plan_at_homes.new(params_care_plan_at_home)
                if care_plan_at_home.save
                  params[:schedule_at_homes].each do |params_schedule|
                    service = ServiceHomeSystem.find_by(id: params_schedule[:service_home_system_id])
                    schedule = care_plan_at_home.schedule_at_homes.create(service_home_system_id: service.id, supplement_options: params_schedule[:supplement_options])
                    params_schedule[:schedule_date_at_homes].each do |date|
                      schedule_date_at_homes = patient.schedule_date_at_homes
                                                      .where(date: date)
                                                      .where("start_time < ? AND end_time > ?", params_schedule[:end_time], params_schedule[:start_time])
                      return error!({ 'messages': I18n.t('errors.messages.already_been_set') }) if schedule_date_at_homes.present?
                      schedule.schedule_date_at_homes.create(start_time: params_schedule[:start_time], end_time: params_schedule[:end_time], date: date)
                    end
                  end

                  params[:schedule_memo_at_homes].each do |params_schedule|
                    schedule = care_plan_at_home.schedule_memo_at_homes.create(content: params_schedule[:content])
                    params_schedule[:schedule_date_at_homes].each do |date|
                      schedule_date_at_homes = patient.schedule_date_at_homes
                                                      .where(date: date)
                                                      .where("start_time < ? AND end_time > ?", params_schedule[:end_time], params_schedule[:start_time])
                      return error!({ 'messages': I18n.t('errors.messages.already_been_set') }) if schedule_date_at_homes.present?

                      schedule.schedule_date_at_homes.create(start_time: params_schedule[:start_time], end_time: params_schedule[:end_time], date: date)
                    end
                  end

                  { success: I18n.t('success.messages.added') }
                else
                  error!({ messages: care_plan_at_home.error_messages}, UNPROCESSABLE_ENTITY)
                end
              end
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin_home_system/care_plan_at_homes'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            requires :schedule_at_homes, type: Array do
              optional :id, type: Integer
              requires :service_home_system_id, type: Integer, message: I18n.t('error.validate.blank')
              requires :start_time, type: String, message: I18n.t('error.validate.blank')
              requires :end_time, type: String, message: I18n.t('error.validate.blank')
              requires :supplement_options, type: String, values: ScheduleAtHome.supplement_options.keys, message: I18n.t('error.validate.blank')
              requires :schedule_date_at_homes, type: Array[String], message: I18n.t('error.validate.blank')
            end

            requires :schedule_memo_at_homes, type: Array do
              optional :id, type: Integer
              requires :content, type: String, message: I18n.t('error.validate.blank')
              requires :start_time, type: String, message: I18n.t('error.validate.blank')
              requires :end_time, type: String, message: I18n.t('error.validate.blank')
              requires :schedule_date_at_homes, type: Array[String], message: I18n.t('error.validate.blank')
            end
          end

          put do
            begin
              ActiveRecord::Base.transaction do
                patient = Patient.find_by(id: params[:patient_id])
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

                care_plan_at_home = patient.care_plan_at_homes.find_by(year_month: params[:year_month])
                return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if care_plan_at_home.blank?

                if care_plan_at_home.update(params_care_plan_at_home)
                  care_plan_at_home.schedule_at_homes.where.not(id: params[:schedule_at_homes].pluck(:id)).destroy_all
                  params[:schedule_at_homes].each do |params_schedule|
                    if params_schedule[:id].present?
                      schedule = ScheduleAtHome.find(params_schedule[:id])
                      service = ServiceHomeSystem.find_by(id: params_schedule[:service_home_system_id])
                      schedule.update(service_home_system_id: service.id, supplement_options: params_schedule[:supplement_options])
                      schedule.schedule_date_at_homes.where.not(date: params_schedule[:schedule_date_at_homes]).destroy_all
                      params_schedule[:schedule_date_at_homes].each do |date|
                        schedule_date_at_homes = patient.schedule_date_at_homes
                                                        .where(date: date)
                                                        .where("start_time < ? AND end_time > ?", params_schedule[:end_time], params_schedule[:start_time])
                                                        .where.not(schedule_homeable_id: params_schedule[:id])
                        return error!({ 'messages': I18n.t('errors.messages.already_been_set') }) if schedule_date_at_homes.present?

                        schedule_date_at_home = schedule.schedule_date_at_homes.find_or_initialize_by(date: date)
                        schedule_date_at_home.update(start_time: params_schedule[:start_time], end_time: params_schedule[:end_time])
                      end
                    else
                      service = ServiceHomeSystem.find_by(id: params_schedule[:service_home_system_id])
                      schedule = care_plan_at_home.schedule_at_homes.create(service_home_system_id: service.id, supplement_options: params_schedule[:supplement_options])
                      params_schedule[:schedule_date_at_homes].each do |date|
                        schedule_date_at_homes = patient.schedule_date_at_homes
                                                        .where(date: date)
                                                        .where("start_time < ? AND end_time > ?", params_schedule[:end_time], params_schedule[:start_time])
                        return error!({ 'messages': I18n.t('errors.messages.already_been_set') }) if schedule_date_at_homes.present?

                        schedule.schedule_date_at_homes.create(start_time: params_schedule[:start_time], end_time: params_schedule[:end_time], date: date)
                      end
                    end
                  end

                  care_plan_at_home.schedule_memo_at_homes.where.not(id: params[:schedule_memo_at_homes].pluck(:id)).destroy_all
                  params[:schedule_memo_at_homes].each do |params_schedule|
                    if params_schedule[:id].present?
                      schedule = care_plan_at_home.schedule_memo_at_homes.find(params_schedule[:id])
                      schedule.update(content: params_schedule[:content])
                      schedule.schedule_date_at_homes.where.not(date: params_schedule[:schedule_date_at_homes]).destroy_all
                      params_schedule[:schedule_date_at_homes].each do |date|
                        schedule_date_at_homes = patient.schedule_date_at_homes
                                                        .where(date: date)
                                                        .where("start_time < ? AND end_time > ?", params_schedule[:end_time], params_schedule[:start_time])
                                                        .where.not(schedule_homeable_id: params_schedule[:id])
                        return error!({ 'messages': I18n.t('errors.messages.already_been_set') }) if schedule_date_at_homes.present?

                        schedule_date_at_home = schedule.schedule_date_at_homes.find_or_initialize_by(date: date)
                        schedule_date_at_home.update(start_time: params_schedule[:start_time], end_time: params_schedule[:end_time])
                      end
                    else
                      schedule = care_plan_at_home.schedule_memo_at_homes.create(content: params_schedule[:content])
                      params_schedule[:schedule_date_at_homes].each do |date|
                        schedule_date_at_homes = patient.schedule_date_at_homes
                                                        .where(date: date)
                                                        .where("start_time < ? AND end_time > ?", params_schedule[:end_time], params_schedule[:start_time])
                        return error!({ 'messages': I18n.t('errors.messages.already_been_set') }) if schedule_date_at_homes.present?

                        schedule.schedule_date_at_homes.create(start_time: params_schedule[:start_time], end_time: params_schedule[:end_time], date: date)
                      end
                    end
                  end

                  { success: I18n.t('success.messages.added') }
                else
                  error!({ messages: care_plan_at_home.error_messages}, UNPROCESSABLE_ENTITY)
                end
              end
            rescue StandardError => e
              error!({ 'messages': e.message }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin_home_system/care_plan_at_homes'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
          end
          get do
            patient = Patient.using.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            patient_serializer = PatientSerializer.new(patient).as_json
            care_plan_at_home = patient.care_plan_at_homes.find_by(year_month: params[:year_month])
            if care_plan_at_home.blank?
              data = { patient: patient_serializer, care_plan_at_home: care_plan_at_home}
            else
              care_plan_at_home_serializer = CarePlanAtHomeSerializer.new(care_plan_at_home).as_json
              data = { patient: patient_serializer, care_plan_at_home: care_plan_at_home_serializer}
            end

            { data: data }
          end
        end
      end

      helpers do
        def params_care_plan_at_home
          params.slice(:patient_id, :year_month)
        end
      end
    end
  end
end
