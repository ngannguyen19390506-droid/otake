BAD_REQUEST = 400
UNAUTHORIZED = 401
NOT_FOUND = 404
UNPROCESSABLE_ENTITY = 422
INTERNAL_SERVER_ERROR = 500
MIN_LENGTH_THREE = 3
MIN_LENGTH_TEN = 10
MAX_LENGTH_TWENTY = 20
MAX_LENGTH_FIFTY = 50
MAX_LENGTH_FIVE_HUNDRED = 500
MAX_LENGTH_THREE_THOUSAND = 3000
ZIP_CODE_REGEX = /\A\w{3}-\w{4}\z/.freeze
NAME_REGEX = /\A[^[:punct:]\\]+\z/.freeze
NAME_KATAKANA_REGEX = /\A(?!^\s)([ァ-ン\s]|ー)+\z/.freeze
DAY_NAMES = {0 => '日', 1 => '月', 2 => '火', 3 => '水', 4 => '木', 5 => '金', 6 => '土'}
YEAR_MONTH = /\A\d{4}\/\d{2}\z/.freeze
DATE_REGEX = /\A\d{4}-\d{2}-\d{2}\z/.freeze
RENT_COST = 37000
UTILITY_COST = 18000
FOOD_COST = 40000
LIVING_COST = 25000
REFUND_COST = 120000
DEFAULT_NURSING_ADDITIONAL = 11.05
DEFAULT_DISABILITY_ADDITIONAL = 10.9
NURSING_CARE_TYPE = 'nursing_care'
DISABILITY_TYPE = 'disability'
PASSWORD_REGEX = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/
ASSIGNED = 'assigned'
NOT_ENOUGH_ASSIGN = 'not_enough_assign'
NOT_ASSIGN = 'not_assign'
DEFAULT_PLAN_NUMBER = 1
DEFAULT_HAS_ACTUAL = 1
DEFAULT_HAS_NOT_ACTUAL = 0
NOT_MANAGE = '管理しない'
PAYLOAD_LOGGER = Logger.new(Rails.root.join('log', "#{Rails.env}_payload_logger.log"))
PROCESS_LOGGER = Logger.new(Rails.root.join('log', "#{Rails.env}_process_logger.log"))
MAX_FILE_SIZE = 10.megabytes
ALLOWED_CONTENT_TYPES = [
  'image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp', 'image/bmp',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', # xlsx
  'application/vnd.ms-excel', # xls
  'application/pdf'
].freeze
