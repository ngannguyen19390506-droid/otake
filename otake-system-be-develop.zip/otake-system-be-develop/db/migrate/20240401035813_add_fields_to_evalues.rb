class AddFieldsToEvalues < ActiveRecord::Migration[7.0]
  def change
    add_column :evalue_ones, :current_illness_history, :text
    add_column :evalue_ones, :family_interview, :text
    add_column :evalue_ones, :personal_interview, :text
    add_column :evalue_ones, :created_date, :date
    add_column :evalue_twos, :created_date, :date
  end
end
