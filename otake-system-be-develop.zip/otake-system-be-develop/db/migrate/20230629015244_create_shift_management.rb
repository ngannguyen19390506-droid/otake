class CreateShiftManagement < ActiveRecord::Migration[7.0]
  def change
    create_table :shift_managements do |t|
      t.date       :shift_date, null: false
      t.time       :start_time, null: false
      t.time       :end_time,   null: false
      t.string     :shift_name, null: false
      t.boolean    :is_present, null: false

      t.timestamps
    end
  end
end
