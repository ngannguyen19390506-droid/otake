module V1
  module AdminHomeSystem
    class EquipmentServiceApi < V1::AppApi
      before { authenticate!(UserHomeSystem, :user_code) }

      namespace :admin_home_system do
        resources :equipment_services do
          # index
          desc 'GET api/v1/admin_home_system/equipment_services'
          params do
            optional :category, type: String, values: EquipmentService.categories.keys
            optional :year_month, type: String
            optional :patient_id, type: Integer
          end
          get do
            patient = Patient.using.find_by(id: params[:patient_id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if patient.blank?

            @equipment_services = EquipmentService.includes(equipment_home_systems: :equipment_usage_home_systems)
                                                  .where(category: 'equipment').sort_by(&:position)

            serialized_equipment_services = @equipment_services.map do |equipment_service|
              EquipmentServiceSerializer.new(equipment_service, { year_month: params[:year_month], patient_id: params[:patient_id] }).as_json
            end

            { data: { patient: patient, equipment_services: serialized_equipment_services } }
          end
        end
      end

      helpers do
      end
    end
  end
end
