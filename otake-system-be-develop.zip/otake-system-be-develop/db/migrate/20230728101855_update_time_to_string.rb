class UpdateTimeToString < ActiveRecord::Migration[7.0]
  def change
    add_column :shift_managements, :start_time_string, :string
    add_column :shift_managements, :end_time_string, :string

    add_column :shift_registrations, :start_time_string, :string
    add_column :shift_registrations, :end_time_string, :string

    add_column :schedule_dates, :start_time_string, :string
    add_column :schedule_dates, :end_time_string, :string

    ShiftManagement.all.each do |shift|
      shift.update(start_time_string: shift.start_time.strftime('%H:%M'), end_time_string: shift.end_time.strftime('%H:%M'))
    end

    ShiftRegistration.all.each do |shift_registration|
      shift_registration.update(start_time_string: shift_registration.start_time.strftime('%H:%M'), end_time_string: shift_registration.end_time.strftime('%H:%M'))
    end

    ScheduleDate.all.each do |schedule_date|
      schedule_date.update(start_time_string: schedule_date.start_time.strftime('%H:%M'), end_time_string: schedule_date.end_time.strftime('%H:%M'))
    end

    remove_column :shift_managements, :start_time
    remove_column :shift_managements, :end_time

    remove_column :shift_registrations, :start_time
    remove_column :shift_registrations, :end_time

    remove_column :schedule_dates, :start_time
    remove_column :schedule_dates, :end_time

    rename_column :shift_managements, :start_time_string, :start_time
    rename_column :shift_managements, :end_time_string, :end_time

    rename_column :shift_registrations, :start_time_string, :start_time
    rename_column :shift_registrations, :end_time_string, :end_time

    rename_column :schedule_dates, :start_time_string, :start_time
    rename_column :schedule_dates, :end_time_string, :end_time
  end
end
