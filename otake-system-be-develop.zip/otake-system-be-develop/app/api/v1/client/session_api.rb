module V1
  module Client
    class SessionApi < V1::AppApi
      namespace :client do
        desc 'POST api/v1/client/login'
        params do
          requires :patient_code, type: String
          requires :password, type: String
        end
        post :login do
          patient = Patient.find_by(patient_code: params[:patient_code])
          return error!({ errors: I18n.t('login.code.invalid') }, UNAUTHORIZED) if patient.blank?

          if patient&.password_matches?(params[:password])
            token = patient.generate_jwt(patient.patient_code, :client)
            { access_token: token }
          else
            error!({ errors: I18n.t('login.code.invalid') }, UNAUTHORIZED)
          end
        end
      end
    end
  end
end
