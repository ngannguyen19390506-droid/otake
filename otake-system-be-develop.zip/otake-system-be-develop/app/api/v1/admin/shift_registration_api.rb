module V1
  module Admin
    class ShiftRegistrationApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }
      namespace :admin do
        resources :shift_registrations do
          desc 'GET api/v1/admin/shift_registrations'
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :sortKey, type: String
            optional :order, type: String
            optional :get_all, type: Boolean
          end
          get do
            @query = ShiftRegistration.all
            return present :data, @query.default_order if params[:get_all] == true

            page = (params[:page].presence || 1).to_i
            @shift_registrations = @query.default_order
            sort_key = params[:sortKey]
            if sort_key.present?
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              sort_key = 'start_time' if sort_key == 'time'
              @shift_registrations = @query.order(sort_key => sort_order)
            end
            @shift_registrations = @shift_registrations.page(page).per(params[:per])
            serialized_shifts = @shift_registrations.map do |shift|
              ShiftRegistrationSerializer.new(shift).as_json
            end
            present :page, page
            present :total_items, @shift_registrations.total_count
            present :total_pages, @shift_registrations.total_pages
            present :shift_registrations, serialized_shifts
          end

          desc 'POST api/v1/admin/shift_registrations'
          params do
            requires :abbreviation, type: String, message: I18n.t('shift_registration.error.validate.blank')
            requires :background_color, type: String, message: I18n.t('shift_registration.error.validate.blank')
            requires :end_time, type: String, message: I18n.t('shift_registration.error.validate.blank')
            requires :name, type: String, message: I18n.t('shift_registration.error.validate.blank')
            requires :start_time, type: String, message: I18n.t('shift_registration.error.validate.blank')
            requires :text_color, type: String, message: I18n.t('shift_registration.error.validate.blank')
          end

          post do
            dup_name = ShiftRegistration.find_by(name: params[:name])
            dup_time = ShiftRegistration.find_by(start_time: params[:start_time], end_time: params[:end_time])
            return error!({ message: I18n.t('shift_registration.error.dup_name') }, UNPROCESSABLE_ENTITY) if dup_name.present?
            return error!({ message: I18n.t('shift_registration.error.dup_time') }, UNPROCESSABLE_ENTITY) if dup_time.present?

            shift_code = generate_code(ShiftRegistration, :shift_code)
            result = V1::Admin::ShiftRegistrations::CreateShiftRegistration.call(params, shift_code)
            if result.success?
              { success: I18n.t('success.messages.added') }
            else
              error!({ errors: result.failure }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/shift_registrations/:id'
          params do
            requires :id, type: Integer
          end
          get ':id' do
            @shift_registration = ShiftRegistration.find(params[:id])
            shift = ShiftRegistrationSerializer.new(@shift_registration).as_json
            present shift
          end

          desc 'put api/v1/admin/shift_registrations/:id'
          params do
            optional :abbreviation, type: String
            optional :background_color, type: String
            optional :end_time, type: String
            optional :name, type: String
            optional :start_time, type: String
            optional :text_color, type: String
          end
          put ':id' do
            @shift_registration = ShiftRegistration.find(params[:id])
            return error!({ message: I18n.t('shift_registration.error.cannot_update') }, UNPROCESSABLE_ENTITY) if %w(早番 遅番 夜勤入り 夜勤明け 休み 希望休).include?(@shift_registration.name)

            if params[:name] != @shift_registration.name
              dup_name = ShiftRegistration.find_by(name: params[:name])
              return error!({ message: I18n.t('shift_registration.error.dup_name') }, UNPROCESSABLE_ENTITY) if dup_name.present?
            end

            dup_time = ShiftRegistration.where.not(id: @shift_registration.id).find_by(start_time: params[:start_time], end_time: params[:end_time])
            return error!({ message: I18n.t('shift_registration.error.dup_time') }, UNPROCESSABLE_ENTITY) if dup_time.present?

            if @shift_registration.update(params)
              { success: I18n.t('success.messages.updated') }
            else
              error!({ errors: shift_registration.errors.full_messages }, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end
    end
  end
end
