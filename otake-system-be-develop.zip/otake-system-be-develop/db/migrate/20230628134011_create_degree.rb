class CreateDegree < ActiveRecord::Migration[7.0]
  def change
    create_table :degrees do |t|
      t.references :nurse,    null: false, foreign_key: { to_table: :nursing_staffs }
      t.string  :name,         null: false
      t.date    :expired_date, null: false
      t.integer :status,       null: false, limit: 1

      t.timestamps
    end
  end
end
