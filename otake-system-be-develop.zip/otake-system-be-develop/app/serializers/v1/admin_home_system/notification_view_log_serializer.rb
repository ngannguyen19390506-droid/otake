module V1
  module AdminHomeSystem
    class NotificationViewLogSerializer < ActiveModel::Serializer
      attributes :id,
                 :name

      def name
        UserHomeSystem.find_by(id: object.viewer_id)&.user_name
        # case object.viewer_type
        # when 'AdminHomeSystem'
        #
        # when 'NursingStaff'
        #   NursingStaff.find_by(id: object.viewer_id)&.full_name
        # else
        #   Patient.find_by(id: object.viewer_id)&.full_name
        # end
      end
    end
  end
end
