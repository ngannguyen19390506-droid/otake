every '59 23 20 * *' do
  rake 'monthly_holidays:update_status_and_create_missing'
end

every '59 23 25 * *' do
  rake 'monthly_holidays:update_status_confirmed_by_staff'
end

every '05 00 01 * *' do
  rake 'staff:generate_routines'
end