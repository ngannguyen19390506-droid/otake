# == Schema Information
#
# Table name: authentication_tokens
#
#  id                  :bigint           not null, primary key
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  hashed_id           :string
#  nursing_staff_id    :bigint
#  patient_id          :bigint
#  user_admin_id       :bigint
#  user_home_system_id :bigint
#
# Indexes
#
#  index_authentication_tokens_on_hashed_id            (hashed_id) UNIQUE
#  index_authentication_tokens_on_nursing_staff_id     (nursing_staff_id)
#  index_authentication_tokens_on_patient_id           (patient_id)
#  index_authentication_tokens_on_user_admin_id        (user_admin_id)
#  index_authentication_tokens_on_user_home_system_id  (user_home_system_id)
#
# Foreign Keys
#
#  fk_rails_...  (nursing_staff_id => nursing_staffs.id)
#  fk_rails_...  (patient_id => patients.id)
#  fk_rails_...  (user_admin_id => user_admins.id)
#  fk_rails_...  (user_home_system_id => user_home_systems.id)
#
class AuthenticationToken < ApplicationRecord
  belongs_to :user_admin, optional: true
  belongs_to :nursing_staff, optional: true
  belongs_to :patient, optional: true
  belongs_to :user_home_system, optional: true

  def digest!(token)
    self.hashed_id = self.class.digest token
    save!
  end

  def self.authenticate(token)
    find_by hashed_id: digest(token)
  end

  def self.digest(token)
    Digest::SHA1.hexdigest token.to_s
  end
end
