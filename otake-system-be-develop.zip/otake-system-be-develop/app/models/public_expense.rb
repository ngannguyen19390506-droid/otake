# == Schema Information
#
# Table name: public_expenses
#
#  id                 :bigint           not null, primary key
#  beneficiary_number :string           not null
#  benefit_rate       :float            not null
#  cost_number        :string           not null
#  end_date           :date             not null
#  payment_amount     :integer
#  start_date         :date             not null
#  system_name        :string           not null
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#  patient_id         :bigint           not null
#
# Indexes
#
#  index_public_expenses_on_patient_id  (patient_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#
class PublicExpense < ApplicationRecord
  include ApiCommon

  belongs_to :patient

  validates :start_date, :end_date, :system_name, :cost_number, :beneficiary_number, :benefit_rate,
            presence: true
  validates :cost_number, :beneficiary_number, numericality: { only_integer: true }
  validates :benefit_rate, numericality: { greater_than_or_equal_to: 0 }

  before_save :round_benefit_rate

  private

  def round_benefit_rate
    self.benefit_rate = benefit_rate.round(2) if benefit_rate.present?
  end
end
