# == Schema Information
#
# Table name: patient_shift_manages
#
#  id         :bigint           not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  patient_id :bigint           not null
#  shift_id   :bigint           not null
#
# Indexes
#
#  index_patient_shift_manages_on_patient_id  (patient_id)
#  index_patient_shift_manages_on_shift_id    (shift_id)
#
# Foreign Keys
#
#  fk_rails_...  (patient_id => patients.id)
#  fk_rails_...  (shift_id => shift_managements.id)
#
class PatientShiftManage < ApplicationRecord
  belongs_to :shift, class_name: 'ShiftManagement'
  belongs_to :patient
end
