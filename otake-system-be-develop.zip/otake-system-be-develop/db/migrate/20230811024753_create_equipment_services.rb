class CreateEquipmentServices < ActiveRecord::Migration[7.0]
  def change
    create_table :equipment_services do |t|
      t.string :service_name, null: false
      t.string :display_name, null: false
      t.integer :category, null: false
      t.integer :unit_price
      t.string :stock_quantity
      t.boolean :unit_price_setting, default: false
      t.integer :position

      t.timestamps
    end
  end
end
