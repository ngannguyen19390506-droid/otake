module V1
  module Admin
    module CarePlans
      class CreateDisabilityCarePlan < CarePlanBaseOperation
        def call(params_disability_care_plan, schedules, improvement_nursing_care_plans, current_user_id, patient)
          begin
            ActiveRecord::Base.transaction do
              long_terms = params_disability_care_plan[:long_terms]
              short_terms = params_disability_care_plan[:short_terms]
              disability_care_plan = DisabilityCarePlan.new(params_disability_care_plan.except(:long_terms, :short_terms, :is_clone))
              if disability_care_plan.save
                care_plan_type = 'DisabilityCarePlan'
                patient_type = 'disability'

                if long_terms.present?
                  long_terms.each do |term|
                    next if term.blank?

                    disability_care_plan.disability_care_plan_terms.long_term.create(term_goal: term)
                  end
                end

                if short_terms.present?
                  short_terms.each do |term|
                    next if term.blank?

                    disability_care_plan.disability_care_plan_terms.short_term.create(term_goal: term)
                  end
                end

                schedules.each do |schedule|
                  service = Service.find_by(id: schedule[:service_id], patient_type: patient_type)
                  return Failure({ 'service_id': I18n.t('activerecord.errors.messages.not_found') }) if service.blank?

                  service_type = ServiceType.find_by(id: schedule[:service_type_id])
                  return Failure({ 'service_type_id': I18n.t('activerecord.errors.messages.not_found') }) if service_type.blank?

                  schedule_id = create_schedule(disability_care_plan, schedule, care_plan_type)&.id
                  create_schedule_routine(schedule_id, schedule)
                end
                treatments_found = create_improvement_nursing_care_plans(disability_care_plan.id, improvement_nursing_care_plans,
                                                                         care_plan_type, patient_type, nil)
                return Failure({ 'message': I18n.t('errors.messages.not_found') }) unless treatments_found

                Success(disability_care_plan)
              else
                Failure(disability_care_plan.error_messages)
              end
            end
          rescue StandardError => e
            Failure(e.message)
          end
        end
      end
    end
  end
end
