class UpdateToContactRelativePatientAndHospital < ActiveRecord::Migration[7.0]
  def change
    # contact_relatives
    change_column :contact_relatives, :nurse_id, :bigint, null: true
    add_reference :contact_relatives, :patient, foreign_key: true

    # patients
    remove_column :patients, :name_relative_id
    remove_column :patients, :hospital_id
    change_column :patients, :password, :string, null: true
    add_column :patients, :encrypted_password, :string

    # hospitals
    add_reference :hospitals, :patient, foreign_key: true, null: false
  end
end
