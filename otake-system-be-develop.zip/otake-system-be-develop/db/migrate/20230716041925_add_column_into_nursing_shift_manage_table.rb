class AddColumnIntoNursingShiftManageTable < ActiveRecord::Migration[7.0]
  def change
    add_column :nursing_shift_manages, :is_sent_for_staff, :boolean, default: false
    add_column :nursing_shift_manages, :confirmed_by_admin, :boolean, default: false
    add_column :nursing_shift_manages, :confirmed_by_staff, :boolean, default: false
  end
end
