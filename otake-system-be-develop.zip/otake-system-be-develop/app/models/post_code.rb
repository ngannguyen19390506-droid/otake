# == Schema Information
#
# Table name: post_codes
#
#  id          :bigint           not null, primary key
#  code        :string           not null
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  address_id  :bigint           not null
#  city_id     :bigint           not null
#  district_id :bigint           not null
#
# Indexes
#
#  index_post_codes_on_address_id   (address_id)
#  index_post_codes_on_city_id      (city_id)
#  index_post_codes_on_code         (code) UNIQUE
#  index_post_codes_on_district_id  (district_id)
#
# Foreign Keys
#
#  fk_rails_...  (address_id => addresses.id)
#  fk_rails_...  (city_id => cities.id)
#  fk_rails_...  (district_id => districts.id)
#
class PostCode < ApplicationRecord
  include ApiCommon

  belongs_to :district
  belongs_to :city
  belongs_to :address

  delegate :name, to: :district, prefix: true, allow_nil: true
  delegate :name, to: :city, prefix: true, allow_nil: true
  delegate :name, to: :address, prefix: true, allow_nil: true
end
