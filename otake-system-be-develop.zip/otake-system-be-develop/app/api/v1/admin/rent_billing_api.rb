module V1
  module Admin
    class RentBillingApi < V1::AppApi
      before {authenticate!(UserAdmin, :user_code)}
      namespace :admin do
        resources :rent_billings do
          desc 'GET api/v1/admin/rent_billings'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank'), desc: '2023/08'
          end

          get do
            billing = RentBilling.find_or_create_by(params_find_billing)
            present billing
          end

          desc 'POST api/v1/admin/rent_billings'
          params do
            requires :patient_id, type: Integer, message: I18n.t('error.validate.blank')
            requires :year_month, type: String, message: I18n.t('error.validate.blank')
            optional :rent_cost, type: Integer, default: 0
            optional :utility_cost, type: Integer, default: 0
            optional :food_cost, type: Integer, default: 0
            optional :living_cost, type: Integer, default: 0
            optional :refund_cost, type: Integer, default: 0
          end

          post do
            patient = Patient.find(params_patient[:patient_id])
            billing = patient.rent_billings.new(params_billings)
            if billing.save
              {success: I18n.t('success.messages.updated')}
            else
              error!({ errors: billing.errors }, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'PUT api/v1/admin/rent_billings/:id'
          params do
            requires :id, type: Integer, message: I18n.t('error.validate.blank')
            optional :rent_cost, type: Integer
            optional :utility_cost, type: Integer
            optional :food_cost, type: Integer
            optional :living_cost, type: Integer
          end

          put ':id' do
            billing = RentBilling.find(params[:id])
            rent_cost = params[:rent_cost].present? ? params[:rent_cost] : RENT_COST
            utility_cost = params[:utility_cost].present? ? params[:utility_cost] : UTILITY_COST
            food_cost = params[:food_cost].present? ? params[:food_cost] : FOOD_COST
            living_cost = params[:living_cost].present? ? params[:living_cost] : LIVING_COST
            vls = %w(rent_cost utility_cost food_cost living_cost)
            vls.map {|v|
              billing.assign_attributes({ v => params[v] })
            }
            if billing.save
              {success: I18n.t('success.messages.updated')}
            else
              error!({ errors: billing.errors }, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end

      helpers do
        def params_patient
          params.slice(:patient_id)
        end

        def params_find_billing
          params.slice(:patient_id, :year_month)
        end

        def params_billings
          params.slice(:patient_id, :year_month, :rent_cost, :utility_cost, :food_cost, :living_cost, :refund_cost)
        end
      end
    end
  end
end