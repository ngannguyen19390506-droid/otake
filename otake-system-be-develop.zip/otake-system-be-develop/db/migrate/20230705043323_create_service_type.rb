class CreateServiceType < ActiveRecord::Migration[7.0]
  def change
    create_table :service_types do |t|
      t.references :service,         null: false, foreign_key: true
      t.string     :type_name,       null: false

      t.timestamps
    end
  end
end
