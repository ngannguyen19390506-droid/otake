class RemoveColumnTotalUsageQuantity < ActiveRecord::Migration[7.0]
  def change
    remove_column :equipment_service_payments, :total_usage_quantity
  end
end
