module V1
  module Staff
    class CareCategorySettingSerializer < ActiveModel::Serializer
      attributes :id, :name, :unit, :price
    end
  end
end
