module V1
  module Admin
    class InsuranceCardSerializer < ActiveModel::Serializer
      attributes :id,
                 :patient_id,
                 :insurance_name,
                 :insurance_number,
                 :start_insurance,
                 :end_insurance,
                 :insurance_company_number,
                 :certification_department,
                 :release_date,
                 :certification_date,
                 :start_validate,
                 :end_validate,
                 :care_level,
                 :home_care_office_type,
                 :home_care_office_input_first,
                 :home_care_office_input_second,
                 :care_application_start_date,
                 :responsible_policy_management,
                 :comprehensive_support_center,
                 :announcement_date,
                 :benefit_limit,
                 :start_date_apply_benefits,
                 :zipcode,
                 :city,
                 :district,
                 :street,
                 :home_care_support_office_name

      def initialize(insurance_card, options = {})
        super(insurance_card, options)
        @use_conversion_methods = options[:use_conversion_methods]
      end

      def home_care_office_type
        return object.home_care_office_type unless @use_conversion_methods

        home_care_office_type_values =  { own_office: '自社事業所', other_office: '他社事業所 ', self_created_or_not_declared: '自己作成または届け出なし' }
        home_care_office_type_values[object.home_care_office_type&.to_sym]
      end

      def certification_department
        return object.certification_department unless @use_conversion_methods

        certification_department_values = { pending: '申請中', certified: '認定済' }
        certification_department_values[object.certification_department&.to_sym]
      end
    end
  end
end
