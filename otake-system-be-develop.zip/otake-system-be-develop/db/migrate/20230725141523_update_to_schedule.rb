class UpdateToSchedule < ActiveRecord::Migration[7.0]
  def change
    # schedules
    remove_column :schedules, :start_time
    remove_column :schedules, :end_time
    remove_column :schedules, :nurse_id
    change_column :schedules, :care_plan_id, :bigint, null: true
    add_reference :schedules, :patient, foreign_key: true, null: true
  end
end

