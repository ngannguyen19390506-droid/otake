# == Schema Information
#
# Table name: shift_statuses
#
#  id         :bigint           not null, primary key
#  status     :integer          not null
#  year_month :string           not null
#
# Indexes
#
#  index_shift_statuses_on_id  (id)
#
class ShiftStatus < ApplicationRecord
  enum status: { available: 0, shift_lock: 1 }
end
