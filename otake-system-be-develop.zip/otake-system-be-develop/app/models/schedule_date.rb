# == Schema Information
#
# Table name: schedule_dates
#
#  id                :bigint           not null, primary key
#  date              :date
#  end_time          :string
#  end_time_format   :string
#  previous_data     :json
#  scheduleable_type :string           not null
#  shift_type        :string
#  start_time        :string
#  start_time_format :string
#  status            :integer          default("initial")
#  created_at        :datetime         not null
#  updated_at        :datetime         not null
#  nurse_id          :bigint
#  scheduleable_id   :bigint           not null
#
# Indexes
#
#  index_schedule_dates_on_scheduleable  (scheduleable_type,scheduleable_id)
#
class ScheduleDate < ApplicationRecord
  include ApiCommon

  belongs_to :scheduleable, polymorphic: true
  belongs_to :nurse, class_name: 'NursingStaff', optional: true
  validates :end_time, :start_time, presence: true
  has_one :nursing_care_history, dependent: :destroy

  enum status: { initial: 0, draft: 1, sent: 2 }

  scope :for_working_nurses_on_date, ->(date, start_time, end_time) {
    where(date: date)
      .where('(start_time >= ? AND start_time < ?) OR (end_time > ? AND end_time <= ?)',
             start_time, end_time,
             start_time, end_time)
      .where.not(nurse_id: nil)
  }

  def self.ransackable_attributes(auth_object = nil)
    ["created_at", "date", "end_time", "id", "nurse_id", "previous_data", "scheduleable_id", "scheduleable_type", "start_time", "status", "updated_at"]
  end

  def self.ransackable_associations(auth_object = nil)
    ["nurse", "nursing_care_history", "scheduleable"]
  end

  def create_change_histories(user_admin_id)
    ActiveRecord::Base.transaction do
      return false if previous_changes.keys.include?('scheduleable_id')

      all_changes = extract_changes_without_timestamps(previous_changes)
      all_changes.each do |changed_attribute, (before_value, after_value)|
        if changed_attribute == 'start_time'
          before_end_time = previous_changes['end_time'].present? ? previous_changes['end_time'][0] : end_time
          before_value = "#{before_value} ~ #{before_end_time}"
          after_value = "#{after_value} ~ #{end_time}"
          all_changes.except!(changed_attribute, 'end_time')
        end

        if changed_attribute == 'end_time'
          before_start_time = previous_changes['start_time'].present? ? previous_changes['start_time'][0] : start_time
          before_value = "#{before_start_time} ~ #{before_value}"
          after_value = "#{start_time} ~ #{after_value}"
          all_changes.except!(changed_attribute, 'start_time')
        end
        text_description = I18n.t("attribute_description.schedule.#{changed_attribute}")
        create_change_history_care_plan(user_admin_id, text_description, before_value, after_value)
      end
    rescue StandardError => e
      e
    end
  end

  def create_change_history_care_plan(user_admin_id, text_description, before_value, after_value)
    ChangeHistory.create!(
      user_admin_id: user_admin_id,
      changeable_id: scheduleable.care_plan_id,
      changeable_type: scheduleable.care_plan_type,
      changed_attribute: text_description,
      before_change: before_value,
      after_change: after_value,
      date: Time.zone.today
    )
  end
end
