module V1
  module Staff
    class ScheduleSerializer < ActiveModel::Serializer
      attributes :id,
                 :care_plan_id,
                 :care_plan_type,
                 :service_id,
                 :service_type_id,
                 :patient_id,
                 :start_time,
                 :end_time,
                 :date,
                 :shift_type,
                 :sort_index

      belongs_to :service, serializer: ServiceSerializer
      belongs_to :service_type, serializer: ServiceTypeSerializer
      belongs_to :care_plan, polymorphic: true, optional: true
      belongs_to :patient, serializer: PatientSerializer

      has_many :schedule_dates, as: :scheduleable, serializer: ScheduleDateSerializer
    end
  end
end
