module V1
  module Staff
    class RecipientApi < V1::AppApi
      before { authenticate!(NursingStaff, :nurse_code) }
      namespace :staff do
        resources :recipients do
          desc 'GET api/v1/staff/recipients',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :patient_id, type: Integer
            optional :page, type: Integer
            optional :per, type: Integer, default: 20
          end
          get do
            patient = Patient.find(params[:patient_id])
            page = (params[:page].presence || 1).to_i
            @query = patient.recipients
            @objects = @query.by_created_at_desc.page(page).per(params[:per])
            serialized_data = @objects.map do |item|
              RecipientSerializer.new(item).as_json
            end
            present :page, page
            present :total_page, @objects.total_pages
            present :total_items, @objects.total_count
            present :recipients, serialized_data
          end

          desc 'GET api/v1/staff/recipients/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
          end
          get '/:id' do
            recipient = Recipient.find(params[:id])
            render recipient
          end
        end
      end
    end
  end
end
