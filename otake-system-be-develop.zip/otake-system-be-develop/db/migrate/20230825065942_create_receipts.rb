class CreateReceipts < ActiveRecord::Migration[7.0]
  def change
    create_table :receipts do |t|
      t.integer :price
      t.json :files
      t.integer :patient_receipt_id

      t.timestamps
    end
  end
end
