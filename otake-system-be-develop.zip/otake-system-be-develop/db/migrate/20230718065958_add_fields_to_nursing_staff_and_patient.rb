class AddFieldsToNursingStaffAndPatient < ActiveRecord::Migration[7.0]
  def change
    add_column :nursing_staffs, :family_name, :string
    add_column :nursing_staffs, :name_kana, :string

    add_column :patients, :family_name, :string
    add_column :patients, :name_kana, :string
  end
end
