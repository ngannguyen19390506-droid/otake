class AddReceiverToMessage < ActiveRecord::Migration[7.0]
  def change
    add_column :messages, :receiver_id, :integer
    add_column :messages, :receiver_type, :string
  end
end
