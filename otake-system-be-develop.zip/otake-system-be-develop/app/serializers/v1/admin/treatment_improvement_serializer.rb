module V1
  module Admin
    class TreatmentImprovementSerializer < ActiveModel::Serializer
      attributes :id, :name, :rate
    end
  end
end
