module V1
  module StaffHomeSystem
    class RoomSerializer < ActiveModel::Serializer
      attributes :id,
                 :target_id,
                 :source_id,
                 :lastest_send_at,
                 :unread,
                 :source_type,
                 :target_type,
                 :source,
                 :target,
                 :is_unread,
                 :latest_msg

      def lastest_send_at
        if object&.messages&.count&.positive?
          object.messages.last.created_at.strftime('%Y/%m/%d %H:%M')
        else
          object.created_at.strftime('%Y/%m/%d %H:%M')
        end
      end

      def latest_msg
        object.messages.by_created_at_desc.first
      end

      def unread
        return object.messages.where(receiver_type: 'UserHomeSystem', receiver_id: current_uid).last&.read_at.nil? if object&.messages&.count&.positive?

        false
      end

      def is_unread
        object.messages.where(receiver_type: 'UserHomeSystem', read_at: nil, receiver_id: current_uid).present?
      end

      def source
        source = UserHomeSystem.find_by_id(object.source_id)
        source&.attributes&.except("encrypted_password")
      end

      def target
        source = UserHomeSystem.find_by_id(object.target_id)
        source&.attributes&.except("encrypted_password")
      end

      def current_uid
        @instance_options[:params][:current_uid]
      end
    end
  end
end
