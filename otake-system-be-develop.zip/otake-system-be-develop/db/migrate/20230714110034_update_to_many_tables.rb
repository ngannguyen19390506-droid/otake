class UpdateToManyTables < ActiveRecord::Migration[7.0]
  def change
    # patients
    rename_column :patients, :state, :district
    add_column :patients, :building_name, :string

    remove_column :patients, :name
    remove_column :patients, :family_name
    remove_column :patients, :name_kana
    remove_column :patients, :house_no
    remove_column :patients, :age
    change_column :patients, :desk_phone, :string, null: true
    change_column :patients, :zipcode, :string, null: true
    change_column :patients, :current_illness_history, :text, null: true, limit: 3000
    change_column :patients, :family_interview, :text, null: true, limit: 3000
    change_column :patients, :personal_interview, :text, null: true, limit: 3000
    # hospitals
    change_column :hospitals, :name, :string, null: true
    change_column :hospitals, :clinical_department, :string, null: true
    change_column :hospitals, :phone, :string, null: true
    change_column :hospitals, :address, :string, null: true

    # contact_relatives
    change_column :contact_relatives, :mobile_phone, :string, null: true

    # nursing_staffs
    rename_column :nursing_staffs, :state, :district

    # evalue_ones
    change_column :evalue_ones, :average_blood_pressure, :string, null: true
    change_column :evalue_ones, :temp, :string, null: true
    change_column :evalue_ones, :heartbeat, :text, null: true
    change_column :evalue_ones, :pre_history, :text, null: true
    change_column :evalue_ones, :daily_life_challenges, :text, null: true
    change_column :evalue_ones, :note, :text, null: true
    change_column :evalue_ones, :character, :text, null: true
    change_column :evalue_ones, :hobbies, :text, null: true
    change_column :evalue_ones, :family_circumstances, :text, null: true
    change_column :evalue_ones, :special_notes, :text, null: true

    # nursing_care_plans
    change_column :nursing_care_plans, :comprehensive_aid_policy, :text, null: true
    change_column :nursing_care_plans, :individual_family_intention, :text, null: true
    change_column :nursing_care_plans, :aid_purpose, :text, null: true
    change_column :nursing_care_plans, :short_term_goal_one, :text, null: true
    change_column :nursing_care_plans, :short_term_goal_two, :text, null: true
    change_column :nursing_care_plans, :short_term_goal_three, :text, null: true
    change_column :nursing_care_plans, :long_term_goal_four, :text, null: true
    change_column :nursing_care_plans, :long_term_goal_one, :text, null: true
    change_column :nursing_care_plans, :long_term_goal_two, :text, null: true
    change_column :nursing_care_plans, :long_term_goal_three, :text, null: true
    change_column :nursing_care_plans, :long_term_goal_four, :text, null: true
    change_column :nursing_care_plans, :remarks, :text

    # insurance_cards
    change_column :insurance_cards, :insurance, :string, null: true
    rename_column :insurance_cards, :insurance, :insurance_name
    change_column :insurance_cards, :insurance_number, :string, null: true
    change_column :insurance_cards, :insurance_company_number, :string, null: true
    change_column :insurance_cards, :certification_department, :string, null: true
    change_column :insurance_cards, :care_level, :string, null: true
    change_column :insurance_cards, :home_care_office_input_first, :string, null: true
    change_column :insurance_cards, :home_care_office_input_second, :string, null: true
    change_column :insurance_cards, :responsible_policy_management, :string, null: true
    change_column :insurance_cards, :comprehensive_support_center, :string, null: true
    change_column :insurance_cards, :start_insurance, :date, null: true
    change_column :insurance_cards, :end_insurance, :date, null: true
    change_column :insurance_cards, :release_date, :date, null: true
    change_column :insurance_cards, :certification_date, :date, null: true
    change_column :insurance_cards, :start_validate, :date, null: true
    change_column :insurance_cards, :end_validate, :date, null: true
    change_column :insurance_cards, :care_application_start_date, :date, null: true
    change_column :insurance_cards, :announcement_date, :date, null: true
    change_column :insurance_cards, :start_date_apply_benefits, :date, null: true
    change_column :insurance_cards, :benefit_limit, :integer, null: true

    # public_expenses
    change_column :public_expenses, :payment_amount, :integer, null: true
    rename_column :public_expenses, :benefit_level, :benefit_rate

    # evalue_twos
    change_column :evalue_twos, :staple_food, :string,null: true
    change_column :evalue_twos, :side_meal, :string,null: true
    change_column :evalue_twos, :toromi, :string,null: true
    change_column :evalue_twos, :support, :string,null: true
    change_column :evalue_twos, :eating_utensil, :string,null: true
    change_column :evalue_twos, :luxury_goods, :string,null: true
    change_column :evalue_twos, :is_allergic, :boolean,null: true
    change_column :evalue_twos, :neck, :string,null: true
    change_column :evalue_twos, :upper_limb, :string,null: true
    change_column :evalue_twos, :belt, :string,null: true
    change_column :evalue_twos, :hip_joint, :string,null: true
    change_column :evalue_twos, :bottom, :string,null: true
    change_column :evalue_twos, :sight, :string,null: true
    change_column :evalue_twos, :glasses, :string,null: true
    change_column :evalue_twos, :hearing, :string,null: true
    change_column :evalue_twos, :language, :string,null: true
    change_column :evalue_twos, :form_movement, :string,null: true
    change_column :evalue_twos, :move, :string,null: true
    change_column :evalue_twos, :stand, :string,null: true
    change_column :evalue_twos, :sit, :string,null: true
    change_column :evalue_twos, :wash_face, :string,null: true
    change_column :evalue_twos, :head_washing, :string,null: true
    change_column :evalue_twos, :removable, :string,null: true
    change_column :evalue_twos, :grooming, :string,null: true
    change_column :evalue_twos, :excretory_form, :string,null: true
    change_column :evalue_twos, :is_urgent_urination, :boolean,null: true
    change_column :evalue_twos, :is_benefit, :boolean,null: true
    change_column :evalue_twos, :is_incontinence, :boolean,null: true
    change_column :evalue_twos, :is_crushing_process, :boolean,null: true
    change_column :evalue_twos, :swallow, :string,null: true
    change_column :evalue_twos, :dentures, :string,null: true
    change_column :evalue_twos, :recognition, :string,null: true
    change_column :evalue_twos, :declaration_intent, :string,null: true
    change_column :evalue_twos, :understanding, :string,null: true
    change_column :evalue_twos, :is_wandering, :boolean,null: true
    change_column :evalue_twos, :is_violence, :boolean,null: true
    change_column :evalue_twos, :is_delusion, :boolean,null: true
    change_column :evalue_twos, :is_denial, :boolean,null: true
    change_column :evalue_twos, :is_treatment, :boolean,null: true
    change_column :evalue_twos, :dosage, :string,null: true
  end
end

