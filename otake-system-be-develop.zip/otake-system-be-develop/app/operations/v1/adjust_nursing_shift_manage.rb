module V1
  class AdjustNursingShiftManage < ::ApplicationOperation
    def call(params)
      shift_id = params[:shift_id]
      shift_date = params[:shift_date]
      start_time = params[:start_time]
      end_time = params[:end_time]
      shift = ShiftManagement.find(shift_id)
      if overlap_holiday?(shift_date)
        return Failure({ date: I18n.t('nursing_shift_manage.error.duplicate_holiday',
                                      date: shift_date,
                                      start_time: start_time,
                                      end_time: end_time) })
      end

      overlap_shift = find_overlap_shift(params)
      if overlap_shift.present?
        return Failure({ date: I18n.t('nursing_shift_manage.error.overlap_date',
                                      date: dup_record.pluck(:shift_date).uniq.join(','),
                                      start_time: params[:start_time],
                                      end_time: params[:end_time]) })
      end

      shift.assign_attributes({ shift_date: shift_date, start_time: start_time, end_time: end_time })
      if shift.valid?
        shift.save
        Success(shift)
      else
        Failure(shift.errors.messages.transform_values { |value| value.join(',') })
      end

    rescue StandardError => e
      Failure(e.message)
    end

    private

    def overlap_holiday?(shift_date)
      Holiday.where(nurse_id: nurse_id).where(date: shift_date).present?
    end

    def find_overlap_shift(params)
      ShiftManagement.includes(:nursing_shift_manages)
                     .where.not(id: params[:shift_id])
                     .where(shift_date: params[:shift_date])
                     .where('nursing_shift_manages.nurse_id = ?', params[:nurse_id])
                     .where('(start_time >= :start_time AND end_time <= :start_time)
                               OR (end_time >= :start_time AND end_time <= :end_time)',
                            { start_time: params[:start_time], end_time: params[:end_time] })
    end
  end
end

