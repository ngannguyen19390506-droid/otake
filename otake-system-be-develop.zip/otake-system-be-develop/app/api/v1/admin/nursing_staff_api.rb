module V1
  module Admin
    class NursingStaffApi < V1::AppApi
      before { authenticate!(UserAdmin, :user_code) }

      namespace :admin do
        resources :nursing_staffs do
          desc 'GET api/v1/admin/nursing_staffs || GET api/v1/admin/nursing_staffs?status=?',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            optional :page, type: Integer
            optional :per, type: Integer, default: 10
            optional :fullname, type: String
            optional :status, type: Array[String], values: NursingStaff.statuses.keys
            optional :sortKey, type: String
            optional :order, type: String
            optional :care_plan_date, type: Date
            optional :get_all, type: Boolean
          end
          get do
            @query = NursingStaff.includes(:degrees, :contact_relatives)
            sort_key = params[:sortKey]
            if params[:status].present?
              # enum status: { active: 1, on_leave: 2, resigned: 3 }
              @query = NursingStaff.where(status: params[:status]).includes(:contact_relatives, :degrees)
              if params[:care_plan_date].present?
                @query = @query.includes(:schedule_dates).where(schedule_dates: { date: params[:care_plan_date] })
              end
            end
            return present :data, @query.default_order.select(:id, :family_name, :name_kana) if params[:get_all]

            @q = @query.ransack(family_name_or_name_kana_cont: params[:fullname])
            page = (params[:page].presence || 1).to_i
            @nursing_staffs = @q.result.by_nurse_code_asc.page(page).per(params[:per]) if sort_key.blank?
            if sort_key.present?
              sort_key = 'name_kana' if sort_key == 'name'
              sort_order = params[:order] == 'ascend' ? 'ASC' : 'DESC'
              if sort_key == 'age'
                sort_key = 'birth_date'
                sort_order = sort_order == 'ASC' ? 'DESC' : 'ASC'
              end
              @nursing_staffs = if sort_key == 'name_kana'
                                  sorted = @q.result.sort_by(&:name_kana)
                                  sorted.reverse! if sort_order != 'ASC'
                                  sorted = Kaminari.paginate_array(sorted).page(page).per(params[:per])
                                  sorted
                                else
                                  @q.result.order(sort_key => sort_order).page(page).per(params[:per])
                                end
            end
            serialized_nursing_staffs = @nursing_staffs.map do |nursing_staff|
              NursingStaffSerializer.new(nursing_staff).as_json
            end
            present :page, page
            present :total_items, @nursing_staffs.total_count
            present :total_pages, @nursing_staffs.total_pages
            present :nursing_staffs, serialized_nursing_staffs
          end

          # Create NursingStaff
          desc 'POST api/v1/admin/nursing_staffs',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :telephone_number, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :password, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :birth_date, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :sex, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :last_name, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :first_name, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :last_name_kana, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :first_name_kana, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :zipcode, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :district, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :city, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :street, type: String, message: I18n.t('nursing_staff.error.validate.blank')
            requires :status, type: String, values: NursingStaff.statuses.keys
            optional :join_date, type: String
            optional :my_number, type: String
            optional :building_name, type: String
            optional :cellphone_number, type: String
            optional :employment_type, type: String, values: NursingStaff.employment_types.keys
            optional :contact_relatives_attributes, type: Array do
              optional :name, type: String
              optional :relationship, type: String
              optional :cellphone_number, type: String
              optional :telephone_number, type: String
              optional :address, type: String
            end
            optional :degrees_attributes, type: Array do
              optional :name, type: String
              optional :expired_date, type: String
            end
          end
          post do
            nursing_staff = NursingStaff.new(params_nursing_staff)
            nursing_staff.password_valid?(params[:password])
            return error!(nursing_staff.error_messages, UNPROCESSABLE_ENTITY) if nursing_staff.error_messages.present?

            nursing_staff.nurse_code = generate_code(NursingStaff, :nurse_code) + last_four_digits_of_telephone(params[:telephone_number])
            nursing_staff.contact_relatives.each do |contact_relative|
              contact_relative.nurse = nursing_staff
            end
            nursing_staff.degrees.each do |degree|
              degree.nurse = nursing_staff
            end

            nursing_staff.update_family_name_and_name_kana(params_nursing_staff)
            if nursing_staff.save
              { success: I18n.t('nursing_staff.success.added') }
            else
              error!(nursing_staff.error_messages, UNPROCESSABLE_ENTITY)
            end
          end

          desc 'GET api/v1/admin/nursing_staffs/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
          end
          get ':id' do
            begin
              @nursing_staff = NursingStaff.find_by(id: params[:id])
              return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if @nursing_staff.blank?

              present @nursing_staff
            end
          end

          # Update NursingStaff
          desc 'PUT api/v1/admin/nursing_staffs/:id',
               headers: {
                 'Authorization' => {
                   description: 'Ex: Bearer [your_token]',
                   required: true
                 }
               }
          params do
            requires :id, type: Integer
            optional :cellphone_number, type: String
            optional :telephone_number, type: String
            optional :password, type: String
            optional :birth_date, type: String
            optional :sex, type: String, values: NursingStaff.sexes.keys
            optional :last_name, type: String
            optional :first_name, type: String
            optional :last_name_kana, type: String
            optional :first_name_kana, type: String
            optional :zipcode, type: String
            optional :district, type: String
            optional :city, type: String
            optional :street, type: String
            optional :my_number, type: String
            optional :building_name, type: String
            optional :join_date, type: String
            optional :status, type: String, values: NursingStaff.statuses.keys
            optional :employment_type, type: String, values: NursingStaff.employment_types.keys
            optional :contact_relatives_attributes, type: Array do
              optional :id, type: Integer
              optional :name, type: String
              optional :relationship, type: String
              optional :cellphone_number, type: String
              optional :telephone_number, type: String
              optional :address, type: String
            end
            optional :degrees_attributes, type: Array do
              optional :id, type: Integer
              optional :name, type: String
              optional :expired_date, type: String
            end
          end
          put ':id' do
            nursing_staff = NursingStaff.find_by(id: params[:id])
            return error!({ 'messages': I18n.t('errors.messages.not_found') }, NOT_FOUND) if nursing_staff.blank?

            nursing_staff.update_family_name_and_name_kana(params_nursing_staff)
            if params[:telephone_number].present?
              nurse_code = nursing_staff.nurse_code[0..-5] + last_four_digits_of_telephone(params[:telephone_number])
              nursing_staff.nurse_code = nurse_code
            end
            nursing_staff.password_valid?(params[:password]) if params[:password].present?
            return error!(nursing_staff.error_messages, UNPROCESSABLE_ENTITY) if nursing_staff.error_messages.present?

            current_user_id = current_user(UserAdmin, :user_code).id
            degrees_to_destroy = nursing_staff.degrees.where.not(id: params_nursing_staff[:degrees_attributes]&.pluck(:id))
            degrees_to_destroy.each do |degree|
              before_change = ''
              before_change += "資格名: #{degree.name}" if degree.name.present?
              before_change += '、' if degree.name.present? && degree.expired_date.present?
              before_change += "取得年月日: #{degree.expired_date.strftime('%Y年%m月%d日')}" if degree.expired_date.present?
              next if before_change.blank?

              create_change_history(nursing_staff, current_user_id, '保有資格', before_change, '削除されました。')
            end
            degrees_to_destroy.destroy_all
            if nursing_staff.update(params_nursing_staff)
              if nursing_staff.resigned?
                AuthenticationToken.where(nursing_staff_id: nursing_staff.id)&.destroy_all
              end

              nursing_staff.create_change_histories(current_user_id)
              { success: I18n.t('nursing_staff.success.updated') }
            else
              error!(nursing_staff.error_messages, UNPROCESSABLE_ENTITY)
            end
          end
        end
      end

      helpers do
        def params_nursing_staff
          params_nursing_staff = params.slice(
            :cellphone_number, :telephone_number, :password, :birth_date, :sex, :last_name, :first_name, :last_name_kana,
            :first_name_kana, :zipcode, :district, :city, :street, :my_number, :building_name, :join_date, :status, :employment_type
          )
          params_nursing_staff[:birth_date] = convert_date(params[:birth_date]) if params[:birth_date].present?

          if params[:contact_relatives_attributes].present?
            params_nursing_staff = params_nursing_staff.merge(contact_relatives_attributes: params_contact_relatives)
          end

          if params[:degrees_attributes].present?
            params_nursing_staff = params_nursing_staff.merge(degrees_attributes: params_degrees_attributes)
          end
          params_nursing_staff[:join_date] = convert_date(params[:join_date]) if params[:join_date].present?

          params_nursing_staff
        end

        def params_contact_relatives
          params[:contact_relatives_attributes].map do |contact_relative_params|
            contact_relative_params.slice(
              :id, :name, :relationship, :cellphone_number, :telephone_number, :address
            )
          end
        end

        def params_degrees_attributes
          params[:degrees_attributes].map do |degree_attributes|
            degree_attributes[:expired_date] = convert_date(degree_attributes[:expired_date]) if degree_attributes[:expired_date].present?
            degree_attributes.slice(:id, :name, :expired_date)
          end
        end

        def last_four_digits_of_telephone(telephone_number)
          telephone_number.slice(-4, 4)
        end

        def create_change_history(staff, current_user_id, changed_attribute, before_change, after_change)
          ChangeHistory.create(
            user_admin_id: current_user_id,
            changeable_id: staff.id,
            changeable_type: staff.class.name,
            changed_attribute: changed_attribute,
            before_change: before_change,
            after_change: after_change,
            date: Time.zone.today
          )
        end
      end
    end
  end
end
