class CreateShiftRegistrations < ActiveRecord::Migration[7.0]
  def change
    create_table :shift_registrations do |t|
      t.string :shift_code, null: false
      t.string :name, null: false
      t.string :abbreviation, null: false
      t.time :start_time, null: false
      t.time :end_time, null: false
      t.string :background_color, null: false
      t.string :text_color, null: false
      t.timestamps
    end
  end
end
