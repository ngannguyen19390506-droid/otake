module V1
  module Staff
    class EvalueTwoSerializer < ActiveModel::Serializer
      attributes :id,
                 :allergic,
                 :allergic_excretion,
                 :belt,
                 :belt_option,
                 :benefit_excretion,
                 :bottom,
                 :bottom_option,
                 :cognitive_level,
                 :crushing_process,
                 :declaration_intent,
                 :delusion,
                 :denial,
                 :dentures,
                 :dentures_option,
                 :dosage,
                 :dosage_level,
                 :eating_utensil,
                 :eating_utensil_option,
                 :excretory_form,
                 :excretory_form_option,
                 :form_movement,
                 :form_movement_option,
                 :glasses,
                 :grooming,
                 :grooming_level,
                 :has_glasses,
                 :head_washing,
                 :head_washing_level,
                 :hearing,
                 :hip_joint,
                 :hip_joint_option,
                 :is_allergic,
                 :is_benefit,
                 :is_crushing_process,
                 :is_delusion,
                 :is_denial,
                 :is_disability_hearing,
                 :is_disability_language,
                 :is_disability_sight,
                 :is_incontinence,
                 :is_normal_swallow,
                 :is_possible_declaration_intent,
                 :is_possible_understanding,
                 :is_toromi,
                 :is_treatment,
                 :is_urgent_urination,
                 :is_violence,
                 :is_wandering,
                 :language,
                 :luxury_goods,
                 :luxury_goods_option,
                 :move,
                 :move_level,
                 :neck,
                 :neck_option,
                 :recognition,
                 :removable,
                 :removable_level,
                 :side_meal,
                 :side_meal_option,
                 :sight,
                 :sit,
                 :sit_level,
                 :stand,
                 :stand_level,
                 :staple_food,
                 :staple_food_option,
                 :support,
                 :support_level,
                 :swallow,
                 :toromi,
                 :treatment,
                 :understanding,
                 :upper_limb,
                 :upper_limb_option,
                 :urgent_urination_excretion,
                 :violence,
                 :wandering,
                 :wash_face,
                 :wash_face_level,
                 :patient_id,
                 :created_date

      def staple_food_option
        Hash.from_xml(object.staple_food_option)['hash']
      end

      def side_meal_option
        Hash.from_xml(object.side_meal_option)['hash']
      end

      def eating_utensil_option
        Hash.from_xml(object.eating_utensil_option)['hash']
      end

      def luxury_goods_option
        Hash.from_xml(object.luxury_goods_option)['hash']
      end

      def neck_option
        Hash.from_xml(object.neck_option)['hash']
      end

      def upper_limb_option
        Hash.from_xml(object.upper_limb_option)['hash']
      end

      def belt_option
        Hash.from_xml(object.belt_option)['hash']
      end

      def hip_joint_option
        Hash.from_xml(object.hip_joint_option)['hash']
      end

      def bottom_option
        Hash.from_xml(object.bottom_option)['hash']
      end

      def form_movement_option
        Hash.from_xml(object.form_movement_option)['hash']
      end

      def excretory_form_option
        Hash.from_xml(object.excretory_form_option)['hash']
      end

      def dentures_option
        Hash.from_xml(object.dentures_option)['hash']
      end
    end
  end
end
